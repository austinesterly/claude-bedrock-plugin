// The fishing dimension's islands (0.1.272): where each one is, what kind it is and its shape, all worked out from the
// world's seed, so a world always has the same sky and every world a different one (Austin, 12 Nov 18:45Z: "we need to
// make sure each seed generates them randomly"). Nothing here touches the game: fishing/islands.js builds what these
// rules describe, a list of blocks at a time. Plan: research/Jack_rods_and_dimension_plan.md.
//
// The sky is cut into cells of LAYOUT.cell blocks. A cell holds one island or (LAYOUT.emptyChance) open sky. Cells go
// in regions of 2 by 2; a region can instead hold one huge island over all four (the ships and submarines, later) or a
// mythic one (the Shark People's town, later), and every world has one mythic region 2,000 to 4,000 blocks from the
// middle. An island's kind: common 55, uncommon 25, rare 12, exotic 7 (Austin's tiers). 0.1.272 built the common
// ones; 0.1.274 the uncommon ones too (BUILT): the common island's grass and ponds with amethyst worked through it, in
// purple and ZooCraft's red and blue (fishing/amethystRules.js): crystal spires, an open geode or two, crystals hanging
// under it and patches of amethyst in the grass. 0.1.275 the rare ones (Austin: "crying obsidian, and blackstone,
// gilded blackstone, some gold stuff as well, with a purply colored water"): blackstone ground with crimson nylium,
// huge crimson fungi for trees, a ruined portal of obsidian and crying obsidian with gold about it, broken pillars, gold
// in the stone, and ponds on magenta and purple beds (the sky's one biome gives all its water one colour, so the bed
// and a purple water fog, fishing/islands.js and equipment/divingHelmet.js, make it read purple). 0.1.276 the exotic
// ones (Austin: "a circled pool of water, relatively large, with large vibrant green weeping willows around it, there
// is a place for the angler to stand there as well. This shoud be a very lush island, with diamond shards sprinkled
// around as well"): one big round pool in the middle, deep in its centre; a ring of big bright green Weeping Willows
// round it leaning over the water; a spruce dock out into it from the side the portal is on, with lanterns at its end;
// grass and moss thick with flowers, ferns, azaleas and pink petals, a few azalea trees; seagrass and lily pads in the
// pool; glow berries hanging under it; and Diamond Shards lying about (fishing/diamondRules.js: 9 make a diamond). The
// 0.1.277 the mythic ones, each a town of the Shark People (Austin: "super rare, advanced fishing civilization of Shark
// People ... city like his picture, smaller"): a lagoon in the middle with a quay and piers, white houses with gold and
// blue domes round it, a palace with a great gold dome, a quartz wall with gold-domed towers and a golden gate, a ring
// of sea round the wall with sailboats on it, a causeway across it to a plaza on the beach (mythicSites). A mythic
// island takes a smaller radius than a huge one (MYTHIC_RADIUS) in the same place; no portal opens onto one, so it is
// found by travelling the sky. 0.1.280 the huge ones, each a harbour (Austin: "Some being huge with builds on them
// (fishing ships, submarines, etc)"; harbourSites): a round harbour with a stone quay, piers, two fishing trawlers, a
// submarine, boats, a lighthouse, fishing huts and fish stalls; no portal opens onto one either. Every kind is built now.
//
// 0.1.279: the closer sky (LAYOUT2, skyIslandsNear and the rest, after the first sky's layout below). Islands 172
// blocks apart instead of 256 (Austin: "33% closer"); the first sky's islands a world already built stay as they are.
// The game asks only the closer sky (sky...); the first sky's functions are for those islands and the tests.
//
// NEVER change LAYOUT or the hashing: islands already built in a world were placed by them.

export const FISHING = "zoocraft:fishing";

export const LAYOUT = Object.freeze({
  cell: 256,
  emptyChance: 0.12,
  kinds: /** @type {ReadonlyArray<[string, number]>} */ (Object.freeze([
    ["common", 55],
    ["uncommon", 25],
    ["rare", 12],
    ["exotic", 7],
  ])),
  hugeChance: 1 / 12,
  mythicChance: 0.01,
  mythicRing: Object.freeze([2000, 4000]),
  radius: Object.freeze([30, 60]),
  hugeRadius: Object.freeze([100, 130]),
  topY: Object.freeze([48, 200]),
  margin: 30,
});

/** The kinds of island this version builds (0.1.280: every kind, the huge ones too). */
export const BUILT = new Set(["common", "uncommon", "rare", "exotic", "mythic", "huge"]);

/** Most blocks in one list handed to the game at a time. */
import { willowCells, WILLOW, DRAPE_TIP } from "./willowRules.js";

export const BATCH = 2048;

// ---- hashing and noise

function mix(h) {
  h ^= h >>> 16;
  h = Math.imul(h, 0x7feb352d);
  h ^= h >>> 15;
  h = Math.imul(h, 0x846ca68b);
  h ^= h >>> 16;
  return h >>> 0;
}

/** A 32-bit number from the seed and three whole numbers. */
export function hash(seed, a, b, c) {
  let h = mix((seed ^ 0x9e3779b9) >>> 0);
  h = mix((h ^ (a | 0)) >>> 0);
  h = mix((h + Math.imul(b | 0, 0x85ebca6b)) >>> 0);
  h = mix((h ^ Math.imul(c | 0, 0xc2b2ae35)) >>> 0);
  return h;
}

/** 0 (inclusive) to 1 (exclusive) from a hash. */
export const unit = (h) => h / 4294967296;

/** The world's seed (a string in the game) as a 32-bit number. */
export function seedOf(text) {
  let h = 0x811c9dc5;
  for (const ch of String(text ?? "")) {
    h ^= ch.codePointAt(0) ?? 0;
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return mix(h >>> 0);
}

/** Smooth value noise, -1 to 1, one lattice step per unit. */
export function noise2(seed, x, z) {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = x - x0;
  const fz = z - z0;
  const u = fx * fx * (3 - 2 * fx);
  const v = fz * fz * (3 - 2 * fz);
  const a = unit(hash(seed, x0, z0, 7)) * 2 - 1;
  const b = unit(hash(seed, x0 + 1, z0, 7)) * 2 - 1;
  const c = unit(hash(seed, x0, z0 + 1, 7)) * 2 - 1;
  const d = unit(hash(seed, x0 + 1, z0 + 1, 7)) * 2 - 1;
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

/** Two octaves of noise2, -1 to 1. */
export function fbm2(seed, x, z) {
  return (noise2(seed, x, z) + 0.5 * noise2((seed + 1013) >>> 0, x * 2, z * 2)) / 1.5;
}

// ---- the layout

function mythicRegion(seed) {
  const a = unit(hash(seed, 0, 0, 101)) * Math.PI * 2;
  const [d0, d1] = LAYOUT.mythicRing;
  const d = d0 + unit(hash(seed, 0, 0, 103)) * (d1 - d0);
  const span = LAYOUT.cell * 2;
  return { rx: Math.floor((Math.cos(a) * d) / span), rz: Math.floor((Math.sin(a) * d) / span) };
}

/** "mythic", "huge" or undefined: what a region of 2 by 2 cells holds if it is one island. */
export function regionKind(seed, rx, rz) {
  const m = mythicRegion(seed);
  if (rx === m.rx && rz === m.rz) return "mythic";
  const u = unit(hash(seed, rx, rz, 107));
  if (u < LAYOUT.mythicChance) return "mythic";
  if (u < LAYOUT.mythicChance + LAYOUT.hugeChance) return "huge";
  return undefined;
}

/** How far an island's blocks can reach from its middle (its edge, the rocks floating round it). */
export function extentOf(isl) {
  return Math.ceil(isl.r * 1.15) + LAYOUT.margin;
}

function kindAt(seed, cx, cz) {
  const total = LAYOUT.kinds.reduce((s, [, w]) => s + w, 0);
  let u = unit(hash(seed, cx, cz, 137)) * total;
  for (const [k, w] of LAYOUT.kinds) {
    if (u < w) return k;
    u -= w;
  }
  return LAYOUT.kinds[0][0];
}

/**
 * The island in cell cx cz, or undefined for open sky: { id, kind, huge, x, z (its middle), y (its ground level),
 * r (its radius), s (its own seed) }. The four cells of a huge or mythic region give the same island.
 */
export function islandOf(seed, cx, cz) {
  const { cell } = LAYOUT;
  const rx = Math.floor(cx / 2);
  const rz = Math.floor(cz / 2);
  const big = regionKind(seed, rx, rz);
  const [y0, y1] = LAYOUT.topY;
  if (big) {
    const [r0, r1] = LAYOUT.hugeRadius;
    const u = unit(hash(seed, rx, rz, 109));
    const r = Math.round(r0 + u * (r1 - r0));
    const room = Math.max(0, cell - Math.ceil(r * 1.15) - LAYOUT.margin);
    const x = rx * 2 * cell + cell + Math.round((unit(hash(seed, rx, rz, 113)) * 2 - 1) * room);
    const z = rz * 2 * cell + cell + Math.round((unit(hash(seed, rx, rz, 127)) * 2 - 1) * room);
    const y = Math.round(y0 + unit(hash(seed, rx, rz, 131)) * (y1 - y0));
    // (0.1.277: a mythic island is a town smaller than a huge island, in the same place; its radius from the same number)
    const size = big === "mythic" ? Math.round(MYTHIC_RADIUS[0] + u * (MYTHIC_RADIUS[1] - MYTHIC_RADIUS[0])) : r;
    return { id: `r${rx},${rz}`, kind: big, huge: true, x, z, y, r: size, s: hash(seed, rx, rz, 139) };
  }
  if (unit(hash(seed, cx, cz, 149)) < LAYOUT.emptyChance) return undefined;
  const [r0, r1] = LAYOUT.radius;
  const r = Math.round(r0 + unit(hash(seed, cx, cz, 151)) * (r1 - r0));
  const lo = Math.ceil(r * 1.15) + LAYOUT.margin;
  const span = Math.max(0, cell - 2 * lo - 1);
  const x = cx * cell + lo + Math.floor(unit(hash(seed, cx, cz, 157)) * (span + 1));
  const z = cz * cell + lo + Math.floor(unit(hash(seed, cx, cz, 163)) * (span + 1));
  const y = Math.round(y0 + unit(hash(seed, cx, cz, 167)) * (y1 - y0));
  return { id: `${cx},${cz}`, kind: kindAt(seed, cx, cz), huge: false, x, z, y, r, s: hash(seed, cx, cz, 173) };
}

/** Every island whose blocks come within `reach` blocks of x z (each once). */
export function islandsNear(seed, x, z, reach) {
  const c = LAYOUT.cell;
  const out = new Map();
  for (let cx = Math.floor((x - reach) / c) - 1; cx <= Math.floor((x + reach) / c) + 1; cx++) {
    for (let cz = Math.floor((z - reach) / c) - 1; cz <= Math.floor((z + reach) / c) + 1; cz++) {
      const isl = islandOf(seed, cx, cz);
      if (!isl || out.has(isl.id)) continue;
      if (Math.hypot(isl.x - x, isl.z - z) - extentOf(isl) <= reach) out.set(isl.id, isl);
    }
  }
  return [...out.values()];
}

/** Whether this version builds that island (0.1.277: the mythic ones too; 0.1.280: the huge ones too, so every island). */
export const builds = (isl) => Boolean(isl) && BUILT.has(isl.kind);
/**
 * What 0.1.277 to 0.1.279 built: every island but the huge ones. The first sky's portals still choose by it (arrivalIsland),
 * and only such an island can be one a world already built (legacyOf).
 */
const builds279 = (isl) => Boolean(isl) && BUILT.has(isl.kind) && isl.kind !== "huge" && (!isl.huge || isl.kind === "mythic");

/**
 * The mythic island nearest x z within `regions` regions (of 2 by 2 cells) each way, or undefined: every world has
 * one 2,000 to 4,000 blocks from the middle, and about 1 region in 100 holds one.
 */
export function mythicNear(seed, x, z, regions = 10) {
  const span = LAYOUT.cell * 2;
  const rx0 = Math.floor(x / span);
  const rz0 = Math.floor(z / span);
  let best;
  for (let rz = rz0 - regions; rz <= rz0 + regions; rz++) {
    for (let rx = rx0 - regions; rx <= rx0 + regions; rx++) {
      if (regionKind(seed, rx, rz) !== "mythic") continue;
      const isl = /** @type {any} */ (islandOf(seed, rx * 2, rz * 2));
      const d = Math.hypot(isl.x - x, isl.z - z);
      if (!best || d < best.d) best = { isl, d };
    }
  }
  return best?.isl;
}

/** The island whose land covers x z (any kind, built or not), or undefined over open sky. */
export function islandAt(seed, x, z) {
  let best;
  for (const isl of islandsNear(seed, x, z, 0)) {
    const d = Math.hypot(isl.x - x, isl.z - z);
    if (d <= isl.r * 1.15 && (!best || d < best.d)) best = { isl, d };
  }
  return best?.isl;
}

/**
 * The loot table a catch comes from on an island of `islandKind`: an uncommon island's junk and treasure are its own
 * (0.1.274: amethyst shards and clusters in its three colours), a rare island's (0.1.275: blackstone, gold and the
 * Nether's treasures) and an exotic island's (0.1.276: its plants, and Diamond Shards, emeralds and the sea's
 * treasures) and a mythic island's (0.1.277: the sea's treasures, gold, prismarine, a trident now and then, a conduit
 * once in a long while) and a huge island's (0.1.280, its harbour: the fleet's lost gear, and lures, spyglasses,
 * emeralds), each mixed with the game's junk and treasure; a common island's junk and treasure are the game's
 * (undefined). 0.1.282: and every island's fish (FISH_SETS): its own fish among the game's.
 */
export const CATCH_SETS = Object.freeze({ uncommon: "crystal", rare: "gilded", exotic: "lush", mythic: "mythic", huge: "harbour" });
/**
 * 0.1.282: the fish an island gives (Jack's "new custom fish", fishing/skyFish.js): every kind's own fish now, a common
 * island's too (its junk and treasure stay the game's), each table its own fish and the game's fish.
 */
export const FISH_SETS = Object.freeze({ common: "sky", ...CATCH_SETS });
export function islandCatchPath(islandKind, kind) {
  const sets = kind === "fish" ? FISH_SETS : CATCH_SETS;
  const set = islandKind && Object.prototype.hasOwnProperty.call(sets, islandKind) ? sets[islandKind] : undefined;
  if (set && (kind === "junk" || kind === "treasure" || kind === "fish")) return `gameplay/fishing/zoocraft_${set}_${kind}`;
  return undefined;
}

/** What fills the gap under a return portal's frame: the island's own ground (0.1.275: a rare island's is blackstone). */
export const groundOf = (kind) => (kind === "rare" ? "minecraft:blackstone" : "minecraft:dirt");

/**
 * The island a portal at x z (in the fishing dimension's blocks) opens onto: the nearest one this version builds (0.1.277:
 * never a mythic one, which is found by travelling the sky: Austin, "super rare"); but
 * (0.1.275) like a Nether portal finding one already there, the nearest island that already has a return portal
 * (`linked`) if one is within a cell's width, so a later version building a new kind of island nearer doesn't move
 * where an old portal goes.
 */
export function arrivalIsland(seed, x, z, linked) {
  const near = islandsNear(seed, x, z, LAYOUT.cell * 6).filter((i) => builds279(i) && i.kind !== "mythic");
  near.sort((a, b) => Math.hypot(a.x - x, a.z - z) - Math.hypot(b.x - x, b.z - z) || (a.id < b.id ? -1 : 1));
  if (linked) {
    const old = near.find((i) => Math.hypot(i.x - x, i.z - z) <= LAYOUT.cell && linked(i));
    if (old) return old;
  }
  return near[0];
}

// ---- an island's shape

// ---- the closer sky (0.1.279)
//
// Austin, 13 Nov: "the islands to be 33% closer, right now they are very spaced apart. Or use your judgement if you
// think 33% is too much". The layout above is the first sky (0.1.272 to 0.1.278). It stays only for the islands it
// already built in a world (`legacy`, from the world's records, legacyOf): they keep their places and their blocks, and
// portals that opened onto them still do. Every other island comes from this one: cells of 172 blocks instead of 256,
// each island within 8 blocks of its cell's middle (the first sky's could sit anywhere in its cell), so neighbours'
// middles are about 170 blocks apart instead of about 226, and the open sky between them about 70 blocks instead of
// about 127. A full third closer (cells of 160) would have left 1 island in 10 out and made the rest smaller, to keep
// them apart. No two islands come nearer each other than their two reaches and 4 blocks (reachOf: their land and the
// rocks floating off it): the lower in rank is made smaller, or left out if that would make it smaller than 30 (100
// for a huge one, 46 for a mythic one). Rank: an island already built, then mythic, then huge, then the rest, by their
// hashes. A cell is open sky 1 time in 20 (1 in 8 before). One too near an island a world already built first moves straight away from it (at most half a cell), so the
// old ones get neighbours as near as anywhere else, not a hole round them. The kinds are as before (55, 25, 12, 7 in 100; 1 region in 12 huge, 1 in 100 mythic; one mythic 2,000 to
// 4,000 blocks from the middle), all from a seed of their own made from the world's.
//
// NEVER change LAYOUT2 or its hashing either: once a world has built islands from it, they were placed by it.

export const LAYOUT2 = Object.freeze({
  cell: 172,
  jitter: 8,
  gap: 4,
  /** a cell of open sky: 1 in 20 (the first sky's 1 in 8 left gaps of two cells, the very spacing Austin meant) */
  emptyChance: 0.05,
  minRadius: 30,
  minHugeRadius: 100,
  /** how far skyMythicNear looks, in regions of 2 by 2 cells each way (beyond the one 2,000 to 4,000 out) */
  mythicRegions: 15,
});

/** How far an island's blocks reach from its middle: its land (at most 1.08 r) and the rocks floating off it (28 more). */
export const reachOf = (isl) => Math.ceil(isl.r * 1.08 + 28);

/** The closer sky's own seed, from the world's. */
export const seed2Of = (seed) => hash(seed, 279, 2, 0x5ca1);

const regions2 = new Map();
function mythicRegion2(s2) {
  let m = regions2.get(s2);
  if (m) return m;
  const a = unit(hash(s2, 0, 0, 101)) * Math.PI * 2;
  const [d0, d1] = LAYOUT.mythicRing;
  const d = d0 + unit(hash(s2, 0, 0, 103)) * (d1 - d0);
  const span = LAYOUT2.cell * 2;
  m = { rx: Math.floor((Math.cos(a) * d) / span), rz: Math.floor((Math.sin(a) * d) / span) };
  if (regions2.size > 64) regions2.clear();
  regions2.set(s2, m);
  return m;
}

/** "mythic", "huge" or undefined: what a region of 2 by 2 cells of the closer sky holds if it is one island. */
export function regionKind2(s2, rx, rz) {
  const m = mythicRegion2(s2);
  if (rx === m.rx && rz === m.rz) return "mythic";
  const u = unit(hash(s2, rx, rz, 107));
  if (u < LAYOUT.mythicChance) return "mythic";
  if (u < LAYOUT.mythicChance + LAYOUT.hugeChance) return "huge";
  return undefined;
}

const raw = new Map();
/**
 * A cell's island before it makes room for its neighbours in the closer sky, but after making room for the islands a
 * world already built (roomFromLegacy): { isl, rank } (rank: [tier, a hash]), or undefined.
 */
function cellOf2(s2, cx, cz, legacy) {
  const cache = legacy === LEGACY;
  const key = `${s2}:${cx},${cz}`;
  if (cache && raw.has(key)) return raw.get(key);
  const c0 = rawCell2(s2, cx, cz);
  const c = c0 && legacy.length ? roomFromLegacy(c0, legacy) : c0;
  if (cache) {
    if (raw.size > 40000) raw.clear();
    raw.set(key, c);
  }
  return c;
}

/**
 * An island of the closer sky too near one a world already built moves straight away from it until there is room
 * (the two reaches and the gap), at most half a cell from its place, so the old islands get neighbours as near as
 * everywhere else, not a hole round them; whatever is still too near makes it smaller, or leaves it out.
 */
function roomFromLegacy(c, legacy) {
  const isl = c.isl;
  const near = legacy.filter((l) => Math.abs(l.x - isl.x) < 520 && Math.abs(l.z - isl.z) < 520);
  if (!near.length) return c;
  const { gap, cell } = LAYOUT2;
  const most = cell / 2;
  let { x, z, r } = isl;
  for (let pass = 0; pass < 2; pass++) {
    for (const l of near) {
      const need = reachOf({ r }) + reachOf(l) + gap;
      const d = Math.hypot(x - l.x, z - l.z);
      if (d >= need) continue;
      const ux = d > 0.5 ? (x - l.x) / d : 1;
      const uz = d > 0.5 ? (z - l.z) / d : 0;
      let nx = l.x + ux * (need + 0.5);
      let nz = l.z + uz * (need + 0.5);
      const sd = Math.hypot(nx - isl.x, nz - isl.z);
      if (sd > most) {
        nx = isl.x + ((nx - isl.x) / sd) * most;
        nz = isl.z + ((nz - isl.z) / sd) * most;
      }
      x = Math.round(nx);
      z = Math.round(nz);
    }
  }
  const min = smallest(isl);
  for (const l of near) {
    const room = Math.hypot(l.x - x, l.z - z) - gap - reachOf(l);
    while (r >= min && Math.ceil(r * 1.08 + 28) > room) r--;
    if (r < min) return undefined;
  }
  return x === isl.x && z === isl.z && r === isl.r ? c : { isl: { ...isl, x, z, r }, rank: c.rank };
}

function rawCell2(s2, cx, cz) {
  const { cell, jitter } = LAYOUT2;
  const [y0, y1] = LAYOUT.topY;
  const rx = Math.floor(cx / 2);
  const rz = Math.floor(cz / 2);
  const big = regionKind2(s2, rx, rz);
  if (big) {
    const [r0, r1] = LAYOUT.hugeRadius;
    const u = unit(hash(s2, rx, rz, 109));
    const r = big === "mythic" ? Math.round(MYTHIC_RADIUS[0] + u * (MYTHIC_RADIUS[1] - MYTHIC_RADIUS[0])) : Math.round(r0 + u * (r1 - r0));
    const x = rx * 2 * cell + cell + Math.round((unit(hash(s2, rx, rz, 113)) * 2 - 1) * jitter);
    const z = rz * 2 * cell + cell + Math.round((unit(hash(s2, rx, rz, 127)) * 2 - 1) * jitter);
    const y = Math.round(y0 + unit(hash(s2, rx, rz, 131)) * (y1 - y0));
    return { isl: { id: `2:r${rx},${rz}`, kind: big, huge: true, x, z, y, r, s: hash(s2, rx, rz, 139) }, rank: [big === "mythic" ? 2 : 1, hash(s2, rx, rz, 223)] };
  }
  if (unit(hash(s2, cx, cz, 149)) < LAYOUT2.emptyChance) return undefined;
  const [r0, r1] = LAYOUT.radius;
  const r = Math.round(r0 + unit(hash(s2, cx, cz, 151)) * (r1 - r0));
  const x = cx * cell + cell / 2 + Math.round((unit(hash(s2, cx, cz, 157)) * 2 - 1) * jitter);
  const z = cz * cell + cell / 2 + Math.round((unit(hash(s2, cx, cz, 163)) * 2 - 1) * jitter);
  const y = Math.round(y0 + unit(hash(s2, cx, cz, 167)) * (y1 - y0));
  return { isl: { id: `2:${cx},${cz}`, kind: kindAt(s2, cx, cz), huge: false, x, z, y, r, s: hash(s2, cx, cz, 173) }, rank: [0, hash(s2, cx, cz, 211)] };
}

const outranks = (a, b) => a.rank[0] > b.rank[0] || (a.rank[0] === b.rank[0] && (a.rank[1] > b.rank[1] || (a.rank[1] === b.rank[1] && a.isl.id < b.isl.id)));
const smallest = (isl) => (isl.kind === "mythic" ? MYTHIC_RADIUS[0] : isl.huge ? LAYOUT2.minHugeRadius : LAYOUT2.minRadius);

/** A cell's island once it has made room for those that outrank it (they as they were before making room themselves). */
function settle2(s2, c, legacy) {
  const { cell, gap } = LAYOUT2;
  const isl = c.isl;
  const above = [];
  const seen = new Set([isl.id]);
  const cx0 = Math.floor(isl.x / cell);
  const cz0 = Math.floor(isl.z / cell);
  // (two huge islands' reaches and the gap come to under 2 cells, and each is at most half a cell from its place; 3
  // each way covers them)
  for (let dx = -3; dx <= 3; dx++) {
    for (let dz = -3; dz <= 3; dz++) {
      const o = cellOf2(s2, cx0 + dx, cz0 + dz, legacy);
      if (!o || seen.has(o.isl.id)) continue;
      seen.add(o.isl.id);
      if (outranks(o, c)) above.push(o.isl);
    }
  }
  for (const l of legacy) if (Math.abs(l.x - isl.x) < 520 && Math.abs(l.z - isl.z) < 520) above.push(l);
  const min = smallest(isl);
  let r = isl.r;
  for (const o of above) {
    const room = Math.hypot(o.x - isl.x, o.z - isl.z) - gap - reachOf(o);
    while (r >= min && Math.ceil(r * 1.08 + 28) > room) r--;
    if (r < min) return undefined;
  }
  return r === isl.r ? isl : { ...isl, r };
}

let LEGACY = Object.freeze(/** @type {any[]} */ ([]));
const settled = new Map();

/** The islands the first sky built in this world (legacyOf), which the closer sky keeps and makes room for. */
export function setLegacy(list) {
  LEGACY = Object.freeze([...list]);
  settled.clear();
  raw.clear();
}
export const legacyIslands = () => LEGACY;

/**
 * The first sky's islands named by `ids` (the world's island records: "cx,cz" or "rX,Z"; the closer sky's are "2:..."),
 * those of a kind that gets built.
 */
export function legacyOf(seed, ids) {
  const out = [];
  for (const id of ids) {
    if (typeof id !== "string") continue;
    const m = /^(r?)(-?\d+),(-?\d+)$/.exec(id);
    if (!m) continue;
    const a = Number(m[2]);
    const b = Number(m[3]);
    const isl = m[1] ? islandOf(seed, a * 2, b * 2) : islandOf(seed, a, b);
    if (isl && isl.id === id && builds279(isl)) out.push(isl);
  }
  return out;
}

/** The closer sky's island in cell cx cz (the four cells of a huge or mythic region give the same one), or undefined. */
export function skyIslandOf(seed, cx, cz, legacy = LEGACY) {
  const s2 = seed2Of(seed);
  const key = `${s2}:${cx},${cz}`;
  const cache = legacy === LEGACY;
  if (cache && settled.has(key)) return settled.get(key);
  const c = cellOf2(s2, cx, cz, legacy);
  const isl = c ? settle2(s2, c, legacy) : undefined;
  if (cache) {
    if (settled.size > 20000) settled.clear();
    settled.set(key, isl);
  }
  return isl;
}

/** Every island whose blocks come within `reach` blocks of x z (each once): the closer sky's, and those already built. */
export function skyIslandsNear(seed, x, z, reach, legacy = LEGACY) {
  const c = LAYOUT2.cell;
  const out = new Map();
  for (let cx = Math.floor((x - reach) / c) - 1; cx <= Math.floor((x + reach) / c) + 1; cx++) {
    for (let cz = Math.floor((z - reach) / c) - 1; cz <= Math.floor((z + reach) / c) + 1; cz++) {
      const isl = skyIslandOf(seed, cx, cz, legacy);
      if (!isl || out.has(isl.id)) continue;
      if (Math.hypot(isl.x - x, isl.z - z) - extentOf(isl) <= reach) out.set(isl.id, isl);
    }
  }
  for (const l of legacy) if (!out.has(l.id) && Math.hypot(l.x - x, l.z - z) - extentOf(l) <= reach) out.set(l.id, l);
  return [...out.values()];
}

/** The island whose land covers x z (any kind, built or not), or undefined over open sky. */
export function skyIslandAt(seed, x, z, legacy = LEGACY) {
  let best;
  for (const isl of skyIslandsNear(seed, x, z, 0, legacy)) {
    const d = Math.hypot(isl.x - x, isl.z - z);
    if (d <= isl.r * 1.15 && (!best || d < best.d)) best = { isl, d };
  }
  return best?.isl;
}

/**
 * The island a portal at x z opens onto (as arrivalIsland did in the first sky): the nearest one that gets built, never
 * a mythic one (0.1.280: nor a huge one; both are found by travelling the sky); but the nearest one that already has a return portal (`linked`) if one is within 256 blocks, so a portal
 * that opened onto an island still does. A portal that opened onto one of the first sky's islands before 0.1.279 still
 * opens onto it: where the first sky's own choice (arrivalIsland, unchanged) is one of those islands, it stands. It
 * looks a little way out first, then farther (up to 1,536 blocks, as before).
 */
export function skyArrival(seed, x, z, linked, legacy = LEGACY) {
  if (linked && legacy.length) {
    const was = arrivalIsland(seed, x, z, linked);
    if (was && legacy.some((l) => l.id === was.id) && linked(was)) return was;
  }
  for (const reach of [LAYOUT.cell * 1.5, LAYOUT.cell * 3, LAYOUT.cell * 6]) {
    const near = skyIslandsNear(seed, x, z, reach, legacy).filter((i) => builds(i) && i.kind !== "mythic" && i.kind !== "huge");
    near.sort((a, b) => Math.hypot(a.x - x, a.z - z) - Math.hypot(b.x - x, b.z - z) || (a.id < b.id ? -1 : 1));
    if (linked) {
      const old = near.find((i) => Math.hypot(i.x - x, i.z - z) <= LAYOUT.cell && linked(i));
      if (old) return old;
    }
    // (every island nearer than `reach` is in the list, so its nearest is the nearest there is)
    if (near.length && (Math.hypot(near[0].x - x, near[0].z - z) <= reach || reach === LAYOUT.cell * 6)) return near[0];
  }
  return undefined;
}

/**
 * The mythic island nearest x z, or undefined: the closer sky's within LAYOUT2.mythicRegions regions each way (every
 * world has one 2,000 to 4,000 blocks from the middle, and about 1 region in 100 holds one), and those already built.
 */
export function skyMythicNear(seed, x, z, regions = LAYOUT2.mythicRegions, legacy = LEGACY) {
  const s2 = seed2Of(seed);
  const span = LAYOUT2.cell * 2;
  const rx0 = Math.floor(x / span);
  const rz0 = Math.floor(z / span);
  const towns = [...legacy];
  for (let rz = rz0 - regions; rz <= rz0 + regions; rz++) {
    for (let rx = rx0 - regions; rx <= rx0 + regions; rx++) {
      if (regionKind2(s2, rx, rz) === "mythic") towns.push(skyIslandOf(seed, rx * 2, rz * 2, legacy));
    }
  }
  let best;
  let bestD = Infinity;
  for (const isl of towns) {
    if (!isl || isl.kind !== "mythic") continue;
    const d = Math.hypot(isl.x - x, isl.z - z);
    if (d < bestD) {
      best = isl;
      bestD = d;
    }
  }
  return best;
}

export const AIR = 0;
export const LAND = 1;
export const POND = 2;
export const ROCK = 3;
/** A column over an open geode (0.1.274): its top is the geode's floor. */
export const GEODE = 4;

/**
 * An empty shape for the island: per column of its square (side W, corner x0 z0) its kind (AIR, LAND, POND, ROCK),
 * top (the grass, or the water's surface), floor (a pond's bed; the grass elsewhere), bottom (the lowest block),
 * edge (how far out the column is, 0 the middle to 100 the shore) and roots (a hanging root under it).
 */
export function newShape(isl) {
  const R = extentOf(isl);
  const W = 2 * R + 1;
  const n = W * W;
  return {
    R,
    W,
    x0: isl.x - R,
    z0: isl.z - R,
    kind: new Uint8Array(n),
    top: new Int16Array(n),
    floor: new Int16Array(n),
    bottom: new Int16Array(n),
    edge: new Uint8Array(n),
    roots: new Uint8Array(n),
    ponds: [],
    rocks: [],
    landing: undefined,
    trees: [],
    geodes: [],
    sites: [],
    spires: [],
    hangers: [],
    patches: [],
    ruins: [],
    pillars: [],
    fungi: [],
    dock: undefined,
    shards: [],
  };
}

/** The column index of x z in the shape, or -1 outside it. */
export function at(sh, x, z) {
  const i = x - sh.x0;
  const j = z - sh.z0;
  return i < 0 || j < 0 || i >= sh.W || j >= sh.W ? -1 : j * sh.W + i;
}

/** Works the island's shape out into `sh`, a row of columns per step (so the game can spread it over ticks). */
export function* shapeSteps(isl, sh) {
  const { r, y: y0, s } = isl;
  const depth = Math.max(8, Math.round(r * 0.6));
  // the body: a rounded, wavy shore; gentle hills on top; a deep, rough, dripping underside (0.1.277: a mythic island's
  // is its town's, mythicBody; 0.1.280: a huge one's has its harbour, hugeBody)
  if (isl.kind === "mythic") yield* mythicBody(isl, sh, depth);
  else if (isl.kind === "huge") yield* hugeBody(isl, sh);
  else for (let j = 0; j < sh.W; j++) {
    const z = sh.z0 + j;
    for (let i = 0; i < sh.W; i++) {
      const x = sh.x0 + i;
      const dx = x - isl.x;
      const dz = z - isl.z;
      const d = Math.hypot(dx, dz);
      if (d > r * 1.1) continue;
      const ang = Math.atan2(dz, dx);
      const re = r * (0.86 + 0.14 * fbm2((s ^ 0x1) >>> 0, 3 + 2 * Math.cos(ang), 3 + 2 * Math.sin(ang)) + 0.08 * noise2((s ^ 0x2) >>> 0, x / 18, z / 18));
      if (d >= re) continue;
      const t = d / re;
      const top = y0 + Math.round(2.5 * (1 - t * t) + 1.8 * fbm2((s ^ 0x3) >>> 0, x / 24, z / 24) - (t > 0.8 ? (t - 0.8) * 8 : 0));
      const under = depth * Math.pow(Math.max(0, 1 - t * t), 0.7) * (0.75 + 0.35 * noise2((s ^ 0x4) >>> 0, x / 12, z / 12));
      let drip = 0;
      if (t < 0.85) {
        const q = noise2((s ^ 0x5) >>> 0, x / 5, z / 5);
        if (q > 0.5) drip = (q - 0.5) * 2 * depth * 0.35 * (1 - t);
      }
      const k = j * sh.W + i;
      sh.kind[k] = LAND;
      sh.top[k] = top;
      sh.floor[k] = top;
      sh.bottom[k] = top - 2 - Math.round(under + drip);
      sh.edge[k] = Math.min(100, Math.round(t * 100));
    }
    yield;
  }
  // an exotic island's one big round pool in its middle (0.1.276), instead of the ponds
  if (isl.kind === "exotic") {
    exoticPool(isl, sh);
    yield;
  }
  // ponds of normal water, each in a sealed basin well inside the shore
  const tries = isl.kind === "exotic" || isl.kind === "mythic" || isl.kind === "huge" ? 0 : r >= 40 && unit(hash(s, 1, 0, 5)) < 0.6 ? 2 : 1;
  // a rare island always gets one (its purple water is its show): if its first looks found no room, up to 30 more
  const rarePonds = isl.kind === "rare";
  for (let p = 0; p < (rarePonds ? 32 : tries); p++) {
    if (p >= tries && sh.ponds.length) break;
    const a = unit(hash(s, p, 1, 7)) * Math.PI * 2;
    const dist = r * (0.12 + 0.28 * unit(hash(s, p, 2, 7)));
    // a rare island's ponds are its show (its purple water), so a little bigger (0.1.275)
    const big = isl.kind === "rare" ? 1.5 : 1;
    const pr = Math.max(4, Math.min(isl.kind === "rare" ? 14 : 10, Math.round(r * (0.11 + 0.08 * unit(hash(s, p, 3, 7))) * big)));
    const px = Math.round(isl.x + Math.cos(a) * dist);
    const pz = Math.round(isl.z + Math.sin(a) * dist);
    const bank = Math.ceil(pr * 1.7);
    if (sh.ponds.some((q) => Math.hypot(q.x - px, q.z - pz) < q.r * 1.7 + bank + 2)) continue;
    let ok = true;
    for (let z = pz - bank; z <= pz + bank && ok; z++) {
      for (let x = px - bank; x <= px + bank; x++) {
        if (Math.hypot(x - px, z - pz) > bank) continue;
        const k = at(sh, x, z);
        if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 85) {
          ok = false;
          break;
        }
      }
    }
    if (!ok) continue;
    sh.ponds.push({ x: px, z: pz, r: pr });
    for (let z = pz - bank; z <= pz + bank; z++) {
      for (let x = px - bank; x <= px + bank; x++) {
        const raw = Math.hypot(x - px, z - pz);
        if (raw > bank) continue;
        const k = at(sh, x, z);
        const pd = (raw / pr) * (1 + 0.18 * noise2((s ^ 0x6) >>> 0, x / 4, z / 4));
        if (pd < 1) {
          const floor = y0 - (1 + Math.round(2.5 * (1 - pd * pd)));
          sh.kind[k] = POND;
          sh.top[k] = y0;
          sh.floor[k] = floor;
          sh.bottom[k] = Math.min(sh.bottom[k], floor - 2);
        } else if (sh.kind[k] === LAND && sh.top[k] < y0) {
          sh.top[k] = y0;
          sh.floor[k] = y0;
        }
      }
    }
    yield;
  }
  // small rocks floating off the shore
  const rocks = 2 + Math.floor(unit(hash(s, 9, 0, 3)) * 3);
  for (let q = 0; q < rocks; q++) {
    const a = unit(hash(s, q, 9, 11)) * Math.PI * 2;
    const rr = 3 + Math.floor(unit(hash(s, q, 9, 13)) * 4);
    const dist = r * 1.08 + 8 + unit(hash(s, q, 9, 17)) * 14;
    const qx = Math.round(isl.x + Math.cos(a) * dist);
    const qz = Math.round(isl.z + Math.sin(a) * dist);
    const qy = y0 - 6 + Math.floor(unit(hash(s, q, 9, 19)) * 12);
    let free = true;
    for (let z = qz - rr - 2; z <= qz + rr + 2 && free; z++) for (let x = qx - rr - 2; x <= qx + rr + 2; x++) if (sh.kind[at(sh, x, z)] !== AIR) free = false;
    if (!free) continue;
    sh.rocks.push({ x: qx, z: qz, y: qy, r: rr });
    for (let z = qz - rr; z <= qz + rr; z++) {
      for (let x = qx - rr; x <= qx + rr; x++) {
        const d = Math.hypot(x - qx, z - qz) / (rr * (0.85 + 0.15 * noise2((s ^ 0x7) >>> 0, x / 3, z / 3)));
        if (d >= 1) continue;
        const k = at(sh, x, z);
        const top = qy + (d < 0.5 ? 1 : 0);
        sh.kind[k] = ROCK;
        sh.top[k] = top;
        sh.floor[k] = top;
        sh.bottom[k] = top - 1 - Math.round(rr * 1.3 * (1 - d * d));
        sh.edge[k] = 100;
      }
    }
  }
  // hanging roots under a few columns
  for (let k = 0; k < sh.kind.length; k++) {
    if (sh.kind[k] !== LAND || sh.edge[k] > 70) continue;
    const x = sh.x0 + (k % sh.W);
    const z = sh.z0 + Math.floor(k / sh.W);
    if (sh.top[k] - sh.bottom[k] >= 4 && unit(hash(s, x, z, 37)) < 0.05) sh.roots[k] = 1;
  }
  if (isl.kind === "uncommon") geodesOf(isl, sh);
  // (0.1.280: no portal opens onto a huge island, so it has no landing)
  sh.landing = isl.kind === "mythic" ? mythicLanding(isl) : isl.kind === "huge" ? undefined : landingOf(isl, sh);
  if (isl.kind === "uncommon") {
    yield;
    crystalSites(isl, sh);
  }
  if (isl.kind === "rare") {
    yield;
    rareSites(isl, sh);
  }
  if (isl.kind === "exotic") {
    // its dock, its willows and azalea trees (its trees), then the Diamond Shards about it
    yield;
    exoticSites(isl, sh);
  } else if (isl.kind === "mythic") {
    // its town (0.1.277): its palms are its own, built block by block
    yield;
    yield* mythicSites(isl, sh);
  } else if (isl.kind === "huge") {
    // its harbour (0.1.280), then its groves
    yield;
    yield* harbourSites(isl, sh);
    sh.trees = hugeTrees(isl, sh);
  } else sh.trees = isl.kind === "rare" ? [] : treesOf(isl, sh);
  yield;
}

// ---- amethyst on an uncommon island (0.1.274)

/** The island's own colour of amethyst: purple 40 in 100, red 30, blue 30. */
export function colourOf(isl) {
  const u = unit(hash(isl.s, 61, 0, 1));
  return u < 0.4 ? "purple" : u < 0.7 ? "red" : "blue";
}

/** One feature's colour: the island's own 3 times in 5, else one of the other two. */
export function featureColour(isl, a, b) {
  const main = colourOf(isl);
  const u = unit(hash(isl.s, a, b, 63));
  if (u < 0.6) return main;
  const others = ["purple", "red", "blue"].filter((c) => c !== main);
  return others[u < 0.8 ? 0 : 1];
}

/** Ground whole and dry all round x z out to `n` blocks, well inside the shore. */
function solidGround(sh, x, z, n, maxEdge) {
  for (let dz = -n; dz <= n; dz++) {
    for (let dx = -n; dx <= n; dx++) {
      if (Math.hypot(dx, dz) > n) continue;
      const k = at(sh, x + dx, z + dz);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > maxEdge) return false;
    }
  }
  return true;
}

/**
 * One or two open geodes (one on a smaller island): a hollow ball under the grass with its top cut off, so it's a
 * bowl lined with amethyst, then calcite, then smooth basalt, as the game's geodes, with crystals growing inside. The
 * columns over the hollow lose everything above its floor (GEODE).
 */
function geodesOf(isl, sh) {
  const n = isl.r >= 40 ? 2 : 1;
  for (let g = 0; g < 32 && sh.geodes.length < n; g++) {
    const R = 4 + Math.floor(unit(hash(isl.s, g, 71, 1)) * 3);
    const a = unit(hash(isl.s, g, 71, 2)) * Math.PI * 2;
    const dist = isl.r * 0.62 * Math.sqrt(unit(hash(isl.s, g, 71, 3)));
    const gx = Math.round(isl.x + Math.cos(a) * dist);
    const gz = Math.round(isl.z + Math.sin(a) * dist);
    if (!solidGround(sh, gx, gz, R + 3, 78)) continue;
    if (sh.ponds.some((p) => Math.hypot(p.x - gx, p.z - gz) < p.r * 1.7 + R + 3)) continue;
    if (sh.geodes.some((q) => Math.hypot(q.x - gx, q.z - gz) < q.R + R + 10)) continue;
    const cy = sh.top[at(sh, gx, gz)] - Math.round(R * 0.35);
    sh.geodes.push({ x: gx, z: gz, y: cy, R, colour: featureColour(isl, g, 73) });
    for (let z = gz - R; z <= gz + R; z++) {
      for (let x = gx - R; x <= gx + R; x++) {
        const h = Math.hypot(x - gx, z - gz);
        if (h >= R) continue;
        const k = at(sh, x, z);
        const floor = Math.floor(cy - Math.sqrt(R * R - h * h));
        if (floor >= sh.top[k]) continue;
        sh.kind[k] = GEODE;
        sh.top[k] = floor;
        sh.floor[k] = floor;
        sh.bottom[k] = Math.min(sh.bottom[k], floor - 4);
      }
    }
  }
}

/**
 * Where the amethyst grows: spire clusters on the grass (3 to 9, each one colour: a tall spire and up to three
 * smaller ones leaning out from it), crystals hanging under the island, and patches of amethyst in the grass. All
 * clear of the ponds, the geodes and the landing.
 */
function crystalSites(isl, sh) {
  const clear = (x, z, room, apart = 11) => {
    if (sh.landing && Math.hypot(x - sh.landing.x, z - sh.landing.z) < 9 + room) return false;
    if (sh.geodes.some((g) => Math.hypot(x - g.x, z - g.z) < g.R + 5 + room)) return false;
    if (sh.sites.some((q) => Math.hypot(x - q.x, z - q.z) < apart)) return false;
    return !nearWater(sh, x, z, 3 + room);
  };
  const want = Math.max(4, Math.round(isl.r / 8)) + Math.floor(unit(hash(isl.s, 81, 0, 1)) * 3);
  // the spots: the first look as it was; if a small or crowded island found fewer than 4, more looks, a little closer together
  const looks = [];
  for (let t = 0; t < want * 4; t++) looks.push([t, 11, 3]);
  for (let t = 1000; t < 1000 + want * 16; t++) looks.push([t, 8, 2]);
  for (const [t, apart, ground] of looks) {
    if (sh.sites.length >= (t >= 1000 ? 4 : want)) break;
    const a = unit(hash(isl.s, t, 81, 2)) * Math.PI * 2;
    const d = isl.r * 0.8 * Math.sqrt(unit(hash(isl.s, t, 81, 3)));
    const x = Math.round(isl.x + Math.cos(a) * d);
    const z = Math.round(isl.z + Math.sin(a) * d);
    if (!solidGround(sh, x, z, ground, 80) || !clear(x, z, 0, apart)) continue;
    const site = { x, z, colour: featureColour(isl, t, 83) };
    sh.sites.push(site);
    const u = (c) => unit(hash(isl.s, t, 85, c));
    const main = { x, z, y: sh.top[at(sh, x, z)] - 1, h: 8 + Math.floor(u(1) * 9), r0: 1.8 + u(2) * 1.0, tx: (u(3) - 0.5) * 0.24, tz: (u(4) - 0.5) * 0.24, colour: site.colour, dir: 1 };
    sh.spires.push(main);
    const more = 2 + Math.floor(u(5) * 3);
    for (let m = 0; m < more; m++) {
      const b = u(10 + m) * Math.PI * 2;
      const off = 2 + u(20 + m) * 1.5;
      const sx = Math.round(x + Math.cos(b) * off);
      const sz = Math.round(z + Math.sin(b) * off);
      const k = at(sh, sx, sz);
      if (k < 0 || sh.kind[k] !== LAND) continue;
      const lean = 0.25 + u(30 + m) * 0.2;
      sh.spires.push({ x: sx, z: sz, y: sh.top[k] - 1, h: 4 + Math.floor(u(40 + m) * 6), r0: 1.0 + u(50 + m) * 0.6, tx: Math.cos(b) * lean, tz: Math.sin(b) * lean, colour: site.colour, dir: 1 });
    }
  }
  // crystals hanging under the island
  const hangs = 2 + Math.round(isl.r / 12);
  for (let t = 0; t < hangs * 4 && sh.hangers.length < hangs; t++) {
    const a = unit(hash(isl.s, t, 87, 2)) * Math.PI * 2;
    const d = isl.r * 0.6 * Math.sqrt(unit(hash(isl.s, t, 87, 3)));
    const x = Math.round(isl.x + Math.cos(a) * d);
    const z = Math.round(isl.z + Math.sin(a) * d);
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] !== LAND || sh.roots[k] || sh.edge[k] > 60) continue;
    if (sh.hangers.some((q) => Math.hypot(x - q.x, z - q.z) < 8)) continue;
    const u = (c) => unit(hash(isl.s, t, 89, c));
    sh.hangers.push({ x, z, y: sh.bottom[k], h: 5 + Math.floor(u(1) * 8), r0: 1.3 + u(2) * 0.9, tx: (u(3) - 0.5) * 0.3, tz: (u(4) - 0.5) * 0.3, colour: featureColour(isl, t, 91), dir: -1 });
  }
  // patches of amethyst showing through the grass
  const patches = 4 + Math.round(isl.r / 10);
  const tries = [];
  for (let t = 0; t < patches * 4; t++) tries.push([t, 2, 6]);
  for (let t = 1000; t < 1000 + patches * 16; t++) tries.push([t, 1, 4]);
  for (const [t, ground, apart] of tries) {
    if (sh.patches.length >= (t >= 1000 ? 3 : patches)) break;
    const a = unit(hash(isl.s, t, 93, 2)) * Math.PI * 2;
    const d = isl.r * 0.85 * Math.sqrt(unit(hash(isl.s, t, 93, 3)));
    const x = Math.round(isl.x + Math.cos(a) * d);
    const z = Math.round(isl.z + Math.sin(a) * d);
    if (!solidGround(sh, x, z, ground, 85) || !clear(x, z, 0, 6)) continue;
    if (sh.patches.some((q) => Math.hypot(x - q.x, z - q.z) < apart)) continue;
    sh.patches.push({ x, z, r: 1 + unit(hash(isl.s, t, 95, 1)) * 1.3, colour: featureColour(isl, t, 97) });
  }
}

// ---- a rare island (0.1.275): blackstone, gold, crimson fungi and a ruined portal

/**
 * Where a rare island's builds stand, all clear of its ponds, its landing and each other: a ruined portal (two on a
 * big island), a few broken pillars and huge crimson fungi (its trees: at least 3, more on a big island).
 */
function rareSites(isl, sh) {
  const s = isl.s;
  const far = (x, z, list, n) => list.every((q) => Math.hypot(x - q.x, z - q.z) >= n);
  const offLanding = (x, z, n) => !sh.landing || Math.hypot(x - sh.landing.x, z - sh.landing.z) >= n;
  // the ruined portal: obsidian and crying obsidian, 4 to 6 wide and 5 to 7 tall, broken in places
  // (a small island with a big pond: a second look, a little closer to the water and the landing, so it gets one)
  const ruins = isl.r >= 45 ? 2 : 1;
  const looks = [];
  for (let t = 0; t < 48; t++) looks.push([t, 4, 6, 14]);
  for (let t = 1000; t < 1064; t++) looks.push([t, 3, 4, 11]);
  for (const [t, ground, water, landing] of looks) {
    if (sh.ruins.length >= (t >= 1000 ? 1 : ruins)) break;
    const a = unit(hash(s, t, 201, 1)) * Math.PI * 2;
    const d = isl.r * 0.62 * Math.sqrt(unit(hash(s, t, 201, 2)));
    const x = Math.round(isl.x + Math.cos(a) * d);
    const z = Math.round(isl.z + Math.sin(a) * d);
    if (!solidGround(sh, x, z, ground, 72) || nearWater(sh, x, z, water) || !offLanding(x, z, landing) || !far(x, z, sh.ruins, 22)) continue;
    sh.ruins.push({ x, z, axis: unit(hash(s, t, 201, 3)) < 0.5 ? "x" : "z", w: 4 + Math.floor(unit(hash(s, t, 201, 4)) * 3), h: 5 + Math.floor(unit(hash(s, t, 201, 5)) * 3), t });
  }
  // broken pillars of polished blackstone bricks, some with a gold block on top
  const pillars = 3 + Math.floor(isl.r / 20);
  for (let t = 0; t < pillars * 8 && sh.pillars.length < pillars; t++) {
    const a = unit(hash(s, t, 203, 1)) * Math.PI * 2;
    const d = isl.r * 0.8 * Math.sqrt(unit(hash(s, t, 203, 2)));
    const x = Math.round(isl.x + Math.cos(a) * d);
    const z = Math.round(isl.z + Math.sin(a) * d);
    if (!solidGround(sh, x, z, 1, 80) || nearWater(sh, x, z, 2) || !offLanding(x, z, 8) || !far(x, z, sh.ruins, 9) || !far(x, z, sh.pillars, 6)) continue;
    sh.pillars.push({ x, z, h: 2 + Math.floor(unit(hash(s, t, 203, 3)) * 5), gold: unit(hash(s, t, 203, 4)) < 0.45, t });
  }
  // huge crimson fungi: a first look on a grid (at most 6, 9 on a big island), then, if it found fewer than 3 (5 on
  // a big island), a second look in its own random order over the spots between, and a third a little closer in
  const want = isl.r >= 45 ? 5 : 3;
  const most = isl.r >= 45 ? 9 : 6;
  const grow = (x, z, near = false) => {
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 75 || sh.top[k] !== sh.floor[k] || nearWater(sh, x, z, near ? 3 : 4)) return;
    if (!offLanding(x, z, near ? 9 : 11) || !far(x, z, sh.ruins, near ? 9 : 11) || !far(x, z, sh.pillars, near ? 5 : 6) || !far(x, z, sh.fungi, near ? 8 : 9)) return;
    const h = 5 + Math.floor(unit(hash(s, x, z, 209)) * 6);
    sh.fungi.push({ x, z, y: sh.top[k] + 1, h, R: h >= 8 ? 3 : 2 });
  };
  for (let gz = -sh.R; gz <= sh.R && sh.fungi.length < most; gz += 9) {
    for (let gx = -sh.R; gx <= sh.R && sh.fungi.length < most; gx += 9) {
      if (unit(hash(s, gx, gz, 205)) < 0.45) grow(isl.x + gx + Math.floor(unit(hash(s, gx, gz, 206)) * 5) - 2, isl.z + gz + Math.floor(unit(hash(s, gx, gz, 207)) * 5) - 2);
    }
  }
  const more = [];
  for (let gz = -sh.R + 2; gz <= sh.R; gz += 4) for (let gx = -sh.R + 2; gx <= sh.R; gx += 4) more.push([gx, gz, unit(hash(s, gx, gz, 208))]);
  more.sort((a, b) => a[2] - b[2]);
  for (const near of [false, true]) {
    for (const [gx, gz] of more) {
      if (sh.fungi.length >= want) break;
      grow(isl.x + gx, isl.z + gz, near);
    }
  }
}

/** The cells of a huge crimson fungus: its stem, its cap of nether wart with shroomlights inside, vines under its rim. */
function fungusCells(f, s) {
  const out = [];
  const u = (x, y, z, c) => unit(hash(s, x * 3 + c, y, z * 5 + c));
  for (let i = 0; i < f.h; i++) out.push({ x: f.x, y: f.y + i, z: f.z, id: "minecraft:crimson_stem" });
  const capH = f.R + 1;
  const top = f.y + f.h;
  const hem = [];
  for (let L = 0; L < capH; L++) {
    const y = top - L;
    const r = L === 0 ? f.R - 1 : f.R;
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        const ring = Math.max(Math.abs(dx), Math.abs(dz));
        const x = f.x + dx;
        const z = f.z + dz;
        if (Math.abs(dx) === r && Math.abs(dz) === r && r > 1) continue; // round off the corners
        if (L === 0) {
          out.push({ x, y, z, id: "minecraft:nether_wart_block" });
          continue;
        }
        if (ring === r) {
          if (L === capH - 1 && u(x, y, z, 1) < 0.35) continue; // a ragged hem
          out.push({ x, y, z, id: u(x, y, z, 2) < 0.1 ? "minecraft:shroomlight" : "minecraft:nether_wart_block" });
          if (L === capH - 1) hem.push({ x, y, z });
        } else if (ring === r - 1 && !(dx === 0 && dz === 0)) {
          const v = u(x, y, z, 3);
          if (v < 0.14) out.push({ x, y, z, id: "minecraft:shroomlight" });
          else if (v < 0.3) out.push({ x, y, z, id: "minecraft:nether_wart_block" });
        }
      }
    }
  }
  for (const c of hem) {
    if (u(c.x, c.y, c.z, 4) >= 0.3) continue;
    const n = 1 + Math.floor(u(c.x, c.y, c.z, 5) * 3);
    for (let i = 1; i <= n; i++) out.push({ x: c.x, y: c.y - i, z: c.z, id: "minecraft:weeping_vines", hang: true });
  }
  return out;
}

/**
 * A rare island's builds, worked out from its shape: the ruined portals (frame, rubble, the worked stone and gold
 * round its foot, blackstone under the frame where the ground dips), the pillars and the fungi. Returns
 * Map("x,y,z" -> block id); a cell already taken keeps its first block, as the game's air-only fills do.
 */
export function rareOfIsland(isl, sh) {
  const s = isl.s;
  const out = new Map();
  const key = (x, y, z) => `${x},${y},${z}`;
  const set = (x, y, z, id) => {
    const k = key(x, y, z);
    if (!out.has(k)) out.set(k, id);
  };
  const topAt = (x, z) => {
    const k = at(sh, x, z);
    return k < 0 || sh.kind[k] !== LAND ? undefined : sh.top[k];
  };
  for (const ru of sh.ruins) {
    const [ax, az] = ru.axis === "x" ? [1, 0] : [0, 1];
    const lo = -Math.floor((ru.w - 1) / 2);
    let base = -Infinity;
    for (let i = 0; i < ru.w; i++) base = Math.max(base, (topAt(ru.x + (lo + i) * ax, ru.z + (lo + i) * az) ?? -Infinity) + 1);
    const u = (a, b, c) => unit(hash(s, ru.t * 31 + a, b, 211 + c));
    const missing = [];
    for (let i = 0; i < ru.w; i++) {
      const x = ru.x + (lo + i) * ax;
      const z = ru.z + (lo + i) * az;
      const tp = topAt(x, z);
      for (let y = tp + 1; y < base; y++) set(x, y, z, "minecraft:blackstone");
      for (let j = 0; j < ru.h; j++) {
        if (i !== 0 && i !== ru.w - 1 && j !== 0 && j !== ru.h - 1) continue;
        const v = u(i, j, 1);
        const corner = (i === 0 || i === ru.w - 1) && j === ru.h - 1;
        if (j > 0 && v < (corner ? 0.45 : 0.2)) {
          missing.push([i, j]);
          continue;
        }
        if (j === 0 && v < 0.06) continue;
        set(x, base + j, z, v < 0.48 ? "minecraft:crying_obsidian" : "minecraft:obsidian");
      }
    }
    // the worked stone round its foot: polished and cracked bricks, gilded blackstone and a little magma
    for (let dz = -4; dz <= 4; dz++) {
      for (let dx = -4; dx <= 4; dx++) {
        if (Math.hypot(dx, dz) > 3.6) continue;
        const x = ru.x + dx;
        const z = ru.z + dz;
        const tp = topAt(x, z);
        if (tp === undefined) continue;
        const v = u(dx + 9, dz + 9, 2);
        const id = v < 0.34 ? "minecraft:polished_blackstone_bricks" : v < 0.5 ? "minecraft:cracked_polished_blackstone_bricks" : v < 0.6 ? "minecraft:gilded_blackstone" : v < 0.64 ? "minecraft:magma" : undefined;
        if (id) set(x, tp, z, id);
      }
    }
    // the pieces that fell, lying near it, and gold blocks
    const lying = [];
    for (const [i, j] of missing) {
      if (u(i, j, 3) >= 0.55) continue;
      const side = u(i, j, 4) < 0.5 ? -1 : 1;
      const off = 2 + Math.floor(u(i, j, 5) * 2);
      const along = lo + i + Math.floor(u(i, j, 6) * 3) - 1;
      lying.push([ru.x + along * ax + side * off * az, ru.z + along * az + side * off * ax, u(i, j, 7) < 0.5 ? "minecraft:obsidian" : "minecraft:crying_obsidian"]);
    }
    const golds = 1 + Math.floor(u(0, 0, 8) * 3);
    for (let g = 0; g < golds; g++) {
      const side = u(g, 1, 9) < 0.5 ? -1 : 1;
      const off = 1 + Math.floor(u(g, 2, 9) * 3);
      const along = lo - 1 + Math.floor(u(g, 3, 9) * (ru.w + 2));
      lying.push([ru.x + along * ax + side * off * az, ru.z + along * az + side * off * ax, "minecraft:gold_block"]);
    }
    for (const [x, z, id] of lying) {
      const tp = topAt(x, z);
      if (tp === undefined || out.has(key(x, tp + 1, z))) continue;
      set(x, tp + 1, z, id);
    }
  }
  for (const p of sh.pillars) {
    const tp = topAt(p.x, p.z);
    for (let i = 1; i <= p.h; i++) set(p.x, tp + i, p.z, i === p.h ? "minecraft:chiseled_polished_blackstone" : unit(hash(s, p.t, i, 217)) < 0.3 ? "minecraft:cracked_polished_blackstone_bricks" : "minecraft:polished_blackstone_bricks");
    if (p.gold && p.h >= 3) set(p.x, tp + p.h + 1, p.z, "minecraft:gold_block");
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const t2 = topAt(p.x + dx, p.z + dz);
      if (t2 !== undefined) set(p.x + dx, t2, p.z + dz, "minecraft:polished_blackstone_bricks");
    }
  }
  // the fungi: no cell of a cap or its vines goes into the ground where the land rises under it
  for (const f of sh.fungi) {
    const cut = new Set();
    for (const c of fungusCells(f, s)) {
      const k = at(sh, c.x, c.z);
      const ground = k >= 0 && sh.kind[k] !== AIR && c.y <= sh.top[k];
      if (c.hang && (ground || cut.has(`${c.x},${c.z}`))) {
        cut.add(`${c.x},${c.z}`);
        continue;
      }
      if (!ground) set(c.x, c.y, c.z, c.id);
    }
  }
  return out;
}

/** The block on top of a rare island's column (0.1.275): blackstone, crimson nylium in patches and round each fungus, gilded specks, crying obsidian at the ponds' edges. */
function rareTopOf(isl, sh, k, x, z) {
  const s = isl.s;
  if (sh.kind[k] === LAND && sh.top[k] === isl.y && (isWet(sh, x + 1, z) || isWet(sh, x - 1, z) || isWet(sh, x, z + 1) || isWet(sh, x, z - 1))) {
    return unit(hash(s, x, z, 221)) < 0.4 ? "minecraft:crying_obsidian" : "minecraft:blackstone";
  }
  if (sh.fungi.some((f) => Math.hypot(x - f.x, z - f.z) <= 2.5)) return "minecraft:crimson_nylium";
  if (!nearWater(sh, x, z, 1) && fbm2((s ^ 0xa) >>> 0, x / 11, z / 11) > 0.12) return "minecraft:crimson_nylium";
  const u = unit(hash(s, x, z, 223));
  if (u < 0.035) return "minecraft:gilded_blackstone";
  return "minecraft:blackstone";
}

/** A rare pond's bed: magenta and purple, so the clear water over it reads purple, with crying obsidian glowing here and there. */
function rareBedOf(isl, x, z) {
  const u = unit(hash(isl.s, x, z, 225));
  if (u < 0.14) return "minecraft:crying_obsidian";
  return noise2((isl.s ^ 0xc) >>> 0, x / 4, z / 4) > 0.15 ? "minecraft:purple_concrete" : "minecraft:magenta_concrete";
}

/** The island's whole shape at once (tests, and anything that needn't spread it out). */
// ---- an exotic island (0.1.276): its pool, dock, willows and Diamond Shards

/** How much farther than the pool's edge the land round it reaches before it rises to the island's own ground. */
const POOL_BANK = 7;

/**
 * The one big round pool in the middle of an exotic island: as big as the island leaves room for (a third or so of its
 * radius, 10 to 20 blocks; smaller if the land round it is short), 1 block deep at the edge and 6 in the middle, the
 * ground round it eased down to the water's level so its banks are low and level.
 */
function exoticPool(isl, sh) {
  const { s, y: y0 } = isl;
  const a = unit(hash(s, 2, 1, 7)) * Math.PI * 2;
  const off = isl.r * 0.05 * unit(hash(s, 2, 2, 7));
  const px = Math.round(isl.x + Math.cos(a) * off);
  const pz = Math.round(isl.z + Math.sin(a) * off);
  const want = Math.max(10, Math.min(22, Math.round(isl.r * (0.4 + 0.06 * unit(hash(s, 2, 3, 7))))));
  for (let pr = want; pr >= 8; pr--) {
    const ring = pr + POOL_BANK;
    let ok = true;
    for (let z = pz - ring; z <= pz + ring && ok; z++) {
      for (let x = px - ring; x <= px + ring; x++) {
        if (Math.hypot(x - px, z - pz) > ring) continue;
        const k = at(sh, x, z);
        if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 85) {
          ok = false;
          break;
        }
      }
    }
    if (!ok) continue;
    sh.ponds.push({ x: px, z: pz, r: pr, pool: true });
    for (let z = pz - ring; z <= pz + ring; z++) {
      for (let x = px - ring; x <= px + ring; x++) {
        const raw = Math.hypot(x - px, z - pz);
        if (raw > ring) continue;
        const k = at(sh, x, z);
        const pd = (raw / pr) * (1 + 0.05 * noise2((s ^ 0x6) >>> 0, x / 5, z / 5));
        if (pd < 1) {
          const floor = y0 - (1 + Math.round(5 * (1 - pd * pd)));
          sh.kind[k] = POND;
          sh.top[k] = y0;
          sh.floor[k] = floor;
          sh.bottom[k] = Math.min(sh.bottom[k], floor - 2);
        } else {
          const u = Math.min(1, Math.max(0, (raw - pr) / POOL_BANK));
          const top = y0 + Math.round(Math.max(0, sh.top[k] - y0) * u * u * (3 - 2 * u));
          sh.top[k] = top;
          sh.floor[k] = top;
        }
      }
    }
    return;
  }
}

/** An exotic island's pool, if it got one. */
export const poolOf = (sh) => sh.ponds.find((q) => q.pool);

/**
 * The dock: from the pool's bank straight out into it, 3 wide, a third to a half of the pool's radius long (5 to 9),
 * its deck of spruce planks at the water's level (the bank's), on spruce log pilings down to the bed, a fence post with
 * a lantern on each corner of its far end, and a barrel on the bank beside it. It goes out from the side of the pool the
 * portal is on, so a player coming through sees it, but never within 3 blocks of the portal's frame or its pad (tried
 * in the four directions, nearest the portal first). Returns { axis "x"|"z", dir 1|-1, x, z (the deck's middle on the
 * bank), end (its middle at the far end), len, blocks Map("x,y,z" -> [id, states]) }.
 */
function dockOf(isl, sh, pool) {
  const s = isl.s;
  const y0 = isl.y;
  const L = sh.landing;
  let ax;
  let az;
  if (L) {
    ax = L.x + 0.5 - pool.x;
    az = L.z - pool.z;
  } else {
    const a = unit(hash(s, 81, 0, 1)) * Math.PI * 2;
    ax = Math.cos(a);
    az = Math.sin(a);
  }
  const want = Math.atan2(az, ax);
  const dirs = /** @type {Array<[string, number, number]>} */ ([["x", 1, 0], ["x", -1, Math.PI], ["z", 1, Math.PI / 2], ["z", -1, -Math.PI / 2]]);
  const off = (a) => Math.abs(Math.atan2(Math.sin(a - want), Math.cos(a - want)));
  dirs.sort((p, q) => off(p[2]) - off(q[2]));
  const len = Math.max(5, Math.min(9, Math.round(pool.r * 0.45)));
  // the portal's frame (4 along x, from x-1) and the pad the player steps out onto
  const clear = (x, z) => !L || x < L.x - 4 || x > L.x + 5 || Math.abs(z - L.z) > 3;
  for (const [axis, dir] of dirs) {
    const cell = (along, side) => (axis === "x" ? { x: pool.x + dir * along, z: pool.z + side } : { x: pool.x + side, z: pool.z + dir * along });
    // the bank: the first step out along the line where none of the 3 columns is water
    let bank = 0;
    for (let d = 1; d <= pool.r + POOL_BANK && !bank; d++) {
      if ([-1, 0, 1].every((w) => {
        const c = cell(d, w);
        return sh.kind[at(sh, c.x, c.z)] !== POND;
      })) bank = d;
    }
    if (!bank) continue;
    const end = bank - len;
    const blocks = new Map();
    const put = (x, y, z, id, states) => {
      const k = `${x},${y},${z}`;
      if (!blocks.has(k)) blocks.set(k, [id, states]);
    };
    let ok = true;
    for (let d = bank + 1; d >= end; d--) {
      for (const w of [-1, 0, 1]) {
        const c = cell(d, w);
        const k = at(sh, c.x, c.z);
        if (k < 0 || !clear(c.x, c.z) || (sh.kind[k] !== POND && sh.kind[k] !== LAND)) ok = false;
        if (k < 0) continue;
        put(c.x, y0, c.z, "minecraft:spruce_planks");
        // pilings: under its sides every third step, and its far end, from the deck down to the bed
        if (sh.kind[k] === POND && w !== 0 && (d === end || (bank - d) % 3 === 2)) {
          for (let y = y0 - 1; y > sh.floor[k]; y--) put(c.x, y, c.z, "minecraft:spruce_log");
        }
      }
    }
    for (const w of [-1, 1]) {
      const c = cell(end, w);
      put(c.x, y0 + 1, c.z, "minecraft:spruce_fence");
      put(c.x, y0 + 2, c.z, "minecraft:lantern", { hanging: false });
    }
    const b = cell(bank + 1, 2);
    const kb = at(sh, b.x, b.z);
    if (kb >= 0 && sh.kind[kb] === LAND && clear(b.x, b.z)) put(b.x, sh.top[kb] + 1, b.z, "minecraft:barrel", { facing_direction: 1 });
    const root = cell(bank, 0);
    const dock = { axis, dir, x: root.x, z: root.z, len, end: cell(end, 0), blocks };
    if (ok) return dock;
  }
  return undefined;
}

/** The Weeping Willows (0.1.276): a big one on a trunk 2 wide, and a smaller one; each with its strands hanging. */
export const WILLOWS = Object.freeze({ great: "zoocraft:weeping_willow_great_with_strands", small: "zoocraft:weeping_willow_with_strands" });
/** An exotic island's azalea trees (the game's azalea leaves, one in two flowering). */
export const AZALEAS = Object.freeze(["zoocraft:azalea_round", "zoocraft:azalea_round_flowering"]);

/**
 * How far out a tree's wood can reach from its trunk's middle (its trunk's lean and its branches; its leaves can meet
 * another tree's, but a tree whose trunk or branches would run into another's wood does not grow: 0.1.276 bench, a
 * small willow 12 from a big one did not): a big willow 8, a small one 6, an azalea tree 2.
 */
const REACH = Object.freeze({ 2: 8, 1: 6, 0: 2 });
const middle = (t) => [t.x + (t.w - 1) / 2, t.z + (t.w - 1) / 2];
/**
 * Whether a tree w wide (0 for an azalea tree) at x, z would be too close to any of the trees: their reaches and 1.
 * @param {Array<{x: number, z: number, w: number, azalea?: boolean}>} trees
 */
function crowded(trees, x, z, w) {
  const [mx, mz] = middle({ x, z, w: Math.max(1, w) });
  return trees.some((t) => {
    const [tx, tz] = middle(t);
    return Math.hypot(mx - tx, mz - tz) < REACH[w] + REACH[t.azalea ? 0 : t.w] + 1;
  });
}

/**
 * The places of an exotic island's builds: its dock (out from the bank the portal is on), its ring of Weeping Willows
 * round the pool (5 to 9, at least 4, clear of the dock and the landing), a few azalea trees out on the rest of it and
 * its Diamond Shards, sprinkled over the land (8 and one for every 3 blocks of its radius).
 */
function exoticSites(isl, sh) {
  const s = isl.s;
  const pool = poolOf(sh);
  const offLanding = (x, z, n) => !sh.landing || Math.hypot(x - (sh.landing.x + 0.5), z - sh.landing.z) >= n;
  const trees = [];
  /** columns the trees' trunks take */
  const trunks = new Set();
  if (pool) {
    sh.dock = dockOf(isl, sh, pool);
    const dock = sh.dock;
    // how far a spot is from the dock's line (its deck from the bank out to its end)
    const offDock = (x, z) => {
      const [a0, a1] = dock.axis === "x" ? [Math.min(dock.x, dock.end.x), Math.max(dock.x, dock.end.x)] : [Math.min(dock.z, dock.end.z), Math.max(dock.z, dock.end.z)];
      const along = dock.axis === "x" ? x : z;
      const across = dock.axis === "x" ? z - dock.z : x - dock.x;
      const da = along < a0 ? a0 - along : along > a1 ? along - a1 : 0;
      return Math.hypot(da, across);
    };
    // the ground under a trunk w wide: its lowest top, if it steps by no more than 1 (the higher grass under a big
    // trunk is then taken down to it, so the trunk's foot is clear: 0.1.276 bench, a big willow whose corner stood on
    // the higher grass did not grow)
    const flat = (x, z, w) => {
      let lo = Infinity;
      let hi = -Infinity;
      for (let dz = 0; dz < w; dz++) {
        for (let dx = 0; dx < w; dx++) {
          const k = at(sh, x + dx, z + dz);
          if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 80) return undefined;
          lo = Math.min(lo, sh.top[k]);
          hi = Math.max(hi, sh.top[k]);
        }
      }
      return hi - lo <= 1 ? lo : undefined;
    };
    const ring = [];
    const n = Math.max(5, Math.min(9, Math.round((2 * Math.PI * (pool.r + 5)) / 11)));
    const a0 = unit(hash(s, 70, 0, 1)) * Math.PI * 2;
    // a first ring just off the water, then (if the dock, the landing or the shore took too many) a second, farther out
    for (const [pass, out, count] of [[0, 4, n], [1, 7, n + 2]]) {
      for (let i = 0; i < count; i++) {
        if (pass === 1 && ring.length >= 4) break;
        const a = a0 + ((i + pass * 0.5) * 2 * Math.PI) / count + (unit(hash(s, i, 72 + pass, 1)) - 0.5) * (Math.PI / count) * 0.7;
        const d = pool.r + out + Math.floor(unit(hash(s, i, 72 + pass, 2)) * 2);
        const x = Math.round(pool.x + Math.cos(a) * d);
        const z = Math.round(pool.z + Math.sin(a) * d);
        if (!offLanding(x, z, 9) || offDock(x, z) < 6) continue;
        // a big willow if it was drawn and has room, else a small one, else none
        for (const w of unit(hash(s, i, 72 + pass, 3)) < (isl.r >= 45 ? 0.7 : 0.55) ? [2, 1] : [1]) {
          const top = flat(x, z, w);
          if (top === undefined || nearWater(sh, x, z, 2) || nearWater(sh, x + w - 1, z + w - 1, 2) || crowded(ring, x, z, w)) continue;
          if (w === 2) for (const [dx, dz] of [[0, 0], [1, 0], [0, 1], [1, 1]]) sh.top[at(sh, x + dx, z + dz)] = top;
          ring.push({ id: w === 2 ? WILLOWS.great : WILLOWS.small, x, y: top + 1, z, w });
          break;
        }
      }
    }
    trees.push(...ring);
  }
  for (const t of trees) for (let dz = 0; dz < t.w; dz++) for (let dx = 0; dx < t.w; dx++) trunks.add(at(sh, t.x + dx, t.z + dz));
  // azalea trees out on the rest of the island, away from the pool's willows
  for (let gz = -sh.R; gz <= sh.R; gz += 8) {
    for (let gx = -sh.R; gx <= sh.R; gx += 8) {
      if (unit(hash(s, gx, gz, 75)) >= 0.32) continue;
      const x = isl.x + gx + Math.floor(unit(hash(s, gx, gz, 76)) * 5) - 2;
      const z = isl.z + gz + Math.floor(unit(hash(s, gx, gz, 77)) * 5) - 2;
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 78 || nearWater(sh, x, z, 3)) continue;
      if (pool && Math.hypot(x - pool.x, z - pool.z) < pool.r + 11) continue;
      if (!offLanding(x, z, 10) || crowded(trees, x, z, 0)) continue;
      const id = AZALEAS[unit(hash(s, gx, gz, 78)) < 0.5 ? 0 : 1];
      trees.push({ id, x, y: sh.top[k] + 1, z, w: 1, azalea: true });
      trunks.add(k);
    }
  }
  // 0.1.284: the willows are no longer tree features: they are built block by block (sh.grove, below), where they stood
  sh.trees = trees.filter((t) => t.azalea).map(({ id, x, y, z }) => ({ id, x, y, z }));
  sh.willows = trees.filter((t) => !t.azalea).map(({ id, x, y, z, w }) => ({ id, x, y, z, w }));
  // the Diamond Shards: sprinkled over the land, apart from each other, the trunks, the dock, the landing and the water
  const want = 8 + Math.round(isl.r / 3);
  const spots = [];
  for (let gz = -sh.R; gz <= sh.R; gz += 3) for (let gx = -sh.R; gx <= sh.R; gx += 3) spots.push([gx, gz, unit(hash(s, gx, gz, 85))]);
  spots.sort((p, q) => p[2] - q[2]);
  const dockAt = (x, z) => {
    const d = sh.dock;
    if (!d) return false;
    for (const k of d.blocks.keys()) {
      const [bx, , bz] = k.split(",").map(Number);
      if (Math.abs(bx - x) <= 1 && Math.abs(bz - z) <= 1) return true;
    }
    return false;
  };
  for (const [gx, gz] of spots) {
    if (sh.shards.length >= want) break;
    const x = isl.x + gx + Math.floor(unit(hash(s, gx, gz, 86)) * 3) - 1;
    const z = isl.z + gz + Math.floor(unit(hash(s, gx, gz, 87)) * 3) - 1;
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 90 || trunks.has(k) || nearWater(sh, x, z, 1)) continue;
    if (!offLanding(x, z, 4) || dockAt(x, z) || sh.shards.some((q) => Math.hypot(x - q.x, z - q.z) < 4)) continue;
    if (trees.some((t) => Math.abs(x - t.x - (t.w - 1) / 2) <= t.w && Math.abs(z - t.z - (t.w - 1) / 2) <= t.w)) continue;
    sh.shards.push({ x, y: sh.top[k] + 1, z });
  }
  if (pool) sh.grove = groveOf(isl, sh, pool, trees.filter((t) => !t.azalea));
}

// ---- an exotic island's grove (0.1.284): its willows block by block, its barrels and its little shrine
//
// Austin (14 Nov): "make the willows look more like willows, even if you have to use custom blocks. I want them to be
// very detailed willows as well. there should also be some loot at the exotic items in barrels. Something that hints
// the mythical fishing island should be there as well." The willows were tree features (0.1.276); now each is worked
// out block by block (fishing/willowRules.js) where the feature's trunk stood, so an island's willows are where they
// were. Barrels stand at the feet of up to three of them (the first holds a Gilded Sea Chart), and by the pool is a
// small shrine in the Shark People's style: white quartz, a sea lantern, a gold cap.

/** What fills the grove's barrels (fishing/islands.js CHEST_LOOT). */
export const GROVE_LOOT = Object.freeze({ chart: "willow_chart", barrel: "willow" });
const GROVE_BARREL = "minecraft:barrel";

/**
 * sh.grove = { blocks Map("x,y,z" -> [id, states]) (wood, roots, leaves, barrels, the shrine), decor (the same, put in
 * last: the drapes, the shrine's lantern), chests [{ x, y, z, loot }], shrine { x, y, z } or undefined }.
 */
function groveOf(isl, sh, pool, ring) {
  const s = isl.s;
  const key = (x, y, z) => `${x},${y},${z}`;
  const blocks = new Map();
  const decor = new Map();
  const chests = [];
  const dockTop = new Map();
  for (const k of sh.dock?.blocks.keys() ?? []) {
    const [x, y, z] = k.split(",").map(Number);
    const c = `${x},${z}`;
    if (!dockTop.has(c) || y > dockTop.get(c)) dockTop.set(c, y);
  }
  const L = sh.landing;
  // nothing of the grove near the return portal and its pad, at any height
  const pad = (x, z) => !!L && Math.abs(x - (L.x + 0.5)) <= 5.5 && Math.abs(z - L.z) <= 5;
  /** the lowest free cell of a column: above its ground, its water or the dock */
  const floorY = (x, z) => {
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] === AIR) return undefined;
    const d = dockTop.get(`${x},${z}`);
    return Math.max(sh.top[k], d ?? -Infinity) + 1;
  };
  const free = (x, y, z) => !pad(x, z) && !blocks.has(key(x, y, z)) && !sh.dock?.blocks.has(key(x, y, z));
  const trees = ring.map((t, i) => {
    const great = t.w === 2;
    const mx = t.x + (great ? 0.5 : 0);
    const mz = t.z + (great ? 0.5 : 0);
    const d = Math.hypot(pool.x - mx, pool.z - mz) || 1;
    const cells = willowCells(
      (a, b) => unit(hash(s, a * 977 + i * 131071 + 5, b, 301)),
      great,
      [(pool.x - mx) / d, (pool.z - mz) / d],
      (dx, dz) => {
        const f = floorY(t.x + dx, t.z + dz);
        return f === undefined ? undefined : f - t.y;
      },
      (dx, dz) => isWet(sh, t.x + dx, t.z + dz),
    );
    return { t, cells };
  });
  // the wood of every willow first (a trunk's foot goes down to the ground where the ground is lower), and the roots
  for (const { t, cells } of trees) {
    for (const [dx, dy, dz] of cells.wood) {
      const x = t.x + dx;
      const z = t.z + dz;
      const f = floorY(x, z);
      if (dy === 0) {
        if (f === undefined) continue;
        for (let y = f; y < t.y; y++) if (free(x, y, z)) blocks.set(key(x, y, z), [WILLOW.wood]);
      }
      if ((f === undefined || t.y + dy >= f) && free(x, t.y + dy, z)) blocks.set(key(x, t.y + dy, z), [WILLOW.wood]);
    }
    for (const [dx, dy, dz] of cells.roots) if (free(t.x + dx, t.y + dy, t.z + dz)) blocks.set(key(t.x + dx, t.y + dy, t.z + dz), [WILLOW.roots]);
  }
  // then the leaves, wherever no wood is
  for (const { t, cells } of trees) {
    for (const [dx, dy, dz, catkins] of cells.leaves) {
      const x = t.x + dx;
      const z = t.z + dz;
      const f = floorY(x, z);
      if ((f === undefined || t.y + dy >= f) && free(x, t.y + dy, z)) blocks.set(key(x, t.y + dy, z), [catkins ? WILLOW.catkins : WILLOW.leaves]);
    }
  }
  // the barrels, at the feet of up to three willows, on the side away from the pool
  const picks = trees.map((e, i) => [unit(hash(s, i, 0, 303)), e]).sort((p, q) => p[0] - q[0]).map((p) => p[1]);
  for (const { t } of picks) {
    if (chests.length >= 3) break;
    const g = t.w === 2 ? 0.5 : 0;
    const d = Math.hypot(t.x + g - pool.x, t.z + g - pool.z) || 1;
    const ox = (t.x + g - pool.x) / d;
    const oz = (t.z + g - pool.z) / d;
    for (const [out, side] of [[3, 0], [3, 1], [3, -1], [4, 0], [2, 2], [2, -2], [4, 2], [4, -2]]) {
      const x = Math.round(t.x + g + ox * out - oz * side);
      const z = Math.round(t.z + g + oz * out + ox * side);
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 85 || dockTop.has(`${x},${z}`)) continue;
      const y = sh.top[k] + 1;
      if (!free(x, y, z) || blocks.has(key(x, y + 1, z)) || sh.shards.some((q) => q.x === x && q.z === z)) continue;
      blocks.set(key(x, y, z), [GROVE_BARREL, { facing_direction: 1 }]);
      chests.push({ x, y, z, loot: chests.length ? GROVE_LOOT.barrel : GROVE_LOOT.chart });
      break;
    }
  }
  // the shrine by the pool: a 3 by 3 of quartz slabs, a chiseled quartz block, a sea lantern, a gold cap, a lantern on it
  let shrine;
  const a0 = unit(hash(s, 0, 0, 304)) * Math.PI * 2;
  look: for (const out of [4, 5, 6, 3, 7]) {
    for (let i = 0; i < 32; i++) {
      const a = a0 + (i * Math.PI) / 16;
      const x = Math.round(pool.x + Math.cos(a) * (pool.r + out));
      const z = Math.round(pool.z + Math.sin(a) * (pool.r + out));
      const k = at(sh, x, z);
      if (k < 0) continue;
      const top = sh.top[k];
      let ok = true;
      for (let dz = -1; dz <= 1 && ok; dz++) {
        for (let dx = -1; dx <= 1 && ok; dx++) {
          const c = at(sh, x + dx, z + dz);
          ok = c >= 0 && sh.kind[c] === LAND && sh.top[c] === top && !pad(x + dx, z + dz) && !sh.shards.some((q) => q.x === x + dx && q.z === z + dz);
          for (let y = top + 1; y <= top + 5 && ok; y++) ok = !blocks.has(key(x + dx, y, z + dz));
        }
      }
      for (let dz = -3; dz <= 3 && ok; dz++) for (let dx = -3; dx <= 3 && ok; dx++) ok = !dockTop.has(`${x + dx},${z + dz}`);
      if (!ok || ring.some((t) => Math.hypot(t.x - x, t.z - z) < 5)) continue;
      const y = top + 1;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) blocks.set(key(x + dx, y, z + dz), ["minecraft:smooth_quartz_slab", { "minecraft:vertical_half": "bottom" }]);
      blocks.set(key(x, y, z), ["minecraft:chiseled_quartz_block"]);
      blocks.set(key(x, y + 1, z), ["minecraft:sea_lantern"]);
      blocks.set(key(x, y + 2, z), ["minecraft:gold_block"]);
      decor.set(key(x, y + 3, z), ["minecraft:lantern"]);
      shrine = { x, y, z };
      break look;
    }
  }
  // the drapes last: each column's from its leaf down, stopping at anything in its way; its last block is a tip
  const hang = (x, y, z) => !pad(x, z) && !blocks.has(key(x, y, z)) && !decor.has(key(x, y, z)) && !sh.dock?.blocks.has(key(x, y, z));
  for (const { t, cells } of trees) {
    const cols = new Map();
    for (const [dx, dy, dz] of cells.drapes) {
      const c = `${dx},${dz}`;
      if (!cols.has(c)) cols.set(c, []);
      cols.get(c).push(dy);
    }
    for (const [c, ys] of cols) {
      const [dx, dz] = c.split(",").map(Number);
      const x = t.x + dx;
      const z = t.z + dz;
      ys.sort((p, q) => q - p);
      // (its leaf may have given way to another willow's wood, the pad or the dock: then no drape)
      const over = blocks.get(key(x, t.y + ys[0] + 1, z))?.[0];
      if (over !== WILLOW.leaves && over !== WILLOW.catkins) continue;
      const f = floorY(x, z);
      const put = [];
      for (const dy of ys) {
        const y = t.y + dy;
        if (!hang(x, y, z) || (f !== undefined && y <= f) || !hang(x, y - 1, z)) break;
        put.push(y);
      }
      for (const [j, y] of put.entries()) decor.set(key(x, y, z), [WILLOW.drape, { [DRAPE_TIP]: j === put.length - 1 }]);
    }
  }
  // (a Diamond Shard where a root or a barrel now is gives way)
  sh.shards = sh.shards.filter((q) => !blocks.has(key(q.x, q.y, q.z)));
  return { blocks, decor, chests, shrine };
}

/** The grove's blocks ("blocks") or its drapes and lantern ("decor") as lists, one per block and states, for a replanting. */
export function* groveOps(sh, part) {
  const groups = new Map();
  for (const [k, [id, states]] of sh.grove?.[part] ?? []) {
    const g = `${id}|${states ? JSON.stringify(states) : ""}`;
    if (!groups.has(g)) groups.set(g, { id, states, list: [] });
    const [x, y, z] = k.split(",").map(Number);
    groups.get(g).list.push({ x, y, z });
  }
  for (const g of [...groups.keys()].sort()) {
    const { id, states, list } = groups.get(g);
    for (let i = 0; i < list.length; i += BATCH) yield states ? { block: id, list: list.slice(i, i + BATCH), states } : { block: id, list: list.slice(i, i + BATCH) };
  }
}

/** An exotic island's ground: grass, with patches of moss (none at the water's edge). */
export const EXOTIC_TOPS = Object.freeze(["minecraft:grass_block", "minecraft:moss_block"]);
function exoticTopOf(isl, sh, x, z) {
  if (fbm2((isl.s ^ 0xd) >>> 0, x / 10, z / 10) > 0.22 && !nearWater(sh, x, z, 1)) return "minecraft:moss_block";
  return "minecraft:grass_block";
}
/** An exotic island's flowers: every colour. */
export const EXOTIC_FLOWERS = Object.freeze(["minecraft:allium", "minecraft:azure_bluet", "minecraft:blue_orchid", "minecraft:cornflower", "minecraft:lily_of_the_valley", "minecraft:oxeye_daisy", "minecraft:pink_tulip", "minecraft:red_tulip", "minecraft:white_tulip", "minecraft:orange_tulip", "minecraft:poppy", "minecraft:dandelion"]);
/** Its tall plants, two blocks high (the game's double plants: the lower half, then the upper). */
export const EXOTIC_TALL = Object.freeze(["minecraft:peony", "minecraft:rose_bush", "minecraft:lilac", "minecraft:tall_grass", "minecraft:large_fern"]);
const DIRS4 = Object.freeze(["north", "south", "east", "west"]);

/**
 * One exotic-island column's plant, given its top block: [id, states, tall] or undefined. On grass: short grass, ferns,
 * flowers of every colour, pink petals, tall flowers and grass, the odd firefly bush; on moss: moss carpet and azalea
 * bushes; sugar cane at the water.
 */
function exoticPlantOf(isl, sh, top, x, z, wet) {
  const s = isl.s;
  if (wet && unit(hash(s, x, z, 35)) < 0.3) return ["minecraft:reeds"];
  const u = unit(hash(s, x, z, 31));
  const v = unit(hash(s, x, z, 33));
  if (top === "minecraft:moss_block") {
    if (u < 0.32) return ["minecraft:moss_carpet"];
    if (u < 0.37) return ["minecraft:azalea"];
    if (u < 0.42) return ["minecraft:flowering_azalea"];
    if (u < 0.5) return ["minecraft:short_grass"];
    return undefined;
  }
  if (u < 0.24) return ["minecraft:short_grass"];
  if (u < 0.3) return ["minecraft:fern"];
  if (u < 0.4) return [EXOTIC_FLOWERS[Math.floor(v * EXOTIC_FLOWERS.length)]];
  if (u < 0.44) return ["minecraft:pink_petals", { growth: Math.floor(v * 4), "minecraft:cardinal_direction": DIRS4[Math.floor(unit(hash(s, x, z, 89)) * 4)] }];
  if (u < 0.475) return [EXOTIC_TALL[Math.floor(v * EXOTIC_TALL.length)], undefined, true];
  if (u < 0.485) return ["minecraft:firefly_bush"];
  return undefined;
}

/** The block state a Diamond Shard's face is in (the game's amethyst's). */
const SHARD_FACE = "minecraft:block_face";
/** The crystals of Diamond Shards lying about an exotic island (0.1.276; fishing/diamondRules.js). */
export const DIAMOND_SHARDS = "zoocraft:diamond_shards";

/**
 * An exotic island's plants (0.1.276), its Diamond Shards, its pool's lily pads and seagrass, and the glow berries
 * hanging under it. `pad(x, z)` is the landing's pad; `taken` the dock's cells; `busy` the trees' trunks.
 */
function* exoticPlants(isl, sh, cols, tops, taken, busy, pad, grouped, batches) {
  const s = isl.s;
  const W = sh.W;
  const xOf = (k) => sh.x0 + (k % W);
  const zOf = (k) => sh.z0 + Math.floor(k / W);
  const shardAt = new Set(sh.shards.map((q) => at(sh, q.x, q.z)));
  const plants = new Map();
  for (const k of cols) {
    if ((sh.kind[k] !== LAND && sh.kind[k] !== ROCK) || busy.has(k) || shardAt.has(k)) continue;
    const x = xOf(k);
    const z = zOf(k);
    const y = sh.top[k] + 1;
    if (pad(x, z) || taken.has(`${x},${sh.top[k]},${z}`) || taken.has(`${x},${y},${z}`)) continue;
    const wet = sh.kind[k] === LAND && sh.top[k] === isl.y && (isWet(sh, x + 1, z) || isWet(sh, x - 1, z) || isWet(sh, x, z + 1) || isWet(sh, x, z - 1));
    const p = exoticPlantOf(isl, sh, tops.get(k), x, z, wet);
    if (!p) continue;
    const [id, states, tall] = p;
    if (id === "minecraft:reeds") {
      const n = 1 + Math.floor(unit(hash(s, x, z, 39)) * 3);
      for (let h = 0; h < n && !taken.has(`${x},${y + h},${z}`); h++) plants.set(`${x},${y + h},${z}`, [id]);
    } else if (tall) {
      if (taken.has(`${x},${y + 1},${z}`)) continue;
      plants.set(`${x},${y},${z}`, [id, { upper_block_bit: false }]);
      plants.set(`${x},${y + 1},${z}`, [id, { upper_block_bit: true }]);
    } else plants.set(`${x},${y},${z}`, [id, states]);
  }
  yield* grouped(plants);
  // the Diamond Shards, standing up out of the ground
  for (const op of batches(DIAMOND_SHARDS, sh.shards.map(({ x, y, z }) => ({ x, y, z })))) yield { ...op, states: { [SHARD_FACE]: "up" } };
  // lily pads round the pool's shallow edge, clear of the dock (so its water stays open to fish in)
  const nearDock = (x, z) => {
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) if (taken.has(`${x + dx},${isl.y},${z + dz}`)) return true;
    return false;
  };
  yield* batches("minecraft:waterlily", (function* () {
    for (const k of cols) {
      if (sh.kind[k] !== POND || sh.top[k] - sh.floor[k] > 3 || unit(hash(s, xOf(k), zOf(k), 51)) >= 0.1 || nearDock(xOf(k), zOf(k))) continue;
      yield { x: xOf(k), y: sh.top[k] + 1, z: zOf(k) };
    }
  })());
  // seagrass on the pool's bed, put into its water (put in air, its water would run)
  for (const op of batches("minecraft:seagrass", (function* () {
    for (const k of cols) if (sh.kind[k] === POND && sh.top[k] - sh.floor[k] >= 3 && unit(hash(s, xOf(k), zOf(k), 91)) < 0.3) yield { x: xOf(k), y: sh.floor[k] + 1, z: zOf(k) };
  })())) yield { ...op, into: "minecraft:water" };
  // glow berries hanging under it, 2 to 5 long, one in three with a berry (the lowest one grows no more)
  const vines = new Map();
  for (const k of cols) {
    if (!sh.roots[k]) continue;
    const x = xOf(k);
    const z = zOf(k);
    const n = 2 + Math.floor(unit(hash(s, x, z, 93)) * 4);
    for (let i = 1; i <= n; i++) {
      const berry = unit(hash(s, x, z, 95 + i)) < 0.35;
      const head = i === n;
      const id = berry ? (head ? "minecraft:cave_vines_head_with_berries" : "minecraft:cave_vines_body_with_berries") : "minecraft:cave_vines";
      vines.set(`${x},${sh.bottom[k] - i},${z}`, [id, head ? { growing_plant_age: 25 } : undefined]);
    }
  }
  yield* grouped(vines);
}

export function shapeOf(isl) {
  const sh = newShape(isl);
  for (const _ of shapeSteps(isl, sh));
  return sh;
}

const isWet = (sh, x, z) => sh.kind[at(sh, x, z)] === POND;

function nearWater(sh, x, z, n) {
  for (let dz = -n; dz <= n; dz++) for (let dx = -n; dx <= n; dx++) if (isWet(sh, x + dx, z + dz)) return true;
  return false;
}

/** Where the return portal stands: a flat strip of land 4 long (x) and 3 wide, away from water. */
function landingOf(isl, sh) {
  const a = unit(hash(isl.s, 3, 3, 3)) * Math.PI * 2;
  const cx = Math.round(isl.x + Math.cos(a) * isl.r * 0.45);
  const cz = Math.round(isl.z + Math.sin(a) * isl.r * 0.45);
  const fits = (lx, lz) => {
    let lo = Infinity;
    let hi = -Infinity;
    for (let z = lz - 1; z <= lz + 1; z++) {
      for (let x = lx - 1; x <= lx + 2; x++) {
        const k = at(sh, x, z);
        if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 85) return undefined;
        lo = Math.min(lo, sh.top[k]);
        hi = Math.max(hi, sh.top[k]);
      }
    }
    if (hi - lo > 1 || nearWater(sh, lx, lz, 3) || nearWater(sh, lx + 1, lz, 3)) return undefined;
    return hi;
  };
  for (let ring = 0; ring <= Math.ceil(isl.r * 0.9); ring++) {
    for (let dz = -ring; dz <= ring; dz++) {
      for (let dx = -ring; dx <= ring; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== ring) continue;
        const hi = fits(cx + dx, cz + dz);
        if (hi !== undefined) return { x: cx + dx, z: cz + dz, y: hi + 1, axis: "x" };
      }
    }
  }
  return undefined;
}

/** The trees ZooCraft grows on a common island (its own oak and birch, 0.1.144), and how often. */
export const COMMON_TREES = /** @type {ReadonlyArray<[string, number]>} */ (Object.freeze([
  ["zoocraft:oak_round", 30],
  ["zoocraft:oak_branchy", 25],
  ["zoocraft:oak_tall", 12],
  ["zoocraft:oak_great", 8],
  ["zoocraft:birch_tall", 13],
  ["zoocraft:birch_slim", 12],
]));

function treesOf(isl, sh) {
  const out = [];
  const total = COMMON_TREES.reduce((n, [, w]) => n + w, 0);
  for (let gz = -sh.R; gz <= sh.R; gz += 7) {
    for (let gx = -sh.R; gx <= sh.R; gx += 7) {
      if (unit(hash(isl.s, gx, gz, 23)) >= (isl.kind === "uncommon" ? 0.3 : 0.42)) continue;
      const x = isl.x + gx + Math.floor(unit(hash(isl.s, gx, gz, 21)) * 5) - 2;
      const z = isl.z + gz + Math.floor(unit(hash(isl.s, gx, gz, 22)) * 5) - 2;
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 78 || sh.top[k] !== sh.floor[k] || nearWater(sh, x, z, 3)) continue;
      if (sh.landing && Math.hypot(x - sh.landing.x, z - sh.landing.z) < 10) continue;
      if (sh.sites.some((q) => Math.hypot(x - q.x, z - q.z) < 10) || sh.geodes.some((g) => Math.hypot(x - g.x, z - g.z) < g.R + 6)) continue;
      if (sh.patches.some((q) => Math.hypot(x - q.x, z - q.z) < q.r + 3)) continue;
      let u = unit(hash(isl.s, gx, gz, 25)) * total;
      let id = COMMON_TREES[0][0];
      for (const [t, w] of COMMON_TREES) {
        if (u < w) {
          id = t;
          break;
        }
        u -= w;
      }
      out.push({ id, x, y: sh.top[k] + 1, z });
    }
  }
  // an uncommon island keeps a few trees among its spires (0.1.274): if the first look found too few, a second look,
  // in its own random order over the spots between, a little nearer the spires
  if (isl.kind === "uncommon") {
    const want = isl.r >= 45 ? 3 : 2;
    const spots = [];
    for (let gz = -sh.R + 2; gz <= sh.R; gz += 4) for (let gx = -sh.R + 2; gx <= sh.R; gx += 4) spots.push([gx, gz, unit(hash(isl.s, gx, gz, 121))]);
    spots.sort((a, b) => a[2] - b[2]);
    for (const [gx, gz] of spots) {
      if (out.length >= want) break;
      const x = isl.x + gx;
      const z = isl.z + gz;
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 78 || sh.top[k] !== sh.floor[k] || nearWater(sh, x, z, 3)) continue;
      if (sh.landing && Math.hypot(x - sh.landing.x, z - sh.landing.z) < 10) continue;
      if (sh.sites.some((q) => Math.hypot(x - q.x, z - q.z) < 9) || sh.geodes.some((g) => Math.hypot(x - g.x, z - g.z) < g.R + 6)) continue;
      if (sh.patches.some((q) => Math.hypot(x - q.x, z - q.z) < q.r + 3) || out.some((q) => Math.hypot(x - q.x, z - q.z) < 7)) continue;
      const total = COMMON_TREES.reduce((n, [, w]) => n + w, 0);
      let u = unit(hash(isl.s, gx, gz, 123)) * total;
      let id = COMMON_TREES[0][0];
      for (const [tr, w] of COMMON_TREES) {
        if (u < w) {
          id = tr;
          break;
        }
        u -= w;
      }
      out.push({ id, x, y: sh.top[k] + 1, z });
    }
  }
  return out;
}

// ---- the blocks, in the order they go in

/** A rare island's blocks (0.1.275): its top, its ponds' beds, the gold in its stone and its plants. */
export const RARE_TOPS = Object.freeze(["minecraft:blackstone", "minecraft:crimson_nylium", "minecraft:crying_obsidian", "minecraft:gilded_blackstone"]);
export const RARE_BEDS = Object.freeze(["minecraft:magenta_concrete", "minecraft:purple_concrete", "minecraft:crying_obsidian"]);
/** @type {ReadonlyArray<[string, number, number]>} */
const RARE_VEINS = Object.freeze([["minecraft:gilded_blackstone", 90, 41], ["minecraft:raw_gold_block", 450, 43]]);
export const RARE_PLANTS = Object.freeze(["minecraft:crimson_roots", "minecraft:crimson_fungus"]);
export const FLOWERS = Object.freeze(["minecraft:dandelion", "minecraft:poppy", "minecraft:azure_bluet", "minecraft:oxeye_daisy", "minecraft:cornflower"]);
/** An uncommon island's flowers (0.1.274): purples, blues, pinks and whites to go with the amethyst. */
export const CRYSTAL_FLOWERS = Object.freeze(["minecraft:allium", "minecraft:azure_bluet", "minecraft:cornflower", "minecraft:lily_of_the_valley", "minecraft:pink_tulip", "minecraft:oxeye_daisy"]);

const SETS = {
  purple: { block: "minecraft:amethyst_block", budding: "minecraft:budding_amethyst", stages: ["minecraft:small_amethyst_bud", "minecraft:medium_amethyst_bud", "minecraft:large_amethyst_bud", "minecraft:amethyst_cluster"] },
  red: { block: "zoocraft:red_amethyst_block", budding: "zoocraft:budding_red_amethyst", stages: ["zoocraft:small_red_amethyst_bud", "zoocraft:medium_red_amethyst_bud", "zoocraft:large_red_amethyst_bud", "zoocraft:red_amethyst_cluster"] },
  blue: { block: "zoocraft:blue_amethyst_block", budding: "zoocraft:budding_blue_amethyst", stages: ["zoocraft:small_blue_amethyst_bud", "zoocraft:medium_blue_amethyst_bud", "zoocraft:large_blue_amethyst_bud", "zoocraft:blue_amethyst_cluster"] },
};
const SIDES6 = /** @type {ReadonlyArray<[string, number, number, number]>} */ ([
  ["up", 0, 1, 0],
  ["down", 0, -1, 0],
  ["north", 0, 0, -1],
  ["south", 0, 0, 1],
  ["east", 1, 0, 0],
  ["west", -1, 0, 0],
]);

/** The cells of a leaning, tapering pillar of amethyst (a spire going up from its base, or a crystal hanging down). */
function pillarCells(p) {
  const out = [];
  for (let i = 0; i < p.h; i++) {
    const cx = p.x + p.tx * i;
    const cz = p.z + p.tz * i;
    const ri = Math.max(0.5, p.r0 * (1 - (0.72 * i) / Math.max(1, p.h - 1)));
    const y = p.y + p.dir * i;
    const n = Math.ceil(ri) + 1;
    for (let dz = -n; dz <= n; dz++) {
      for (let dx = -n; dx <= n; dx++) {
        const x = Math.round(cx) + dx;
        const z = Math.round(cz) + dz;
        if (Math.hypot(x - cx, z - cz) <= ri + 0.25) out.push({ x, y, z, end: i === p.h - 1 });
      }
    }
  }
  return out;
}

/**
 * An uncommon island's amethyst, worked out from its shape: the solid blocks (amethyst in its colours, budding
 * amethyst, the geodes' calcite and smooth basalt) and the buds and clusters on them, each growing out into an empty
 * cell from the block it stands on. Returns { solid: Map("x,y,z" -> id), crystals: Map("x,y,z" -> { id, face }) }.
 */
export function amethystOfIsland(isl, sh) {
  const s = isl.s;
  const solid = new Map();
  const crystals = new Map();
  const key = (x, y, z) => `${x},${y},${z}`;
  const empty = (x, y, z) => {
    if (solid.has(key(x, y, z)) || crystals.has(key(x, y, z))) return false;
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] === AIR) return true;
    if (y > sh.top[k]) return true;
    return y < sh.bottom[k] - (sh.roots[k] ? 1 : 0);
  };
  const stageOf = (u) => (u < 0.2 ? 0 : u < 0.4 ? 1 : u < 0.65 ? 2 : 3);
  /** amethyst cells that can grow crystals: the budding ones among them are picked last */
  const faces = [];
  const grow = (x, y, z, colour, chance, salt) => {
    for (const [face, dx, dy, dz] of SIDES6) {
      const nx = x + dx;
      const ny = y + dy;
      const nz = z + dz;
      if (!empty(nx, ny, nz)) continue;
      faces.push([x, y, z, colour]);
      if (unit(hash(s, nx * 7 + dx, ny * 13 + dy, nz * 17 + dz + salt)) >= chance) continue;
      crystals.set(key(nx, ny, nz), { id: SETS[colour].stages[stageOf(unit(hash(s, nx, ny, nz + 101)))], face });
    }
  };
  // the geodes' shells: amethyst inside, then calcite, then smooth basalt, only below the ground (the top is cut off)
  const shells = [];
  for (const g of sh.geodes) {
    const span = g.R + 3;
    for (let y = g.y - span; y <= g.y + span; y++) {
      for (let z = g.z - span; z <= g.z + span; z++) {
        for (let x = g.x - span; x <= g.x + span; x++) {
          const d = Math.hypot(x - g.x, y - g.y, z - g.z);
          if (d < g.R || d >= g.R + 3.2) continue;
          const k = at(sh, x, z);
          if (k < 0 || (sh.kind[k] !== LAND && sh.kind[k] !== GEODE) || y > sh.top[k] || y < sh.bottom[k]) continue;
          const id = d < g.R + 1 ? SETS[g.colour].block : d < g.R + 2 ? "minecraft:calcite" : "minecraft:smooth_basalt";
          solid.set(key(x, y, z), id);
          if (d < g.R + 1) shells.push([x, y, z, g.colour]);
        }
      }
    }
  }
  // spires, hanging crystals, patches in the grass
  const pillars = [];
  for (const p of [...sh.spires, ...sh.hangers]) {
    const cells = pillarCells(p);
    for (const c of cells) solid.set(key(c.x, c.y, c.z), SETS[p.colour].block);
    pillars.push([p, cells]);
  }
  for (const q of sh.patches) {
    const n = Math.ceil(q.r);
    for (let dz = -n; dz <= n; dz++) {
      for (let dx = -n; dx <= n; dx++) {
        if (Math.hypot(dx, dz) > q.r) continue;
        const k = at(sh, q.x + dx, q.z + dz);
        if (k < 0 || sh.kind[k] !== LAND) continue;
        for (let y = sh.top[k] - 1; y <= sh.top[k]; y++) solid.set(key(q.x + dx, y, q.z + dz), SETS[q.colour].block);
      }
    }
  }
  // crystals: a cluster on every spire's top and every hanging crystal's tip, then here and there all over
  for (const [p, cells] of pillars) {
    for (const c of cells) {
      if (!c.end) continue;
      const ny = c.y + p.dir;
      if (empty(c.x, ny, c.z)) crystals.set(key(c.x, ny, c.z), { id: SETS[p.colour].stages[3], face: p.dir > 0 ? "up" : "down" });
    }
  }
  for (const [p, cells] of pillars) for (const c of cells) grow(c.x, c.y, c.z, p.colour, 0.18, 3);
  for (const q of sh.patches) {
    const n = Math.ceil(q.r);
    for (let dz = -n; dz <= n; dz++) {
      for (let dx = -n; dx <= n; dx++) {
        const k = at(sh, q.x + dx, q.z + dz);
        if (k < 0 || !solid.has(key(q.x + dx, sh.top[k], q.z + dz))) continue;
        const x = q.x + dx;
        const z = q.z + dz;
        const y = sh.top[k] + 1;
        if (empty(x, y, z) && unit(hash(s, x, y, z + 103)) < 0.45) crystals.set(key(x, y, z), { id: SETS[q.colour].stages[stageOf(unit(hash(s, x, y, z + 105)))], face: "up" });
      }
    }
  }
  for (const [x, y, z, colour] of shells) grow(x, y, z, colour, 0.3, 5);
  // budding amethyst: one in twelve of the amethyst blocks that face open air (the game's geodes have one in twelve)
  for (const [x, y, z, colour] of faces) {
    const k = key(x, y, z);
    if (solid.get(k) === SETS[colour].block && unit(hash(s, x, y, z + 107)) < 1 / 12) solid.set(k, SETS[colour].budding);
  }
  return { solid, crystals };
}

/**
 * The blocks for the island, as { block, list } with at most BATCH blocks each (a bud or cluster also has `states`,
 * its block_face; an exotic island's double plants, pink petals, lanterns and Diamond Shards theirs), then { tree, at }
 * for each tree. A list with `into` goes only where that block is (its seagrass, into its pool's water), not into air.
 * (0.1.280) `clip(x, z)`, if given: only the blocks and trees there (a part of an island built in parts, partsOf).
 */
export function* opsOf(isl, sh, clip) {
  const W = sh.W;
  const xOf = (k) => sh.x0 + (k % W);
  const zOf = (k) => sh.z0 + Math.floor(k / W);
  const cols = [];
  for (let k = 0; k < sh.kind.length; k++) if (sh.kind[k] !== AIR && (!clip || clip(xOf(k), zOf(k)))) cols.push(k);
  const land = (k) => sh.kind[k] === LAND || sh.kind[k] === ROCK;
  function* batches(block, gen) {
    let list = [];
    for (const p of gen) {
      if (clip && !clip(p.x, p.z)) continue;
      list.push(p);
      if (list.length >= BATCH) {
        yield { block, list };
        list = [];
      }
    }
    if (list.length) yield { block, list };
  }
  const s = isl.s;
  const crystal = isl.kind === "uncommon";
  const rare = isl.kind === "rare";
  const exotic = isl.kind === "exotic";
  const mythic = isl.kind === "mythic";
  const huge = isl.kind === "huge";
  /** a Map("x,y,z" -> [id, states]) as lists, one per block and states, in a fixed order */
  function* grouped(cells) {
    const groups = new Map();
    for (const [k, [id, states]] of cells) {
      const g = `${id}|${states ? JSON.stringify(states) : ""}`;
      if (!groups.has(g)) groups.set(g, { id, states, list: [] });
      const [x, y, z] = k.split(",").map(Number);
      groups.get(g).list.push({ x, y, z });
    }
    for (const g of [...groups.keys()].sort()) {
      const { id, states, list } = /** @type {any} */ (groups.get(g));
      for (const op of batches(id, list)) yield states ? { ...op, states } : op;
    }
  }
  /** the cells the amethyst takes (an uncommon island): no grass, flower, cane or root goes in or on them */
  const taken = new Set();
  if (crystal) {
    const { solid, crystals } = amethystOfIsland(isl, sh);
    for (const k of solid.keys()) taken.add(k);
    for (const k of crystals.keys()) taken.add(k);
    const ids = [...new Set(solid.values())].sort();
    for (const id of ids) {
      yield* batches(id, (function* () {
        for (const [k, v] of solid) {
          if (v !== id) continue;
          const [x, y, z] = k.split(",").map(Number);
          yield { x, y, z };
        }
      })());
    }
    const kinds = [...new Set([...crystals.values()].map((c) => `${c.id} ${c.face}`))].sort();
    for (const kf of kinds) {
      const [id, face] = kf.split(" ");
      for (const op of batches(id, (function* () {
        for (const [k, c] of crystals) {
          if (c.id !== id || c.face !== face) continue;
          const [x, y, z] = k.split(",").map(Number);
          yield { x, y, z };
        }
      })())) yield { ...op, states: { "minecraft:block_face": face } };
    }
  }
  // a rare island's builds (0.1.275): its ruined portals, pillars and fungi, before the ground they stand on
  /** a rare island's top block per column */
  const tops = new Map();
  if (rare) {
    const builds = rareOfIsland(isl, sh);
    for (const k of builds.keys()) taken.add(k);
    for (const id of [...new Set(builds.values())].sort()) {
      yield* batches(id, (function* () {
        for (const [k, v] of builds) {
          if (v !== id) continue;
          const [x, y, z] = k.split(",").map(Number);
          yield { x, y, z };
        }
      })());
    }
    for (const k of cols) if (land(k)) tops.set(k, rareTopOf(isl, sh, k, xOf(k), zOf(k)));
    for (const block of RARE_TOPS) {
      yield* batches(block, (function* () {
        for (const k of cols) if (tops.get(k) === block) yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
      })());
    }
  } else if (exotic) {
    // an exotic island's dock (0.1.276), before the water it stands in and the bank it starts on; then its grass and moss
    if (sh.dock) {
      for (const k of sh.dock.blocks.keys()) taken.add(k);
      yield* grouped(sh.dock.blocks);
    }
    // (0.1.284) its grove: the willows' wood and leaves, the barrels and the shrine; the drapes go in last (decor)
    if (sh.grove) {
      for (const k of sh.grove.blocks.keys()) taken.add(k);
      for (const k of sh.grove.decor.keys()) taken.add(k);
      yield* grouped(sh.grove.blocks);
    }
    for (const k of cols) if (land(k)) tops.set(k, exoticTopOf(isl, sh, xOf(k), zOf(k)));
    for (const block of EXOTIC_TOPS) {
      yield* batches(block, (function* () {
        for (const k of cols) if (tops.get(k) === block) yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
      })());
    }
  } else if (mythic) {
    // a mythic island's town (0.1.277), before the ground it stands on; then its paving, floors, sand and grass
    if (sh.city) {
      for (const k of sh.city.blocks.keys()) taken.add(k);
      for (const k of sh.city.decor.keys()) taken.add(k);
      yield* grouped(sh.city.blocks);
    }
    for (const k of cols) if (land(k)) tops.set(k, mythicTopOf(isl, sh, k));
    // (its sand waits until what holds it up is in: put in first, it fell on the test server)
    for (const block of [...new Set(tops.values())].filter((b) => b !== "minecraft:sand").sort()) {
      yield* batches(block, (function* () {
        for (const k of cols) if (tops.get(k) === block) yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
      })());
    }
  } else if (huge) {
    // a huge island's harbour (0.1.280), before the ground it stands on (and the air in its ships kept dry); then its
    // quay, promenade, floors, paths and grass
    if (sh.harbour) {
      for (const k of sh.harbour.blocks.keys()) taken.add(k);
      for (const k of sh.harbour.decor.keys()) taken.add(k);
      for (const k of sh.harbour.keep) taken.add(k);
      yield* grouped(sh.harbour.blocks);
    }
    for (const k of cols) if (land(k)) tops.set(k, hugeTopOf(isl, sh, k));
    for (const block of [...new Set(tops.values())].sort()) {
      yield* batches(block, (function* () {
        for (const k of cols) if (tops.get(k) === block) yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
      })());
    }
  } else {
    // grass on top
    yield* batches("minecraft:grass_block", (function* () {
      for (const k of cols) if (land(k)) yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
    })());
  }
  // pond beds: sand at the shallow rim, clay and dirt deeper
  const bed = (k) => {
    const x = xOf(k);
    const z = zOf(k);
    if (sh.top[k] - sh.floor[k] <= 1) return "minecraft:sand";
    return noise2((s ^ 0x8) >>> 0, x / 3, z / 3) > 0.25 ? "minecraft:clay" : "minecraft:dirt";
  };
  // (a rare island's: magenta and purple, so its water reads purple)
  // (a mythic island's go in after its stone: mythicSand)
  const bedOf = rare ? (k) => rareBedOf(isl, xOf(k), zOf(k)) : mythic ? (k) => mythicBedOf(isl, sh, k) : bed;
  // (a huge island's harbour bed goes in after its stone too: harbourBed)
  for (const block of rare ? RARE_BEDS : mythic || huge ? [] : ["minecraft:sand", "minecraft:clay", "minecraft:dirt"]) {
    yield* batches(block, (function* () {
      for (const k of cols) if (sh.kind[k] === POND && bedOf(k) === block) yield { x: xOf(k), y: sh.floor[k], z: zOf(k) };
    })());
  }
  // the water (round an exotic island's dock and its pilings, 0.1.276)
  yield* batches("minecraft:water", (function* () {
    for (const k of cols) {
      if (sh.kind[k] !== POND) continue;
      for (let y = sh.floor[k] + 1; y <= sh.top[k]; y++) if (!taken.size || !taken.has(`${xOf(k)},${y},${zOf(k)}`)) yield { x: xOf(k), y, z: zOf(k) };
    }
  })());
  // dirt under the grass and the beds (a rare island's: blackstone)
  // (a mythic island's beach and plaza: sandstone under them, 0.1.277)
  if (mythic) {
    yield* batches("minecraft:sandstone", (function* () {
      for (const k of cols) {
        if (!mythicBeach(isl, sh, k)) continue;
        const f = sh.floor[k];
        for (let y = f - 1; y >= Math.max(sh.bottom[k], f - 3); y--) yield { x: xOf(k), y, z: zOf(k) };
      }
    })());
  }
  yield* batches(rare ? "minecraft:blackstone" : "minecraft:dirt", (function* () {
    for (const k of cols) {
      const f = sh.floor[k];
      for (let y = f - 1; y >= Math.max(sh.bottom[k], f - 3); y--) yield { x: xOf(k), y, z: zOf(k) };
    }
  })());
  // rooted dirt where roots hang (a rare island's vines hang from blackstone, an exotic island's glow berries from moss)
  yield* batches(rare ? "minecraft:blackstone" : exotic ? "minecraft:moss_block" : "minecraft:dirt_with_roots", (function* () {
    for (const k of cols) if (sh.roots[k]) yield { x: xOf(k), y: sh.bottom[k], z: zOf(k) };
  })());
  // ore in the stone: coal veins and fewer iron ones
  // (0.1.280: from every land column, not only the part being built's, so a huge island built a quarter at a time has the
  // same veins as the whole; with no part, the very same list as before)
  const landCols = [];
  for (let k = 0; k < sh.kind.length; k++) if (sh.kind[k] === LAND) landCols.push(k);
  /** @type {ReadonlyArray<[string, number, number]>} */
  const veins = rare ? RARE_VEINS : [["minecraft:coal_ore", 110, 41], ["minecraft:iron_ore", 300, 43]];
  for (const [block, per, salt] of veins) {
    yield* batches(block, (function* () {
      const n = Math.round(landCols.length / per);
      for (let v = 0; v < n && landCols.length; v++) {
        const k = landCols[Math.floor(unit(hash(s, v, salt, 45)) * landCols.length)];
        const lo = sh.bottom[k] + (sh.roots[k] ? 1 : 0);
        const hi = sh.floor[k] - 4;
        if (hi < lo) continue;
        const y = lo + Math.floor(unit(hash(s, v, salt, 47)) * (hi - lo + 1));
        const size = 3 + Math.floor(unit(hash(s, v, salt, 49)) * 4);
        const x0 = xOf(k);
        const z0 = zOf(k);
        for (let b = 0; b < size; b++) {
          const x = x0 + (b % 2);
          const z = z0 + (Math.floor(b / 2) % 2);
          const yy = y + Math.floor(b / 4);
          const kk = at(sh, x, z);
          if (kk < 0 || sh.kind[kk] !== LAND) continue;
          if (yy < sh.bottom[kk] + (sh.roots[kk] ? 1 : 0) || yy > sh.floor[kk] - 4) continue;
          yield { x, y: yy, z };
        }
      }
    })());
  }
  // stone for the rest of the body (anything already placed above is kept: the fills only fill air)
  if (rare) {
    // crying obsidian here and there on the underside, weeping its purple drops (0.1.275)
    yield* batches("minecraft:crying_obsidian", (function* () {
      for (const k of cols) if (sh.kind[k] === LAND && !sh.roots[k] && unit(hash(s, xOf(k), zOf(k), 227)) < 0.025) yield { x: xOf(k), y: sh.bottom[k], z: zOf(k) };
    })());
    // blackstone, with columns of basalt through it; marked `body`, so the builder puts the ponds' water in after it
    const bodyOf = (k) => (noise2((s ^ 0xb) >>> 0, xOf(k) / 9, zOf(k) / 9) > 0.25 ? "minecraft:basalt" : "minecraft:blackstone");
    for (const block of ["minecraft:blackstone", "minecraft:basalt"]) {
      for (const op of batches(block, (function* () {
        for (const k of cols) {
          if (bodyOf(k) !== block) continue;
          const lo = sh.bottom[k] + (sh.roots[k] ? 1 : 0);
          for (let y = sh.floor[k] - 4; y >= lo; y--) yield { x: xOf(k), y, z: zOf(k) };
        }
      })())) yield { ...op, body: true };
    }
  } else {
    yield* batches("minecraft:stone", (function* () {
      for (const k of cols) {
        const lo = sh.bottom[k] + (sh.roots[k] ? 1 : 0);
        for (let y = sh.floor[k] - 4; y >= lo; y--) yield { x: xOf(k), y, z: zOf(k) };
      }
    })());
  }
  // (0.1.277) a mythic island's sand, on its beach and its sea's bed, and the sea lanterns under its lagoon, once what
  // holds them up is in (on the test server, sand put in first fell); marked `body`, so the water goes in after them
  if (mythic) for (const op of mythicSand(isl, sh, cols, tops, batches)) yield { ...op, body: true };
  if (huge) for (const op of harbourBed(isl, sh, cols, batches)) yield { ...op, body: true };
  // plants: grass and flowers, sugar cane at the water, lily pads on it, roots under
  const busy = new Set();
  for (const t of sh.trees) {
    // (an exotic island's big willows stand on a trunk 2 wide)
    const w = t.id === WILLOWS.great ? 2 : 1;
    for (let dz = 0; dz < w; dz++) for (let dx = 0; dx < w; dx++) busy.add(at(sh, t.x + dx, t.z + dz));
  }
  const pad = (x, z) => sh.landing && x >= sh.landing.x - 3 && x <= sh.landing.x + 4 && Math.abs(z - sh.landing.z) <= 2;
  const flowers = crystal ? CRYSTAL_FLOWERS : FLOWERS;
  const plantOf = (k) => {
    // (an exotic island's plants are its own: exoticPlants)
    if (exotic || mythic || !land(k) || busy.has(k)) return undefined;
    // (a huge island's plants only on its grass, not its quay, paving and floors)
    if (huge && tops.get(k) !== "minecraft:grass_block") return undefined;
    const x = xOf(k);
    const z = zOf(k);
    if (pad(x, z)) return undefined;
    if (crystal && sh.geodes.some((g) => Math.hypot(x - g.x, z - g.z) < g.R + 3.5)) return undefined;
    if (taken.size && (taken.has(`${x},${sh.top[k]},${z}`) || taken.has(`${x},${sh.top[k] + 1},${z}`))) return undefined;
    if (rare) {
      // crimson roots and the odd fungus, on the nylium only
      if (tops.get(k) !== "minecraft:crimson_nylium") return undefined;
      const v = unit(hash(s, x, z, 31));
      return v < 0.3 ? "minecraft:crimson_roots" : v < 0.36 ? "minecraft:crimson_fungus" : undefined;
    }
    const wet = sh.kind[k] === LAND && sh.top[k] === isl.y && (isWet(sh, x + 1, z) || isWet(sh, x - 1, z) || isWet(sh, x, z + 1) || isWet(sh, x, z - 1));
    if (wet && unit(hash(s, x, z, 35)) < 0.3) return "minecraft:reeds";
    const u = unit(hash(s, x, z, 31));
    if (u < 0.28) return "minecraft:short_grass";
    if (u < 0.31) return flowers[Math.floor(unit(hash(s, x, z, 33)) * flowers.length)];
    return undefined;
  };
  for (const block of exotic || mythic ? [] : rare ? RARE_PLANTS : ["minecraft:short_grass", ...flowers]) {
    yield* batches(block, (function* () {
      for (const k of cols) if (plantOf(k) === block) yield { x: xOf(k), y: sh.top[k] + 1, z: zOf(k) };
    })());
  }
  if (exotic) yield* exoticPlants(isl, sh, cols, tops, taken, busy, pad, grouped, batches);
  if (exotic && sh.grove) yield* grouped(sh.grove.decor);
  if (mythic) {
    yield* mythicPlants(isl, sh, cols, tops, taken, pad, grouped, batches);
    // its lanterns and carpets last, once what they stand on is in (0.1.277: put in first, some fell off on the test server)
    // (0.1.285: and of those, the beds' feet after everything else: a foot put in before its head turns into a head)
    if (sh.city) {
      const rest = new Map();
      const feet = new Map();
      for (const [k, v] of sh.city.decor) (v[0] === BED && v[1]?.head_piece_bit === false ? feet : rest).set(k, v);
      yield* grouped(rest);
      yield* grouped(feet);
    }
  }
  // a huge island's lanterns, chains, ladders and bell last, once what holds them is in (0.1.280)
  if (huge && sh.harbour) yield* grouped(sh.harbour.decor);
  yield* batches("minecraft:reeds", (function* () {
    for (const k of cols) {
      if (plantOf(k) !== "minecraft:reeds") continue;
      const tall = 1 + Math.floor(unit(hash(s, xOf(k), zOf(k), 39)) * 3);
      for (let h = 1; h <= tall; h++) {
        if (taken.has(`${xOf(k)},${sh.top[k] + h},${zOf(k)}`)) break;
        yield { x: xOf(k), y: sh.top[k] + h, z: zOf(k) };
      }
    }
  })());
  if (rare) {
    // weeping vines, 2 to 6 long, where a common island has hanging roots
    yield* batches("minecraft:weeping_vines", (function* () {
      for (const k of cols) {
        if (!sh.roots[k]) continue;
        const n = 2 + Math.floor(unit(hash(s, xOf(k), zOf(k), 229)) * 5);
        for (let i = 1; i <= n; i++) yield { x: xOf(k), y: sh.bottom[k] - i, z: zOf(k) };
      }
    })());
  } else if (!exotic) {
    // (no lily pads on a mythic island's sea and lagoon, 0.1.277, nor in a huge island's harbour, 0.1.280)
    if (!mythic && !huge) yield* batches("minecraft:waterlily", (function* () {
      for (const k of cols) if (sh.kind[k] === POND && unit(hash(s, xOf(k), zOf(k), 51)) < 0.06) yield { x: xOf(k), y: sh.top[k] + 1, z: zOf(k) };
    })());
    yield* batches("minecraft:hanging_roots", (function* () {
      for (const k of cols) if (sh.roots[k] && !taken.has(`${xOf(k)},${sh.bottom[k]},${zOf(k)}`) && !taken.has(`${xOf(k)},${sh.bottom[k] - 1},${zOf(k)}`)) yield { x: xOf(k), y: sh.bottom[k] - 1, z: zOf(k) };
    })());
  }
  if (huge) yield* harbourSeagrass(isl, sh, cols, taken, batches);
  for (const t of sh.trees) if (!clip || clip(t.x, t.z)) yield { tree: t.id, at: { x: t.x, y: t.y, z: t.z } };
}

// ---- a mythic island: the Shark People's town (0.1.277)
//
// Austin (12 Nov 18:45Z): "super rare, advanced fishing civilization of Shark People that speak, passive, friendlier
// look; city like his picture, smaller". His picture (research/Mythic_island_reference.png) is a ring city round a
// lagoon: white walls and towers with gold domes, a golden gate with blue banners facing the sea, a causeway out to it
// over clear water, a palace with a great gold dome at the back, palms, and sailboats on the sea round it. Here it is at
// the game's own detail (Austin: "This is minecraft remember"), smaller, on a floating island like the others:
// - the lagoon in the middle (a quarter of the island's radius), with a quay round it, three piers and a gold-topped
//   column in its middle;
// - the town round it: houses of white quartz, concrete and sandstone, square ones and round towers, each with a gold
//   or blue dome; paved streets; palms and flowering azaleas on the grass; the palace at the back, facing the lagoon;
// - its wall: quartz, 6 high, with towers capped in gold domes, and the gatehouse with its golden arch, blue banners
//   and two domed towers;
// - a ring of sea round the wall, a beach round that, and a causeway from the gate across the sea to a round plaza on
//   the beach, a wide band of prismarine and sea lanterns under the water either side of it (the picture's sunken road);
// - sailboats on the sea and in the lagoon; coral, seagrass and sand on the sea bed.
// The town's people come in the next version. Everything is worked out from the island's own seed, so every world's
// town differs (its gate faces one of four ways; its houses, towers, palms and boats fall differently).

/** A mythic island's radius: a town smaller than the huge islands its region could hold (Austin: "smaller"). */
export const MYTHIC_RADIUS = Object.freeze([64, 72]); // 0.1.285: was 46 to 56 (Austin: "If we have to make it bigger to do that, that is fine")

const GATE_DIRS = Object.freeze([[0, 1], [1, 0], [0, -1], [-1, 0]]);

/**
 * The town's plan from its island: the lagoon's radius L, the quay's outer edge Q, the wall's middle Wr, the way the
 * gate faces (gx gz), the town's ground level G (one over the water) and the plaza on the beach outside the gate.
 */
export function cityOf(isl) {
  // (0.1.285: the lagoon a little smaller and the wall farther out, so the town between them is twice as wide)
  const L = Math.round(isl.r * 0.19);
  const Wr = Math.round(isl.r * 0.7);
  const [gx, gz] = GATE_DIRS[Math.floor(unit(hash(isl.s, 5, 1, 7)) * 4)];
  const pu = isl.r - 4;
  return { L, Q: L + 3, Wr, gx, gz, G: isl.y + 1, plaza: { u: pu, x: isl.x + gx * pu, z: isl.z + gz * pu, r: 6 } };
}

/** A mythic island's body: round, its edge barely wavy; the lagoon, the town, the sea round it, the beach. */
function* mythicBody(isl, sh, depth) {
  const { r, y: y0, s } = isl;
  const { L, Wr, G, plaza } = cityOf(isl);
  for (let j = 0; j < sh.W; j++) {
    const z = sh.z0 + j;
    for (let i = 0; i < sh.W; i++) {
      const x = sh.x0 + i;
      const dx = x - isl.x;
      const dz = z - isl.z;
      const d = Math.hypot(dx, dz);
      const ang = Math.atan2(dz, dx);
      const re = r * (0.97 + 0.03 * fbm2((s ^ 0x1) >>> 0, 3 + 2 * Math.cos(ang), 3 + 2 * Math.sin(ang)));
      const onPlaza = Math.hypot(x - plaza.x, z - plaza.z) <= plaza.r + 0.5;
      if (d >= re && !onPlaza) continue;
      const t = Math.min(1, d / re);
      const k = j * sh.W + i;
      let kind = LAND;
      let top = G;
      let floor = G;
      if (d < L) {
        // the lagoon: 2 deep at its edge, 5 in its middle
        const q = d / L;
        kind = POND;
        top = y0;
        floor = y0 - (2 + Math.round(3 * (1 - q * q)));
      } else if (d >= Wr + 1 && d < re - 3 && !onPlaza) {
        // the sea round the wall: 3 deep at its sides, 5 in its middle
        const q = (d - (Wr + 1)) / Math.max(1, re - 3 - (Wr + 1));
        kind = POND;
        top = y0;
        floor = y0 - 3 - Math.round(2 * Math.sin(Math.PI * Math.min(1, q)));
      }
      const under = depth * Math.pow(Math.max(0, 1 - t * t), 0.7) * (0.75 + 0.35 * noise2((s ^ 0x4) >>> 0, x / 12, z / 12));
      let drip = 0;
      if (t < 0.85) {
        const q = noise2((s ^ 0x5) >>> 0, x / 5, z / 5);
        if (q > 0.5) drip = (q - 0.5) * 2 * depth * 0.35 * (1 - t);
      }
      let bottom = Math.min(floor - 2, G - 2 - Math.round(under + drip));
      // deep enough under the beach, the plaza and the lagoon's quay that the water beside them stays in
      if (d >= Wr || d < L + 3) bottom = Math.min(bottom, y0 - 7);
      sh.kind[k] = kind;
      sh.top[k] = top;
      sh.floor[k] = floor;
      sh.bottom[k] = bottom;
      sh.edge[k] = Math.min(100, Math.round(t * 100));
    }
    yield;
  }
}

/**
 * Where a return portal would stand: on the plaza, to its outer side. (No portal opens onto a mythic island, arrivalIsland,
 * so this only keeps the plaza clear of plants; a later version could use it.)
 */
function mythicLanding(isl) {
  const { gz, G, plaza } = cityOf(isl);
  return { x: plaza.x - 1, z: plaza.z + (gz !== 0 ? gz * 3 : 3), y: G + 1, axis: "x" };
}

const GOLD = "minecraft:gold_block";
const BLUE_DOME = "minecraft:light_blue_concrete";
const QB = "minecraft:quartz_bricks";
const SQ = "minecraft:smooth_quartz";
const PILLAR = "minecraft:quartz_pillar";
const LANTERN = "minecraft:lantern";
const SEA_LANTERN = "minecraft:sea_lantern";
const SAND_TILE = "minecraft:smooth_sandstone";
const SAND_EDGE = "minecraft:cut_sandstone";
const WOOD = "minecraft:spruce_planks";
const LEAVES = Object.freeze({ persistent_bit: true, update_bit: false });
const BED = "minecraft:bed";
/**
 * A bed's `direction`, by the way its head lies from its foot (0.1.285, found on the test server: 0 is south). The
 * head goes in first: a foot put in alone turns into a head, and the pair comes out the wrong way round or in half.
 */
const BED_DIR = Object.freeze({ south: 0, west: 1, north: 2, east: 3 });
/** What goes into a mythic town last, once what holds it is in: lamps, carpets, ladders, beds, table tops. */
export const MYTHIC_DECOR = Object.freeze([LANTERN, "minecraft:blue_carpet", "minecraft:light_blue_carpet", "minecraft:white_carpet", "minecraft:ladder", BED, "minecraft:spruce_trapdoor"]);
/** A house's walls. */
export const HOUSE_WALLS = Object.freeze([SQ, QB, "minecraft:white_concrete", SAND_TILE]);
/** The coral blocks on the sea's bed (each living as long as water touches it). */
export const CORAL_BLOCKS = Object.freeze(["minecraft:tube_coral_block", "minecraft:brain_coral_block", "minecraft:bubble_coral_block", "minecraft:fire_coral_block", "minecraft:horn_coral_block"]);

/**
 * The town's blocks: sh.city = { blocks Map("x,y,z" -> [id, states]) (they go in first, so nothing else is put where
 * they are), tops Map(column -> the block on top: paving, plank floors), spots (for the town's people: each house's
 * door and the door's step outside, the palace's door, the plaza, the lagoon's middle), houses, towers, boats, palms }.
 * A generator, so the game spreads the work over ticks.
 */
function* mythicSites(isl, sh) {
  const c = cityOf(isl);
  const { L, Q, Wr, gx, gz, G, plaza } = c;
  const s = isl.s;
  const y0 = isl.y;
  const cx = isl.x;
  const cz = isl.z;
  const FOOT = y0 - 5;
  const B = new Map();
  const T = new Map();
  const key = (x, y, z) => `${x},${y},${z}`;
  const set = (x, y, z, id, states) => B.set(key(x, y, z), states ? [id, states] : [id]);
  const del = (x, y, z) => B.delete(key(x, y, z));
  const has = (x, y, z) => B.has(key(x, y, z));
  // the gate's frame: u out from the middle toward the gate, v across it
  const W = (u, v) => [cx + u * gx - v * gz, cz + u * gz + v * gx];
  const U = (x, z) => (x - cx) * gx + (z - cz) * gz;
  const V = (x, z) => -(x - cx) * gz + (z - cz) * gx;
  const setUV = (u, y, v, id, states) => {
    const [x, z] = W(u, v);
    set(x, y, z, id, states);
  };
  const delUV = (u, y, v) => {
    const [x, z] = W(u, v);
    del(x, y, z);
  };
  const tile = (x, z, id) => {
    const k = at(sh, x, z);
    if (k >= 0 && sh.kind[k] === LAND) T.set(k, id);
  };
  const dist = (x, z) => Math.hypot(x - cx, z - cz);
  const roundCells = (R) => {
    const out = [];
    const n = Math.ceil(R);
    for (let dz = -n; dz <= n; dz++) for (let dx = -n; dx <= n; dx++) if (Math.hypot(dx, dz) <= R) out.push([dx, dz, Math.hypot(dx, dz)]);
    return out;
  };
  const towers = [];
  const domes = [];
  /** a dome of `id` on base level `base` over x z, radius R, only its shell; an end rod on its tip */
  function dome(x0, z0, base, R, id) {
    const H = R + 1;
    const rad = (i) => (i > H ? -1 : (R + 0.35) * Math.sqrt(Math.max(0, 1 - (i / (H + 0.2)) ** 2)));
    for (let i = 0; i <= H; i++) {
      const rr = rad(i);
      const next = rad(i + 1);
      for (const [dx, dz, d] of roundCells(rr)) if (d > next || d > rr - 1) set(x0 + dx, base + i, z0 + dz, id);
    }
    set(x0, base + H + 1, z0, "minecraft:end_rod", { facing_direction: 1 });
    domes.push({ x: x0, z: z0, base, R, id, tip: base + H + 1 });
  }
  /** a round tower, radius R, from `foot` up to `top`: quartz with a band of chiseled quartz, a smooth top, a dome */
  function tower(x0, z0, R, foot, top, domeId) {
    const cells = roundCells(R + 0.3);
    for (const [dx, dz, d] of cells) {
      for (let y = foot; y <= top; y++) set(x0 + dx, y, z0 + dz, y === top ? SQ : y === top - 2 && d > R - 0.7 ? "minecraft:chiseled_quartz_block" : QB);
    }
    dome(x0, z0, top + 1, R, domeId);
    towers.push({ x: x0, z: z0, R, top });
  }

  // ---- the wall: 2 thick, from under the water to 6 over the town, a walk on top, battlements outside, lanterns inside
  const ring = Math.ceil(Wr + 1);
  for (let z = cz - ring; z <= cz + ring; z++) {
    for (let x = cx - ring; x <= cx + ring; x++) {
      const d = dist(x, z);
      if (d < Wr - 1 || d >= Wr + 1) continue;
      for (let y = FOOT; y <= G + 5; y++) set(x, y, z, QB);
      set(x, G + 6, z, SQ);
      const step = Math.round(Math.atan2(z - cz, x - cx) * (Wr + 1));
      if (d >= Wr && (step & 1) === 0) set(x, G + 7, z, QB);
      if (d < Wr && ((step % 9) + 9) % 9 === 0) set(x, G + 7, z, LANTERN, { hanging: false });
    }
  }
  yield;
  // its towers, evenly round it (none where the gatehouse stands)
  const ag = Math.atan2(gz, gx);
  const nT = Math.max(6, Math.round((2 * Math.PI * Wr) / 20));
  const a0 = (unit(hash(s, 5, 2, 7)) * Math.PI * 2) / nT;
  for (let i = 0; i < nT; i++) {
    const a = a0 + (i * 2 * Math.PI) / nT;
    const off = Math.abs(Math.atan2(Math.sin(a - ag), Math.cos(a - ag)));
    if (off * Wr < 12) continue;
    tower(Math.round(cx + Math.cos(a) * Wr), Math.round(cz + Math.sin(a) * Wr), 2, FOOT, G + 9, GOLD);
  }
  yield;

  // ---- the gatehouse: 13 wide, 5 deep, 8 high; a gold-framed arch through it; blue banners; two domed towers
  const gu0 = Wr - 2;
  const gu1 = Wr + 2;
  for (let u = gu0; u <= gu1; u++) {
    for (let v = -6; v <= 6; v++) {
      for (let y = FOOT; y <= G + 7; y++) setUV(u, y, v, QB);
      setUV(u, G + 8, v, SQ);
      if ((u === gu0 || u === gu1) && (v & 1) === 0) setUV(u, G + 9, v, QB);
    }
  }
  for (const sv of [-6, 6]) {
    const [tx, tz] = W(Wr, sv);
    tower(tx, tz, 2, FOOT, G + 11, GOLD);
  }
  for (let u = gu0 - 1; u <= gu1; u++) {
    for (let v = -1; v <= 1; v++) {
      for (let y = G + 1; y <= G + 4; y++) delUV(u, y, v);
      setUV(u, G, v, SAND_TILE);
    }
    delUV(u, G + 5, 0);
  }
  for (const fu of [gu0, gu1]) {
    for (let y = G + 1; y <= G + 5; y++) {
      setUV(fu, y, -2, GOLD);
      setUV(fu, y, 2, GOLD);
    }
    for (const v of [-1, 1]) setUV(fu, G + 5, v, GOLD);
    for (const v of [-1, 0, 1]) setUV(fu, G + 6, v, GOLD);
    setUV(fu, G + 7, 0, "minecraft:lapis_block");
    // the banners, flush in its faces: blue, hung from a gold rod
    for (const v of [-4, 4]) {
      for (let y = G + 2; y <= G + 6; y++) setUV(fu, y, v, "minecraft:blue_wool");
      setUV(fu, G + 7, v, GOLD);
    }
  }
  yield;

  // ---- the plaza on the beach, and the causeway from it to the gate, its sunken band under the water either side
  const pr = plaza.r;
  for (let dz = -pr; dz <= pr; dz++) {
    for (let dx = -pr; dx <= pr; dx++) {
      const d = Math.hypot(dx, dz);
      if (d > pr + 0.5) continue;
      tile(plaza.x + dx, plaza.z + dz, d > pr - 1.2 ? SAND_EDGE : d < 1.5 ? "minecraft:chiseled_sandstone" : SAND_TILE);
    }
  }
  for (const [pu, pv] of [[-4, -4], [-4, 4], [4, -4], [4, 4]]) {
    setUV(plaza.u + pu, G + 1, pv, PILLAR);
    setUV(plaza.u + pu, G + 2, pv, LANTERN, { hanging: false });
  }
  for (let u = gu1 + 1; u <= plaza.u; u++) {
    const n = u - gu1;
    for (let v = -2; v <= 2; v++) {
      const [x, z] = W(u, v);
      const k = at(sh, x, z);
      if (k < 0) continue;
      set(x, G, z, Math.abs(v) === 1 ? QB : v === 0 && n % 4 === 0 ? SEA_LANTERN : SQ);
      if (sh.kind[k] === POND) for (let y = sh.floor[k] + 1; y < G; y++) set(x, y, z, "minecraft:prismarine_bricks");
    }
    if (n % 6 === 3 && u < plaza.u - pr) {
      for (const v of [-2, 2]) {
        setUV(u, G + 1, v, PILLAR);
        setUV(u, G + 2, v, LANTERN, { hanging: false });
      }
    }
    for (const v of [-4, -3, 3, 4]) {
      const [x, z] = W(u, v);
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== POND) continue;
      set(x, y0 - 1, z, Math.abs(v) === 4 && n % 4 === 2 ? SEA_LANTERN : "minecraft:dark_prismarine");
      for (let y = sh.floor[k] + 1; y < y0 - 1; y++) set(x, y, z, "minecraft:prismarine");
    }
  }
  yield;

  // ---- the lagoon's quay (white down into the water), the promenade round it, its lanterns
  const qr = Math.ceil(Q);
  for (let z = cz - qr; z <= cz + qr; z++) {
    for (let x = cx - qr; x <= cx + qr; x++) {
      const d = dist(x, z);
      if (d < L || d >= Q) continue;
      tile(x, z, d < L + 1 ? SAND_EDGE : SAND_TILE);
      if (d < L + 1.2) for (let y = y0 - 6; y < G; y++) set(x, y, z, QB);
    }
  }
  const nq = Math.max(6, Math.round((2 * Math.PI * (Q - 0.5)) / 9));
  for (let i = 0; i < nq; i++) {
    const a = ag + ((i + 0.5) * 2 * Math.PI) / nq;
    const x = Math.round(cx + Math.cos(a) * (Q - 1));
    const z = Math.round(cz + Math.sin(a) * (Q - 1));
    set(x, G + 1, z, PILLAR);
    set(x, G + 2, z, LANTERN, { hanging: false });
  }
  // the avenue from the gate to the quay, the street inside the wall, the palace's forecourt
  for (let u = Q; u <= gu0 - 1; u++) {
    for (let v = -2; v <= 2; v++) {
      const [x, z] = W(u, v);
      tile(x, z, v === 0 ? "minecraft:chiseled_sandstone" : Math.abs(v) === 2 ? SAND_EDGE : SAND_TILE);
    }
    if ((u - Q) % 5 === 2) {
      for (const v of [-3, 3]) {
        setUV(u, G + 1, v, PILLAR);
        setUV(u, G + 2, v, LANTERN, { hanging: false });
      }
    }
  }
  for (let z = cz - ring; z <= cz + ring; z++) {
    for (let x = cx - ring; x <= cx + ring; x++) {
      const d = dist(x, z);
      if (d >= Wr - 3 && d < Wr - 1) tile(x, z, SAND_TILE);
    }
  }
  yield;

  // ---- (0.1.285) the town's buildings. Austin, 14 Nov: "the village needs to be much more detailed, especially the
  // buildings. They need an interior so it looks like people live there. If we have to make it bigger to do that, that
  // is fine. I want the homes to look like the ones in the image". So the island is bigger, and every building has
  // rooms: floors, furniture, beds, ladders between storeys, lamps; outside, columns, porches, balconies, parapets and
  // domes on drums, as in his picture.
  /** a frame at ox oz facing fx fz: `a` to its right, `b` forward */
  const frame = (ox, oz, fx, fz) => {
    const rx = -fz;
    const rz = fx;
    const at2 = (a, b) => [ox + a * rx + b * fx, oz + a * rz + b * fz];
    const card = (da, db) => CARD(da * rx + db * fx, da * rz + db * fz);
    const put = (a, y, b, id, st) => {
      const [x, z] = at2(a, b);
      set(x, y, z, id, st);
    };
    return {
      at: at2,
      card,
      put,
      cut: (a, y, b) => {
        const [x, z] = at2(a, b);
        del(x, y, z);
      },
      pave: (a, b, id) => {
        const [x, z] = at2(a, b);
        tile(x, z, id);
      },
      // furniture: a chair's seat faces da db; a bed's head is da db from its foot; a ladder faces da db (the wall is
      // behind it); a thing with a front (smoker, chest, lectern) faces da db
      chair: (a, y, b, da, db) => put(a, y, b, "minecraft:quartz_stairs", { weirdo_direction: STAIRS[card(-da, -db)], upside_down_bit: false }),
      bed: (a, y, b, da, db) => {
        const direction = BED_DIR[card(da, db)];
        put(a + da, y, b + db, BED, { direction, head_piece_bit: true, occupied_bit: false });
        put(a, y, b, BED, { direction, head_piece_bit: false, occupied_bit: false });
      },
      ladder: (a, y, b, da, db) => put(a, y, b, "minecraft:ladder", { facing_direction: FACING[card(da, db)] }),
      front: (a, y, b, id, da, db) => put(a, y, b, id, { "minecraft:cardinal_direction": card(da, db) }),
      table: (a, y, b) => put(a, y, b, "minecraft:spruce_trapdoor", { direction: 0, open_bit: false, upside_down_bit: true }),
      lamp: (a, y, b) => put(a, y, b, LANTERN, { hanging: true }),
    };
  };
  const PANE = "minecraft:light_blue_stained_glass_pane";
  const CHISEL = "minecraft:chiseled_quartz_block";
  const BUSH = "minecraft:azalea_leaves_flowered";
  const chests = [];

  // ---- the palace at the back, facing the lagoon: a great hall with two rows of columns, tall blue windows and a
  // gold band; a portico of columns before its golden doorway; a blue carpet to the gold seat on its dais; the Elder's
  // room on one side of the seat and the vault on the other; over it a great gold dome on a windowed drum, four small
  // domes round it, and a domed tower at each corner
  const uf = Q + 3;
  const ub = Wr - 5;
  const D = ub - uf + 1;
  const PV = 8;
  const PH = G + 10;
  {
    const f = frame(...W(-ub, 0), gx, gz); // b = 0 at its back wall, b = D - 1 at its front; a across
    for (let b = 0; b < D; b++) {
      for (let a = -PV; a <= PV; a++) {
        const shell = Math.abs(a) === PV || b === 0 || b === D - 1;
        f.put(a, G, b, (a + b) % 2 === 0 ? QB : SQ);
        f.put(a, PH, b, b % 4 === 2 && a % 4 === 0 && Math.abs(a) < PV ? SEA_LANTERN : SQ);
        if (!shell) continue;
        const along = Math.abs(a) === PV ? b : a + PV;
        const corner = Math.abs(a) === PV && (b === 0 || b === D - 1);
        for (let y = G + 1; y < PH; y++) {
          let id = SQ;
          if (corner || along % 4 === 0) id = PILLAR;
          else if (y === PH - 1) id = GOLD;
          else if (y === PH - 2 || y === G + 2) id = CHISEL;
          else if (y >= G + 3 && y <= PH - 3) id = PANE;
          f.put(a, y, b, id);
        }
        if ((along & 1) === 0) f.put(a, PH + 1, b, SQ);
      }
    }
    // the hall's columns, a sea lantern at each one's head and foot
    for (let b = 7; b < D - 2; b += 4) {
      for (const a of [-4, 4]) {
        for (let y = G + 1; y < PH; y++) f.put(a, y, b, y === G + 1 || y === PH - 1 ? CHISEL : PILLAR);
        f.put(a, PH, b, SEA_LANTERN);
        f.put(a, G, b, SEA_LANTERN);
      }
    }
    for (let b = 3; b < D - 2; b += 4) f.lamp(0, PH - 1, b);
    // the doorway, 3 wide and 5 high, framed in gold; the portico before it
    const fb = D - 1;
    for (let a = -1; a <= 1; a++) for (let y = G + 1; y <= G + 5; y++) if (y <= G + 4 || a === 0) f.cut(a, y, fb);
    for (let y = G + 1; y <= G + 5; y++) for (const a of [-2, 2]) f.put(a, y, fb, GOLD);
    for (const a of [-1, 1]) f.put(a, G + 5, fb, GOLD);
    for (const a of [-1, 0, 1]) f.put(a, G + 6, fb, GOLD);
    f.put(0, G + 7, fb, "minecraft:lapis_block");
    for (let a = -PV; a <= PV; a++) {
      for (const b of [fb + 1, fb + 2]) f.put(a, G + 8, b, b === fb + 2 && (a & 1) === 0 ? CHISEL : SQ);
      if (Math.abs(a) <= 2 || (a & 1) === 0) f.put(a, G + 9, fb + 2, Math.abs(a) <= 2 ? GOLD : SQ);
    }
    for (const a of [-7, -4, 4, 7]) for (let y = G + 1; y <= G + 7; y++) f.put(a, y, fb + 2, y === G + 1 || y === G + 7 ? CHISEL : PILLAR);
    // the banners either side of the doorway, blue from a gold rod
    for (const a of [-5, 5]) {
      for (let y = G + 3; y <= G + 7; y++) f.put(a, y, fb, "minecraft:blue_wool");
      f.put(a, G + 8, fb, GOLD);
    }
    // the carpet from the door to the seat; the dais; the seat, gold with a high back and lapis over it
    for (let b = 2; b <= fb - 1; b++) f.put(0, G + 1, b, "minecraft:blue_carpet");
    for (const a of [-1, 1]) for (let b = 2; b <= 4; b++) f.put(a, G + 1, b, "minecraft:blue_carpet");
    f.put(0, G + 1, 1, GOLD);
    for (const a of [-1, 1]) {
      f.put(a, G + 1, 1, GOLD);
      f.put(a, G + 2, 1, LANTERN, { hanging: false });
    }
    for (let y = G + 2; y <= G + 4; y++) f.put(0, y, 0, GOLD);
    f.put(0, G + 5, 0, "minecraft:lapis_block");
    for (const a of [-2, 2]) for (let y = G + 1; y <= G + 6; y++) f.put(a, y, 0, y === G + 6 ? GOLD : "minecraft:blue_wool");
    // the two rooms at the back corners, each 4 by 3 under a low ceiling, a doorway toward the hall's middle
    for (const side of [-1, 1]) {
      for (let b = 1; b <= 5; b++) {
        for (let a = 3; a <= PV - 1; a++) {
          const wallHere = a === 3 || b === 5;
          if (wallHere) for (let y = G + 1; y <= G + 4; y++) f.put(side * a, y, b, a === 3 && b === 5 ? PILLAR : QB);
          f.put(side * a, G + 5, b, a === 3 || b === 5 ? CHISEL : SQ);
        }
      }
      f.cut(side * 3, G + 1, 3);
      f.cut(side * 3, G + 2, 3);
      f.put(side * 3, G + 3, 3, GOLD);
      f.lamp(side * 5, G + 4, 3);
    }
    // the vault (to the seat's left as you face it): the chest, gold, lapis
    f.front(6, G + 1, 1, "minecraft:chest", 0, 1);
    chests.push({ at: f.at(6, 1), y: G + 1, loot: "mythic_vault" });
    for (const [a, b, id, n] of /** @type {Array<[number, number, string, number]>} */ ([[7, 2, GOLD, 2], [5, 1, "minecraft:lapis_block", 1], [7, 4, GOLD, 3], [7, 3, "minecraft:raw_gold_block", 1], [4, 1, "minecraft:barrel", 1]])) {
      for (let i = 0; i < n; i++) f.put(a, G + 1 + i, b, id, id === "minecraft:barrel" ? { facing_direction: 1, open_bit: false } : undefined);
    }
    // the Elder's room (to its right): a bed, books, a lectern, a chest of their own
    // (the corner tower's foot fills the corner itself)
    f.bed(-7, G + 1, 3, 0, -1);
    f.put(-6, G + 1, 1, "minecraft:bookshelf");
    f.put(-6, G + 2, 1, "minecraft:bookshelf");
    f.put(-5, G + 1, 1, "minecraft:bookshelf");
    f.front(-4, G + 1, 1, "minecraft:lectern", 0, 1);
    f.put(-7, G + 1, 4, "minecraft:cartography_table");
    for (const [a, b] of [[-5, 3], [-6, 3], [-5, 2], [-6, 2]]) f.put(a, G + 1, b, "minecraft:light_blue_carpet");
    // along the hall's sides: benches, pots, shelves of books
    for (let b = 7; b < fb - 1; b += 2) {
      for (const side of [-1, 1]) {
        const pick = unit(hash(s, b, side, 81));
        if (pick < 0.35) f.chair(side * (PV - 1), G + 1, b, -side, 0);
        else if (pick < 0.6) f.put(side * (PV - 1), G + 1, b, "minecraft:decorated_pot", { direction: 0 });
        else if (pick < 0.8) for (const y of [G + 1, G + 2]) f.put(side * (PV - 1), y, b, "minecraft:bookshelf");
      }
    }
    // the great dome on its drum, windows round the drum; four small domes round it
    const mb = Math.round((D - 1) / 2);
    const R = D >= 21 ? 6 : 5;
    const [px, pz] = f.at(0, mb);
    for (const [dx, dz, d] of roundCells(R + 0.35)) {
      if (d <= R - 0.65) continue;
      const turn = Math.round(Math.atan2(dz, dx) * R);
      for (let y = PH + 1; y <= PH + 5; y++) set(px + dx, y, pz + dz, y === PH + 5 ? CHISEL : y >= PH + 2 && y <= PH + 4 && ((turn % 3) + 3) % 3 !== 0 ? PANE : SQ);
    }
    dome(px, pz, PH + 6, R, GOLD);
    for (const [a, b] of [[-5, 2], [5, 2], [-5, D - 3], [5, D - 3]]) {
      const [x, z] = f.at(a, b);
      for (const [dx, dz, d] of roundCells(2.35)) if (d > 1.35) for (let y = PH + 1; y <= PH + 2; y++) set(x + dx, y, z + dz, y === PH + 2 ? CHISEL : SQ);
      dome(x, z, PH + 3, 2, BLUE_DOME);
    }
    for (const b of [0, D - 1]) {
      for (const a of [-PV - 1, PV + 1]) {
        const [tx, tz] = f.at(a, b);
        tower(tx, tz, 2, G, PH + 6, GOLD);
      }
    }
  }
  // its forecourt
  for (let u = -uf + 1; u <= -Q; u++) for (let v = -PV; v <= PV; v++) {
    const [x, z] = W(u, v);
    tile(x, z, Math.abs(v) === PV ? SAND_EDGE : (u + v) % 4 === 0 ? "minecraft:chiseled_sandstone" : SAND_TILE);
  }
  const palace = { door: W(-uf, 0), step: W(-uf + 2, 0), middle: W(-Math.round((uf + ub) / 2), 0) };
  yield;

  // ---- the streets: a ring street through the middle of the town and two lanes across it, at right angles to the avenue
  const inner = Q + 2;
  const outer = Wr - 3;
  const z1 = Math.floor((outer - inner - 3) / 2);
  const street = [inner + z1, inner + z1 + 3];
  for (let z = cz - ring; z <= cz + ring; z++) {
    for (let x = cx - ring; x <= cx + ring; x++) {
      const d = dist(x, z);
      if (d < Q || d >= Wr - 1) continue;
      const u = U(x, z);
      const v = V(x, z);
      if (u <= -(uf - 3) && Math.abs(v) <= PV + 4) continue;
      if (d >= street[0] && d < street[1]) tile(x, z, SAND_TILE);
      else if (Math.abs(u) <= 1 && d >= Q) tile(x, z, u === 0 ? "minecraft:chiseled_sandstone" : SAND_TILE);
    }
  }
  yield;

  // ---- the houses, in two rings either side of the ring street, clear of the avenue, the lanes and the palace: villas
  // of two storeys with a porch and a balcony, cottages, and round tower houses of three storeys
  const houses = [];
  const clear = (x, z) => {
    const u = U(x, z);
    const v = V(x, z);
    if (u > 0 && Math.abs(v) <= 5) return false;
    if (Math.abs(u) <= 3) return false;
    if (u <= -(uf - 3) && Math.abs(v) <= PV + 5) return false;
    return true;
  };
  /** a villa (h 4: 9 by 9, two storeys) or a cottage (h 3: 7 by 7, one), its door in the middle of its front */
  function villa(hx, hz, h, nx, nz, j, wall, domeId) {
    const f = frame(hx, hz, nx, nz);
    const two = h === 4;
    const F1 = G + 5;
    const top = two ? G + 10 : F1;
    const m = unit(hash(s, j, 21, 7)) < 0.5 ? 1 : -1; // the room mirrored, one house in two
    for (let b = -h; b <= h; b++) {
      for (let a = -h; a <= h; a++) {
        const edge = Math.abs(a) === h || Math.abs(b) === h;
        const corner = Math.abs(a) === h && Math.abs(b) === h;
        f.pave(a, b, WOOD);
        f.put(a, G, b, edge ? QB : WOOD);
        if (edge) for (let y = G + 1; y < top; y++) f.put(a, y, b, corner ? PILLAR : y === F1 ? CHISEL : wall);
        else if (two) f.put(a, F1, b, WOOD);
        f.put(a, top, b, edge ? CHISEL : SQ);
        if (edge && (corner || ((a + b) & 1) === 0)) f.put(a, top + 1, b, corner ? PILLAR : SQ);
        if (corner) f.put(a, top + 2, b, LANTERN, { hanging: false });
      }
    }
    // windows, two high: two a side, on every storey
    const offs = two ? [-2, 2] : [-1, 1];
    for (const base of two ? [G, F1] : [G]) {
      for (const o of offs) {
        for (const y of [base + 2, base + 3]) {
          f.put(-h, y, o, PANE);
          f.put(h, y, o, PANE);
          f.put(o, y, -h, PANE);
          f.put(o + Math.sign(o), y, h, PANE);
        }
      }
    }
    // the door, a gold lintel over it; flowering bushes either side
    f.cut(0, G + 1, h);
    f.cut(0, G + 2, h);
    f.put(0, G + 3, h, GOLD);
    for (const a of [-1, 1]) for (let y = G + 1; y <= G + 3; y++) f.put(a, y, h, PILLAR);
    for (const a of [-h, h]) f.put(a, G + 1, h + 1, BUSH, LEAVES);
    if (two) {
      // the porch: two columns, the balcony over them with its rail, a door out onto it
      for (const a of [-2, 2]) for (let y = G + 1; y < F1; y++) f.put(a, y, h + 2, PILLAR);
      for (let a = -2; a <= 2; a++) {
        for (const b of [h + 1, h + 2]) {
          f.put(a, F1, b, SQ);
          f.pave(a, b, SAND_TILE);
          if (b === h + 2 || Math.abs(a) === 2) f.put(a, F1 + 1, b, "minecraft:birch_fence");
        }
      }
      f.cut(0, F1 + 1, h);
      f.cut(0, F1 + 2, h);
      f.put(0, F1 + 3, h, GOLD);
      f.lamp(0, F1 - 1, h + 1);
    } else {
      // a striped awning over the door
      for (const a of [-1, 0, 1]) f.put(a, G + 4, h + 1, a === 0 ? "minecraft:white_wool" : "minecraft:blue_wool");
    }
    // the dome, on a drum on a villa
    if (two) for (const [dx, dz, d] of roundCells(3.35)) if (d > 2.35) set(hx + dx, top + 1, hz + dz, CHISEL);
    dome(hx, hz, top + (two ? 2 : 1), two ? 3 : 2, domeId);
    // ---- inside, downstairs
    const y1 = G + 1;
    if (two) {
      // the kitchen along the back wall; a table and chairs; shelves; a rug; the ladder up
      f.front(m * -3, y1, -3, "minecraft:smoker", 0, 1);
      f.put(m * -2, y1, -3, "minecraft:crafting_table");
      f.put(m * -3, y1, -2, "minecraft:barrel", { facing_direction: 1, open_bit: false });
      f.put(m * -1, y1, -3, "minecraft:cauldron");
      for (const y of [y1, y1 + 1]) f.put(m * 3, y, -3, "minecraft:bookshelf");
      f.put(m * 2, y1, -3, "minecraft:bookshelf");
      f.put(m * 3, y1, -2, "minecraft:cartography_table");
      for (const b of [0, 1]) {
        f.table(m * 2, y1, b);
        f.chair(m * 1, y1, b, m, 0);
        f.chair(m * 3, y1, b, -m, 0);
      }
      f.put(m * -3, y1, 3, "minecraft:decorated_pot", { direction: 0 });
      f.put(m * 3, y1, 3, "minecraft:barrel", { facing_direction: 1, open_bit: false });
      for (let a = -2; a <= -1; a++) for (let b = -1; b <= 1; b++) f.put(m * a, y1, b, "minecraft:light_blue_carpet");
      for (let y = y1; y <= F1; y++) {
        f.cut(0, y, -3);
        f.ladder(0, y, -3, 0, 1);
      }
      f.lamp(0, F1 - 1, 0);
      // upstairs: two beds, a chest, shelves, a rug
      const y2 = F1 + 1;
      f.bed(m * -3, y2, -1, 0, -1);
      f.bed(m * -2, y2, -1, 0, -1);
      f.front(m * 3, y2, -3, "minecraft:chest", -m, 0);
      for (const y of [y2, y2 + 1]) f.put(m * 3, y, -2, "minecraft:bookshelf");
      f.put(m * 3, y2, 2, "minecraft:loom", { direction: 0 });
      f.put(m * -3, y2, 3, "minecraft:decorated_pot", { direction: 0 });
      for (const [a, b] of [[0, 0], [1, 0], [0, 1], [1, 1]]) f.put(m * a, y2, b, "minecraft:white_carpet");
      f.lamp(0, top - 1, 0);
    } else {
      // one room: a bed, a kitchen corner, a table and a chair, a shelf, a rug
      f.bed(m * -2, y1, -1, 0, -1);
      f.front(m * 2, y1, -2, "minecraft:smoker", 0, 1);
      f.put(m * 1, y1, -2, "minecraft:crafting_table");
      f.put(m * 2, y1, -1, "minecraft:barrel", { facing_direction: 1, open_bit: false });
      f.table(m * 2, y1, 1);
      f.chair(m * 1, y1, 1, m, 0);
      f.put(m * -2, y1, 2, "minecraft:bookshelf");
      f.put(m * -2, y1 + 1, 2, "minecraft:bookshelf");
      for (const [a, b] of [[0, 0], [-1, 0], [0, -1], [-1, -1]]) f.put(m * a, y1, b, "minecraft:light_blue_carpet");
      f.lamp(0, F1 - 1, 0);
    }
    return { door: f.at(0, h), step: f.at(0, h + 1), kind: two ? "villa" : "cottage" };
  }
  /** a round tower house, three storeys: a store, a bedroom, a study; a ladder up its back wall; a tall dome */
  function towerHouse(hx, hz, nx, nz, wall, domeId) {
    const f = frame(hx, hz, nx, nz);
    const cells = roundCells(3.3).map(([dx, dz]) => [dx, dz]);
    const inside = new Set(cells.map(([dx, dz]) => `${dx},${dz}`));
    const edgeOf = (dx, dz) => !inside.has(`${dx + 1},${dz}`) || !inside.has(`${dx - 1},${dz}`) || !inside.has(`${dx},${dz + 1}`) || !inside.has(`${dx},${dz - 1}`);
    const top = G + 12;
    for (const [dx, dz] of cells) {
      const x = hx + dx;
      const z = hz + dz;
      const edge = edgeOf(dx, dz);
      tile(x, z, WOOD);
      set(x, G, z, edge ? QB : WOOD);
      for (let y = G + 1; y < top; y++) {
        const floor = y === G + 4 || y === G + 8;
        if (edge) set(x, y, z, floor ? CHISEL : wall);
        else if (floor) set(x, y, z, WOOD);
      }
      set(x, top, z, edge ? CHISEL : SQ);
      if (edge && ((dx + dz) & 1) === 0) set(x, top + 1, z, SQ);
    }
    for (const base of [G, G + 4, G + 8]) {
      // (none in the back wall: the ladder is on it)
      for (const [a, b] of [[3, 0], [-3, 0], [0, 3]]) {
        if (base === G && b === 3) continue;
        f.put(a, base + 2, b, PANE);
        if (base !== G) f.put(a, base + 3, b, PANE);
      }
    }
    f.cut(0, G + 1, 3);
    f.cut(0, G + 2, 3);
    f.put(0, G + 3, 3, GOLD);
    for (const a of [-2, 2]) f.put(a, G + 1, 3, BUSH, LEAVES);
    for (let y = G + 1; y <= G + 9; y++) {
      f.cut(0, y, -2);
      f.ladder(0, y, -2, 0, 1);
    }
    // the store
    f.put(-2, G + 1, 0, "minecraft:barrel", { facing_direction: 1, open_bit: false });
    f.put(-2, G + 1, -1, "minecraft:barrel", { facing_direction: 1, open_bit: false });
    f.put(-2, G + 2, -1, "minecraft:barrel", { facing_direction: 1, open_bit: false });
    f.put(2, G + 1, 0, "minecraft:crafting_table");
    f.front(2, G + 1, -1, "minecraft:smoker", -1, 0);
    f.lamp(0, G + 3, 0);
    // the bedroom
    f.bed(-2, G + 5, 1, 0, -1);
    f.front(2, G + 5, 0, "minecraft:chest", -1, 0);
    f.put(2, G + 5, 1, "minecraft:decorated_pot", { direction: 0 });
    f.put(0, G + 5, 0, "minecraft:light_blue_carpet");
    f.put(0, G + 5, 1, "minecraft:light_blue_carpet");
    f.lamp(0, G + 7, 0);
    // the study
    f.front(0, G + 9, 2, "minecraft:lectern", 0, -1);
    for (const a of [-2, 2]) for (const y of [G + 9, G + 10]) f.put(a, y, 0, "minecraft:bookshelf");
    f.put(2, G + 9, 1, "minecraft:cartography_table");
    f.put(0, G + 9, 0, "minecraft:white_carpet");
    f.lamp(0, G + 11, 0);
    dome(hx, hz, top + 1, 3, domeId);
    return { door: f.at(0, 3), step: f.at(0, 4), kind: "tower" };
  }
  let j = 0;
  /** whether a house of that kind can stand at hx hz with its door toward nx nz, in the ring from lo to hi: "ok", or "zone" (it would stand out of its ring, or on a street), or "space" (too near another building) */
  const fits = (kind, hx, hz, nx, nz, lo, hi) => {
    const h = kind === "villa" ? 4 : 3;
    // (a villa's porch and a house's bushes stand out in front of it); a corner may stand a block out of its ring
    const pts = [[hx, hz, 0], [hx + nx * (h + (kind === "villa" ? 2 : 1)), hz + nz * (h + (kind === "villa" ? 2 : 1)), 0]];
    if (kind === "tower") pts.push([hx + 3, hz, 0], [hx - 3, hz, 0], [hx, hz + 3, 0], [hx, hz - 3, 0]);
    else for (let dz = -h; dz <= h; dz += h) for (let dx = -h; dx <= h; dx += h) if (dx || dz) pts.push([hx + dx, hz + dz, dx && dz ? 1 : 0]);
    for (const [x, z, slack] of pts) {
      const d = dist(x, z);
      if (d < lo - slack || d > hi + slack || !clear(x, z)) return "zone";
    }
    if (houses.some((o) => Math.max(Math.abs(o.x - hx), Math.abs(o.z - hz)) < o.h + h + 3)) return "space";
    if (towers.some((o) => Math.max(Math.abs(o.x - hx), Math.abs(o.z - hz)) < o.R + h + 2)) return "space";
    return "ok";
  };
  for (const [lo, hi] of [[inner, street[0]], [street[1], outer]]) {
    const hr = (lo + hi) / 2;
    const circ = 2 * Math.PI * hr;
    for (let arc = unit(hash(s, 5, 4 + lo, 7)) * 4; arc < circ; ) {
      const a = ag + arc / hr;
      // what the next house here would be: a tower house now and then, a villa most often, else a cottage; if the
      // ring is too narrow here for it, the next smaller; if it only lacks room beside its neighbour, a step on
      const want = unit(hash(s, j + 1, 6, 7));
      const order = want < 0.18 ? ["tower"] : want < 0.66 ? ["villa", "cottage", "tower"] : ["cottage", "tower"];
      let built;
      let wait = false;
      for (const kind of order) {
        for (const off of kind === "tower" ? [0] : [0, 1, -1, 2]) {
          const hx = Math.round(cx + Math.cos(a) * (hr + off));
          const hz = Math.round(cz + Math.sin(a) * (hr + off));
          // its door on the side facing the lagoon
          const ddx = cx - hx;
          const ddz = cz - hz;
          const [nx, nz] = Math.abs(ddx) >= Math.abs(ddz) ? [Math.sign(ddx), 0] : [0, Math.sign(ddz)];
          const fit = fits(kind, hx, hz, nx, nz, lo, hi);
          if (fit === "space") wait = true;
          if (fit !== "ok") continue;
          j++;
          const h = kind === "villa" ? 4 : 3;
          const domeId = unit(hash(s, j, 8, 7)) < 0.65 ? GOLD : BLUE_DOME;
          const wall = HOUSE_WALLS[Math.floor(unit(hash(s, j, 9, 7)) * HOUSE_WALLS.length)];
          const made = kind === "tower" ? towerHouse(hx, hz, nx, nz, wall, domeId) : villa(hx, hz, h, nx, nz, j, wall, domeId);
          built = { x: hx, z: hz, h, round: kind === "tower", kind, dome: domeId, wall, door: made.door, step: made.step, way: [nx, nz] };
          break;
        }
        if (built || wait) break;
      }
      if (!built) {
        arc += 1;
        continue;
      }
      arc += 2 * built.h + 4;
      houses.push(built);
      // its path, from the step out to the nearest paving
      for (let n = built.kind === "villa" ? 3 : 1; n <= 9; n++) {
        const x = built.door[0] + built.way[0] * n;
        const z = built.door[1] + built.way[1] * n;
        const k = at(sh, x, z);
        if (k < 0 || sh.kind[k] !== LAND || T.has(k) || has(x, G + 1, z)) break;
        tile(x, z, SAND_TILE);
      }
      if (houses.length % 3 === 0) yield;
    }
  }
  yield;

  // ---- the lagoon: three piers (one on from the avenue, one either side) with lanterns at their ends, a column in its
  // middle with a gold cap, and a little sailboat moored beside each side pier
  const pierLen = Math.min(5, L - 5);
  const piers = [];
  for (const [pu, pv] of [[1, 0], [0, 1], [0, -1]]) {
    for (let n = 0; n < pierLen; n++) {
      const along = L - n;
      for (let w = -1; w <= 1; w++) {
        const u = pu * along + pv * 0 + (pv !== 0 ? w : 0);
        const v = pv * along + (pu !== 0 ? w : 0);
        const [x, z] = W(u, v);
        const k = at(sh, x, z);
        if (k < 0) continue;
        set(x, G, z, WOOD);
        if (n === pierLen - 1 && w !== 0 && sh.kind[k] === POND) {
          for (let y = sh.floor[k] + 1; y < G; y++) set(x, y, z, "minecraft:spruce_log");
          set(x, G + 1, z, "minecraft:spruce_fence");
          set(x, G + 2, z, LANTERN, { hanging: false });
        }
      }
    }
    piers.push({ end: W(pu * (L - pierLen + 1), pv * (L - pierLen + 1)) });
  }
  for (const [dx, dz, d] of roundCells(1.5)) {
    const k = at(sh, cx + dx, cz + dz);
    if (k < 0) continue;
    for (let y = sh.floor[k] + 1; y <= G; y++) set(cx + dx, y, cz + dz, SQ);
    if (d > 1) set(cx + dx, G + 1, cz + dz, SEA_LANTERN);
  }
  for (let y = G + 1; y <= G + 5; y++) set(cx, y, cz, PILLAR);
  set(cx, G + 6, cz, GOLD);
  set(cx, G + 7, cz, "minecraft:end_rod", { facing_direction: 1 });
  yield;

  // ---- sailboats: a spruce hull at the water, a mast, a white mainsail and jib, a blue pennant
  const boats = [];
  const water = (x, z, lo, hi) => {
    const k = at(sh, x, z);
    const d = dist(x, z);
    return k >= 0 && sh.kind[k] === POND && d >= lo && d <= hi;
  };
  /** boat cells in its own frame (a along it, b across), from its middle */
  function boatCells(len) {
    const half = (len - 1) / 2;
    const out = [];
    for (let a = -half; a <= half; a++) {
      for (let b = -1; b <= 1; b++) {
        const tip = Math.abs(a) === half;
        if (tip && b !== 0) continue;
        out.push([a, b, tip]);
      }
    }
    return { half, cells: out };
  }
  /** a boat of `len` along `axis` (its bow toward +axis when dir is 1) with its middle at bx bz, if its hull and
   * `margin` blocks round it are all open water from lo to hi blocks from the island's middle, with nothing built there */
  function boat(bx, bz, axis, dir, len, lo, hi, margin) {
    const { half, cells } = boatCells(len);
    const at2 = (a, b) => (axis === "x" ? [bx + a * dir, bz + b] : [bx + b, bz + a * dir]);
    for (let a = -half - margin; a <= half + margin; a++) {
      for (let b = -1 - margin; b <= 1 + margin; b++) {
        const [x, z] = at2(a, b);
        if (!water(x, z, lo, hi) || has(x, y0 - 1, z) || has(x, y0, z) || has(x, G, z)) return false;
      }
    }
    for (const [a, b, tip] of cells) {
      const [x, z] = at2(a, b);
      set(x, y0, z, WOOD);
      if (tip || b !== 0) set(x, y0 + 1, z, WOOD);
    }
    const mast = len >= 7 ? 5 : 3;
    const [mx, mz] = at2(0, 0);
    for (let y = y0 + 1; y <= y0 + 1 + mast; y++) set(mx, y, mz, "minecraft:spruce_fence");
    const sail = len >= 7 ? [[-1, 2], [-2, 2], [-1, 3], [-2, 3], [-1, 4], [-2, 4], [-1, 5], [1, 2], [2, 2], [1, 3], [1, 4]] : [[-1, 2], [-1, 3], [1, 2]];
    for (const [a, h] of sail) {
      const [x, z] = at2(a, 0);
      set(x, y0 + h, z, "minecraft:white_wool");
    }
    const [fx, fz] = at2(-1, 0);
    set(fx, y0 + 1 + mast, fz, "minecraft:blue_wool");
    boats.push({ x: bx, z: bz, axis, dir, len });
    return true;
  }
  const re = isl.r * 0.97;
  const nb = 3 + Math.floor(unit(hash(s, 5, 3, 7)) * 3);
  for (let t = 0, placed = 0; t < 40 && placed < nb; t++) {
    const a = unit(hash(s, t, 10, 7)) * Math.PI * 2;
    const rb = (Wr + 2 + re - 3) / 2 + (unit(hash(s, t, 11, 7)) - 0.5) * 3;
    const bx = Math.round(cx + Math.cos(a) * rb);
    const bz = Math.round(cz + Math.sin(a) * rb);
    if (U(bx, bz) > Wr && Math.abs(V(bx, bz)) < 9) continue;
    if (boats.some((o) => Math.max(Math.abs(o.x - bx), Math.abs(o.z - bz)) < 10)) continue;
    const axis = Math.abs(Math.sin(a)) > Math.abs(Math.cos(a)) ? "x" : "z";
    const dir = unit(hash(s, t, 12, 7)) < 0.5 ? 1 : -1;
    if (boat(bx, bz, axis, dir, 7, Wr + 2, re - 3.5, 1)) placed++;
  }
  for (const pv of [1, -1]) {
    // beside the side pier, on its gate side
    const [bx, bz] = W(3, pv * (L - 4));
    boat(bx, bz, gx !== 0 ? "z" : "x", pv * (gx !== 0 ? gx : -gz) >= 0 ? 1 : -1, 5, 0, L - 0.8, 0);
  }
  yield;

  // ---- palms (on the beach and the town's grass) and flowering azaleas, never against anything built
  const palms = [];
  const free = (x, z, h, pad) => {
    for (let dz = -pad; dz <= pad; dz++) for (let dx = -pad; dx <= pad; dx++) for (let y = G; y <= G + h + 2; y++) if (has(x + dx, y, z + dz)) return false;
    return true;
  };
  const grassAt = (x, z) => {
    const k = at(sh, x, z);
    if (k < 0 || sh.kind[k] !== LAND || T.has(k)) return undefined;
    const d = dist(x, z);
    if (d >= Wr + 1) return Math.hypot(x - plaza.x, z - plaza.z) <= plaza.r + 1.5 ? undefined : "beach";
    return d >= Q && d < Wr - 3 ? "town" : undefined;
  };
  const span = sh.R;
  for (let gzz = -span; gzz <= span; gzz += 5) {
    for (let gxx = -span; gxx <= span; gxx += 5) {
      const x = cx + gxx + Math.floor(unit(hash(s, gxx, gzz, 61)) * 4) - 2;
      const z = cz + gzz + Math.floor(unit(hash(s, gxx, gzz, 63)) * 4) - 2;
      const where = grassAt(x, z);
      if (!where || unit(hash(s, gxx, gzz, 65)) >= (where === "beach" ? 0.45 : 0.3)) continue;
      const h = 5 + Math.floor(unit(hash(s, gxx, gzz, 67)) * 3);
      if (!free(x, z, h, 3) || palms.some((p) => Math.max(Math.abs(p.x - x), Math.abs(p.z - z)) < 5)) continue;
      const T0 = G + h;
      for (let y = G + 1; y <= T0; y++) set(x, y, z, "minecraft:jungle_log");
      set(x, T0 + 1, z, "minecraft:jungle_leaves", LEAVES);
      for (const [ux, uz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        set(x + ux, T0, z + uz, "minecraft:jungle_leaves", LEAVES);
        set(x + 2 * ux, T0, z + 2 * uz, "minecraft:jungle_leaves", LEAVES);
        set(x + 3 * ux, T0 - 1, z + 3 * uz, "minecraft:jungle_leaves", LEAVES);
      }
      for (const [ux, uz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
        set(x + ux, T0, z + uz, "minecraft:jungle_leaves", LEAVES);
        set(x + 2 * ux, T0 - 1, z + 2 * uz, "minecraft:jungle_leaves", LEAVES);
      }
      palms.push({ x, z, h });
    }
  }
  yield;
  for (let gzz = -span; gzz <= span; gzz += 3) {
    for (let gxx = -span; gxx <= span; gxx += 3) {
      const x = cx + gxx + Math.floor(unit(hash(s, gxx, gzz, 71)) * 3) - 1;
      const z = cz + gzz + Math.floor(unit(hash(s, gxx, gzz, 73)) * 3) - 1;
      if (grassAt(x, z) !== "town" || unit(hash(s, gxx, gzz, 75)) >= 0.12 || !free(x, z, 2, 1)) continue;
      set(x, G + 1, z, "minecraft:azalea_leaves_flowered", LEAVES);
      const v = unit(hash(s, gxx, gzz, 77));
      if (v < 0.5 && grassAt(x + 1, z) === "town" && free(x + 1, z, 1, 0)) set(x + 1, G + 1, z, "minecraft:azalea_leaves", LEAVES);
      if (v > 0.6) set(x, G + 2, z, "minecraft:azalea_leaves_flowered", LEAVES);
    }
  }

  const spots = {
    G,
    houses: houses.map((h) => ({ door: h.door, step: h.step })),
    palace: { door: palace.door, step: palace.step },
    plaza: [plaza.x, plaza.z],
    lagoon: [cx, cz],
    piers: piers.map((p) => p.end),
  };
  // the lanterns and carpets go in last, once what they stand on is in (decor)
  const decor = new Map();
  for (const [k, v] of B) if (MYTHIC_DECOR.includes(v[0])) decor.set(k, v);
  for (const k of decor.keys()) B.delete(k);
  sh.city = { blocks: B, decor, tops: T, spots, houses, towers, domes, boats, palms, gate: { u0: gu0, u1: gu1 }, chests: chests.map((c) => ({ x: c.at[0], y: c.y, z: c.at[1], loot: c.loot })) };
}

/**
 * 0.1.286: where the vault's chest stands in a mythic town's palace (as mythicSites puts it: the palace's frame, 6
 * across and 1 in from its back wall), for a vault filled before the Mythical Fishing Rod was in its table.
 */
export function vaultOf(isl) {
  const c = cityOf(isl);
  const ub = c.Wr - 5;
  return { x: isl.x - ub * c.gx - 6 * c.gz + c.gx, y: c.G + 1, z: isl.z - ub * c.gz + 6 * c.gx + c.gz };
}

/** A mythic island's top block on a column: paving and plank floors as the town laid them; sand on the beach; grass. */
function mythicTopOf(isl, sh, k) {
  const t = sh.city?.tops.get(k);
  if (t) return t;
  if (sh.kind[k] !== LAND) return "minecraft:grass_block";
  const x = sh.x0 + (k % sh.W);
  const z = sh.z0 + Math.floor(k / sh.W);
  return Math.hypot(x - isl.x, z - isl.z) >= cityOf(isl).Wr + 1 ? "minecraft:sand" : "minecraft:grass_block";
}

/** Whether a mythic island's column is beach or plaza (sandstone under it, not dirt). */
function mythicBeach(isl, sh, k) {
  if (sh.kind[k] !== LAND) return false;
  const x = sh.x0 + (k % sh.W);
  const z = sh.z0 + Math.floor(k / sh.W);
  return Math.hypot(x - isl.x, z - isl.z) >= cityOf(isl).Wr + 1;
}

/**
 * A mythic island's sea bed: sand, with a coral block here and there in the sea round the wall (it goes in as sand and
 * becomes coral once the water is in: put in dry, coral dies at once), sea lanterns in a ring under the lagoon.
 */
function mythicBedOf(isl, sh, k) {
  const x = sh.x0 + (k % sh.W);
  const z = sh.z0 + Math.floor(k / sh.W);
  const { L } = cityOf(isl);
  const d = Math.hypot(x - isl.x, z - isl.z);
  if (d < L) {
    const step = Math.round(Math.atan2(z - isl.z, x - isl.x) * (L - 3));
    return Math.abs(d - (L - 3)) < 0.5 && ((step % 3) + 3) % 3 === 0 ? SEA_LANTERN : "minecraft:sand";
  }
  const u = unit(hash(isl.s, x, z, 233));
  return u < 0.05 ? CORAL_BLOCKS[Math.floor(unit(hash(isl.s, x, z, 235)) * CORAL_BLOCKS.length)] : "minecraft:sand";
}

/** The flowers in a mythic town's grass. */
export const MYTHIC_FLOWERS = Object.freeze(["minecraft:allium", "minecraft:pink_tulip", "minecraft:cornflower", "minecraft:lily_of_the_valley", "minecraft:oxeye_daisy", "minecraft:azure_bluet"]);

/**
 * A mythic island's sand (its beach, its sea's bed, sand where its coral will be) and the sea lanterns under its lagoon,
 * as lists: they go in after its stone, so the sand has something under it.
 */
function* mythicSand(isl, sh, cols, tops, batches) {
  const xOf = (k) => sh.x0 + (k % sh.W);
  const zOf = (k) => sh.z0 + Math.floor(k / sh.W);
  yield* batches("minecraft:sand", (function* () {
    for (const k of cols) if (tops.get(k) === "minecraft:sand") yield { x: xOf(k), y: sh.top[k], z: zOf(k) };
    for (const k of cols) if (sh.kind[k] === POND && mythicBedOf(isl, sh, k) !== SEA_LANTERN) yield { x: xOf(k), y: sh.floor[k], z: zOf(k) };
  })());
  yield* batches(SEA_LANTERN, (function* () {
    for (const k of cols) if (sh.kind[k] === POND && mythicBedOf(isl, sh, k) === SEA_LANTERN) yield { x: xOf(k), y: sh.floor[k], z: zOf(k) };
  })());
}

/** A mythic island's plants: grass, flowers and pink petals on its grass; coral and seagrass on the bed of its sea and lagoon. */
function* mythicPlants(isl, sh, cols, tops, taken, pad, grouped, batches) {
  const s = isl.s;
  const W = sh.W;
  const xOf = (k) => sh.x0 + (k % W);
  const zOf = (k) => sh.z0 + Math.floor(k / W);
  const plants = new Map();
  for (const k of cols) {
    if (sh.kind[k] !== LAND || tops.get(k) !== "minecraft:grass_block") continue;
    const x = xOf(k);
    const z = zOf(k);
    const y = sh.top[k] + 1;
    if (pad(x, z) || taken.has(`${x},${sh.top[k]},${z}`) || taken.has(`${x},${y},${z}`)) continue;
    const u = unit(hash(s, x, z, 31));
    if (u < 0.22) plants.set(`${x},${y},${z}`, ["minecraft:short_grass"]);
    else if (u < 0.27) plants.set(`${x},${y},${z}`, [MYTHIC_FLOWERS[Math.floor(unit(hash(s, x, z, 33)) * MYTHIC_FLOWERS.length)]]);
    else if (u < 0.3) plants.set(`${x},${y},${z}`, ["minecraft:pink_petals", { growth: 3, "minecraft:cardinal_direction": DIRS4[Math.floor(unit(hash(s, x, z, 37)) * 4)] }]);
  }
  yield* grouped(plants);
  // coral blocks in the sea's bed, put in place of the sand once the water is over it
  const coral = new Map();
  for (const k of cols) {
    if (sh.kind[k] !== POND) continue;
    const id = mythicBedOf(isl, sh, k);
    const x = xOf(k);
    const z = zOf(k);
    if (CORAL_BLOCKS.includes(id) && !taken.has(`${x},${sh.floor[k]},${z}`)) coral.set(`${x},${sh.floor[k]},${z}`, [id]);
  }
  for (const op of grouped(coral)) yield { ...op, into: "minecraft:sand" };
  // seagrass on the bed, put into the water once it's in (put in air, its water would run)
  for (const op of batches("minecraft:seagrass", (function* () {
    for (const k of cols) {
      if (sh.kind[k] !== POND || sh.top[k] - sh.floor[k] < 2) continue;
      const x = xOf(k);
      const z = zOf(k);
      const y = sh.floor[k] + 1;
      if (taken.has(`${x},${y},${z}`) || taken.has(`${x},${sh.floor[k]},${z}`) || mythicBedOf(isl, sh, k) !== "minecraft:sand" || unit(hash(s, x, z, 91)) >= 0.25) continue;
      yield { x, y, z };
    }
  })())) yield { ...op, into: "minecraft:water" };
}

// ---- the return portal on the island

/**
 * The prismarine frame (4 wide, 5 tall, along x) standing on the landing, the portal inside it, the dirt that fills
 * any gap under the frame, and where a player arrives (in the portal's middle).
 */
export function returnPortal(landing, sh) {
  const { x: lx, z: lz, y } = landing;
  const frame = [];
  const inside = [];
  const under = [];
  for (let dx = -1; dx <= 2; dx++) {
    for (let dy = 0; dy <= 4; dy++) {
      const p = { x: lx + dx, y: y + dy, z: lz };
      if (dx === -1 || dx === 2 || dy === 0 || dy === 4) frame.push(p);
      else inside.push(p);
    }
    const k = sh ? at(sh, lx + dx, lz) : -1;
    if (k >= 0) for (let yy = sh.top[k] + 1; yy < y; yy++) under.push({ x: lx + dx, y: yy, z: lz });
  }
  return { frame, inside, under, arrive: { x: lx + 1, y: y + 1, z: lz + 0.5 }, axis: "x" };
}
// ---- a huge island: the harbour (0.1.280)
//
// Austin (12 Nov 18:01Z): "All islands ... should all be relatively big. Some being huge with builds on them (fishing
// ships, submarines, etc)". A huge island (radius 100 to 130, a region of 2 by 2 cells) is a harbour island:
// - a round harbour of clear water (its radius about a third of the island's), off the middle toward one of four ways,
//   3 deep at its quay and 11 in its middle, sealed in stone, with a quay of stone bricks all round it;
// - on its inland side a paved promenade with two fish stalls and a crane, fishing huts behind it, lamp posts round the
//   quay;
// - three wooden piers out into it, with lantern posts and a bell;
// - two fishing trawlers alongside the side piers (a raised bow, the wheelhouse with its mast, a hold under the deck
//   with a hatch and a ladder, the working deck aft with the net drum and the gantry over the stern; a captain's chest
//   in the wheelhouse), a submarine alongside the middle pier (its conning tower with a hatch and a ladder down; inside,
//   the torpedo room, the control room, bunks and the engine room; a chest), and two boats anyone can take out;
// - a lighthouse on the far side of the harbour near the shore, red and white, lit at the top;
// - the rest of the island grass on rolling ground, a hill on its far side, groves of trees and open meadows.
// Ships are built like the town (lists of blocks into air): their hulls are whole blocks wherever they touch the water,
// and the air inside them is kept dry. A huge island is built in four parts, then its water, then its plants and lamps
// (islands.js: the game keeps at most 300 chunks loaded for an add-on, measured on the test server, and a huge island
// needs about 480). No portal opens onto a huge island: like the mythic towns, they're found by travelling the sky.

/** The harbour's size: its middle `at` of the island's radius from the island's, its radius `radius` of it. */
export const HARBOUR = Object.freeze({ at: 0.4, radius: 0.36, flat: 16, blend: 12, pier: 0.45, spread: 0.55 });

/**
 * The harbour's plan from its island: its middle hx hz, radius B, the way from the island's middle to it (gx gz; the
 * piers and the town are on the side toward the island's middle, the lighthouse on the far side), the water's surface
 * y0, the quay's level G (one over the water), the piers' length P and how far apart they are (sp).
 */
export function harbourOf(isl) {
  const [gx, gz] = GATE_DIRS[Math.floor(unit(hash(isl.s, 7, 1, 7)) * 4)];
  const dH = Math.round(isl.r * HARBOUR.at);
  const B = Math.round(isl.r * HARBOUR.radius);
  return { gx, gz, dH, hx: isl.x + gx * dH, hz: isl.z + gz * dH, B, y0: isl.y, G: isl.y + 1, P: Math.round(B * HARBOUR.pier), sp: Math.round(B * HARBOUR.spread) };
}

/** The harbour's water at d blocks from its middle: its bed's level (3 deep at the quay, 11 in the middle). */
export const harbourFloor = (h, d) => h.y0 - (3 + Math.round(8 * (1 - (d / h.B) ** 2)));

const smooth01 = (t) => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));

/** A huge island's body: the common one's shore, hills and underside, flat round the harbour, the harbour cut in. */
function* hugeBody(isl, sh) {
  const { r, y: y0, s } = isl;
  const depth = Math.round(Math.min(r, 75) * 0.6);
  const h = harbourOf(isl);
  const { hx, hz, B, G } = h;
  const hill = { x: isl.x - h.gx * r * 0.5, z: isl.z - h.gz * r * 0.5, R: r * 0.42, H: 8 + Math.floor(unit(hash(s, 7, 2, 7)) * 5) };
  const flat = B + HARBOUR.flat;
  // (at least `flat` blocks of land round the harbour's middle, out to the shore)
  const px = hx - isl.x;
  const pz = hz - isl.z;
  for (let j = 0; j < sh.W; j++) {
    const z = sh.z0 + j;
    for (let i = 0; i < sh.W; i++) {
      const x = sh.x0 + i;
      const dx = x - isl.x;
      const dz = z - isl.z;
      const d = Math.hypot(dx, dz);
      if (d > r * 1.1) continue;
      const ang = Math.atan2(dz, dx);
      let re = r * (0.86 + 0.14 * fbm2((s ^ 0x1) >>> 0, 3 + 2 * Math.cos(ang), 3 + 2 * Math.sin(ang)) + 0.08 * noise2((s ^ 0x2) >>> 0, x / 18, z / 18));
      const proj = px * Math.cos(ang) + pz * Math.sin(ang);
      const room = flat * flat - (px * px + pz * pz - proj * proj);
      if (room > 0) re = Math.max(re, proj + Math.sqrt(room));
      if (d >= re) continue;
      const t = d / re;
      let top = y0 + Math.round(2.5 * (1 - t * t) + 1.8 * fbm2((s ^ 0x3) >>> 0, x / 24, z / 24) - (t > 0.8 ? (t - 0.8) * 8 : 0));
      const dh = Math.hypot(x - hill.x, z - hill.z) / hill.R;
      if (dh < 1) top += Math.round(hill.H * Math.pow(1 - dh * dh, 1.6) * (0.8 + 0.4 * noise2((s ^ 0x9) >>> 0, x / 20, z / 20)));
      const dq = Math.hypot(x - hx, z - hz);
      if (dq < flat) top = G;
      else if (dq < flat + HARBOUR.blend) top = Math.round(G + (top - G) * smooth01((dq - flat) / HARBOUR.blend));
      const under = depth * Math.pow(Math.max(0, 1 - t * t), 0.7) * (0.75 + 0.35 * noise2((s ^ 0x4) >>> 0, x / 12, z / 12));
      let drip = 0;
      if (t < 0.85) {
        const q = noise2((s ^ 0x5) >>> 0, x / 5, z / 5);
        if (q > 0.5) drip = (q - 0.5) * 2 * depth * 0.35 * (1 - t);
      }
      let kind = LAND;
      let floor = top;
      if (dq < B) {
        kind = POND;
        top = y0;
        floor = harbourFloor(h, dq);
      }
      let bottom = Math.min(floor - 3, top - 2 - Math.round(under + drip));
      // deep under the harbour and its quay, so its water stays in (and the rock under it hangs well down)
      const keel = y0 - 15 - Math.round(3 * noise2((s ^ 0xa) >>> 0, x / 7, z / 7));
      if (dq < B + 4) bottom = Math.min(bottom, keel);
      else if (dq < B + 14) bottom = Math.min(bottom, Math.round(keel + (bottom - keel) * ((dq - B - 4) / 10)));
      const k = j * sh.W + i;
      sh.kind[k] = kind;
      sh.top[k] = top;
      sh.floor[k] = floor;
      sh.bottom[k] = bottom;
      sh.edge[k] = Math.min(100, Math.round(t * 100));
    }
    yield;
  }
}

const SB = "minecraft:stone_bricks";
const PLANKS = "minecraft:spruce_planks";
const LOG = "minecraft:spruce_log";
const FENCE = "minecraft:spruce_fence";
const CHAIN = "minecraft:iron_chain";
const LADDER = "minecraft:ladder";
const BARREL = "minecraft:barrel";
const BARREL_UP = Object.freeze({ facing_direction: 1, open_bit: false });
const HATCH = Object.freeze({ direction: 0, open_bit: false, upside_down_bit: true });
/** The blocks that go in last, once what holds them is in (lanterns, chains, ladders, the bell). */
export const HARBOUR_DECOR = Object.freeze([LANTERN, CHAIN, LADDER, "minecraft:bell"]);
/** A local way (dx dz, one of the four) as the game names it. */
const CARD = (dx, dz) => (dx > 0 ? "east" : dx < 0 ? "west" : dz > 0 ? "south" : "north");
/** Stairs: the way their tall side faces. */
const STAIRS = Object.freeze({ east: 0, west: 1, south: 2, north: 3 });
/** A ladder (or a dispenser): the way it faces, away from the block it's on. */
const FACING = Object.freeze({ north: 2, south: 3, west: 4, east: 5 });

/** The trawlers' colours: above the water, the band at the water, below it. */
export const TRAWLER_COLOURS = Object.freeze([
  ["minecraft:blue_concrete", "minecraft:white_concrete", "minecraft:red_concrete"],
  ["minecraft:red_concrete", "minecraft:white_concrete", "minecraft:black_concrete"],
  ["minecraft:green_concrete", "minecraft:white_concrete", "minecraft:red_concrete"],
  ["minecraft:cyan_concrete", "minecraft:white_concrete", "minecraft:black_concrete"],
  ["minecraft:dark_oak_planks", PLANKS, "minecraft:dark_oak_planks"],
]);
/** The submarine's colours: its hull and its trim (the tower's top, the planes, the fins). */
export const SUB_COLOURS = Object.freeze([
  ["minecraft:yellow_concrete", "minecraft:black_concrete"],
  ["minecraft:gray_concrete", "minecraft:black_concrete"],
]);

/**
 * A frame for building something facing a way: at(a, b) the world's x z of the point a along it (fx fz) and b across
 * it (to its right, looking along it) from ox oz; way(da, db) a local way in the world.
 */
function frame(ox, oz, fx, fz) {
  return { at: (a, b) => [ox + a * fx - b * fz, oz + a * fz + b * fx], way: (da, db) => [da * fx - db * fz, da * fz + db * fx] };
}

/** The cells (a, b, h; h from the water's surface) of a trawler, 23 long and 7 across, its bow at a 11. */
export function trawlerCells(colours, loot = "trawler") {
  const [top, band, below] = colours;
  const half = (a) => (a === 11 ? 0 : a >= 9 ? 1 : a >= 7 ? 2 : a >= -10 ? 3 : a === -11 ? 2 : -1);
  const cells = [];
  const keep = [];
  const put = (a, b, h, id, st) => cells.push({ a, b, h, id, st });
  const HOLD = [-4, 5];
  const inHold = (a, b) => a >= HOLD[0] && a <= HOLD[1] && Math.abs(b) < half(a);
  for (let a = -11; a <= 11; a++) {
    const w = half(a);
    for (let b = -w; b <= w; b++) {
      const side = Math.abs(b) === w || Math.abs(b) > half(a + 1) || Math.abs(b) > half(a - 1);
      if (Math.abs(b) < w) put(a, b, -2, below);
      if (side) {
        put(a, b, -1, below);
        put(a, b, 0, band);
        put(a, b, 1, top);
        // the bulwark round the deck (a gap on each side to step aboard), higher at the raised bow
        if (!(a >= -3 && a <= -2)) put(a, b, 2, top);
        if (a >= 7) put(a, b, 3, top);
      } else {
        if (inHold(a, b)) {
          keep.push({ a, b, h: -1 }, { a, b, h: 0 });
        } else {
          put(a, b, -1, below);
          put(a, b, 0, PLANKS);
        }
        put(a, b, 1, a === HOLD[0] && b === 0 ? "minecraft:spruce_trapdoor" : PLANKS, a === HOLD[0] && b === 0 ? HATCH : undefined);
        if (a >= 7) put(a, b, 2, PLANKS);
      }
    }
  }
  // the hatch's ladder down into the hold, on its aft wall; barrels of fish and a chest in the hold
  for (const h of [0, -1]) put(HOLD[0], 0, h, LADDER, { way: [1, 0] });
  for (const [a, b] of [[-3, 2], [-3, -2], [-2, 2], [3, -2], [4, -2], [4, 2]]) put(a, b, -1, BARREL, BARREL_UP);
  put(5, 2, -1, BARREL, BARREL_UP);
  // a step up onto the raised bow
  for (const b of [-1, 0, 1]) put(6, b, 2, "minecraft:spruce_stairs", { stairs: [1, 0] });
  // the wheelhouse: white walls, windows all round, an open door aft; a chart table and the captain's chest inside
  for (let a = 1; a <= 5; a++) {
    for (let b = -2; b <= 2; b++) {
      const wall = a === 1 || a === 5 || Math.abs(b) === 2;
      for (let h = 2; h <= 4; h++) {
        if (!wall) continue;
        if (a === 1 && b === 0 && h <= 3) continue;
        const corner = (a === 1 || a === 5) && Math.abs(b) === 2;
        put(a, b, h, h === 3 && !corner ? "minecraft:glass_pane" : "minecraft:white_concrete");
      }
      put(a, b, 5, "minecraft:white_concrete");
    }
  }
  put(4, -1, 2, "minecraft:lectern", { card: [-1, 0] });
  put(2, 1, 2, "minecraft:chest", { card: [0, -1], loot });
  put(3, 0, 4, LANTERN, { hanging: true });
  // the mast on its roof: a radar bar, a lantern on top, a flag
  for (let h = 6; h <= 10; h++) put(3, 0, h, FENCE);
  for (const b of [-1, 1]) put(3, b, 9, "minecraft:iron_bars");
  put(3, 0, 11, LANTERN, { hanging: false });
  put(2, 0, 10, colours[0] === "minecraft:dark_oak_planks" ? "minecraft:red_wool" : "minecraft:white_wool");
  put(1, 0, 10, colours[0] === "minecraft:dark_oak_planks" ? "minecraft:red_wool" : "minecraft:white_wool");
  // the bow's light
  put(10, 0, 3, FENCE);
  put(10, 0, 4, LANTERN, { hanging: false });
  // the working deck aft: fish barrels, the net drum with its net, the gantry over the stern with its chains
  for (const [a, b, h] of [[-1, 2, 2], [-1, -2, 2], [0, 2, 2], [-1, 2, 3]]) put(a, b, h, BARREL, BARREL_UP);
  for (let b = -2; b <= 2; b++) put(-7, b, 2, "minecraft:dark_oak_log", { axis: [0, 1] });
  for (let b = -1; b <= 1; b++) put(-7, b, 3, "minecraft:green_wool");
  for (const b of [-2, 2]) for (let h = 2; h <= 6; h++) put(-10, b, h, "minecraft:stripped_dark_oak_log");
  for (let b = -2; b <= 2; b++) put(-10, b, 7, "minecraft:stripped_dark_oak_log", { axis: [0, 1] });
  for (const b of [-1, 1]) for (let h = 4; h <= 6; h++) put(-10, b, h, CHAIN, { axis: [0, 0] });
  const used = new Set(cells.map((c) => `${c.a},${c.b},${c.h}`));
  return { cells, keep: keep.filter((c) => !used.has(`${c.a},${c.b},${c.h}`)), length: 23, beam: 7 };
}

/**
 * The cells of a submarine, 31 long (and its propeller) and 7 across, its bow at a 15: a round hull (its axis 2 under
 * the water's surface, so its deck is just over it), whole blocks wherever it touches the water and dry inside; the
 * conning tower with a hatch on top and a ladder down, a ladder up its back, a periscope and a light; planes on the
 * tower, planes and fins at the stern, a copper propeller; portholes under the water; inside, the torpedo room, the
 * control room (its consoles and chart table under the tower), the bunks with a chest, the engine room, lanterns.
 */
export function submarineCells(colours) {
  const [hullId, trim] = colours;
  const AX = -2;
  const rad = (a) => (a > 15 || a < -15 ? -1 : a > 10 ? 3 * Math.sqrt(Math.max(0, 1 - ((a - 10) / 5.6) ** 2)) : a >= -8 ? 3 : 3 * (1 - Math.pow((-8 - a) / 8.5, 1.5)));
  const outer = new Set();
  const K = (a, b, h) => `${a},${b},${h}`;
  const dist = (b, h) => Math.hypot(b, h - AX);
  for (let a = -15; a <= 15; a++) {
    const R = rad(a);
    if (R < 0) continue;
    for (let b = -4; b <= 4; b++) for (let h = -6; h <= 2; h++) if (dist(b, h) <= R + 0.5) outer.add(K(a, b, h));
  }
  const inside = new Set();
  for (const k of outer) {
    const [a, b, h] = k.split(",").map(Number);
    if (dist(b, h) > rad(a) - 0.6 || a > 13 || a < -12) continue;
    if ([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].every(([p, q, r]) => outer.has(K(a + p, b + q, h + r)))) inside.add(k);
  }
  const cells = [];
  const keep = [];
  const taken = new Set();
  const put = (a, b, h, id, st) => {
    taken.add(K(a, b, h));
    cells.push({ a, b, h, id, st });
  };
  // the floor inside: the lowest row of each column of it
  const floor = (a, b, h) => inside.has(K(a, b, h)) && !inside.has(K(a, b, h - 1));
  const shaft = (a, b, h) => a === 4 && b === 0 && h >= 1;
  for (const k of outer) {
    const [a, b, h] = k.split(",").map(Number);
    if (shaft(a, b, h)) continue;
    if (!inside.has(k)) {
      const port = Math.abs(b) === 3 && h === AX + 1 && a >= -8 && a <= 10 && ((a + 30) % 3) === 0;
      put(a, b, h, port ? "minecraft:glass" : hullId);
    } else if (floor(a, b, h)) put(a, b, h, "minecraft:polished_andesite");
  }
  // the conning tower: 5 long, 3 across, 3 high over the deck, its bridge on top, the hatch and the shaft down
  for (let a = 2; a <= 6; a++) {
    for (let b = -1; b <= 1; b++) {
      for (let h = 2; h <= 4; h++) if (!shaft(a, b, h)) put(a, b, h, hullId);
      if (!shaft(a, b, 5)) put(a, b, 5, trim);
    }
  }
  put(4, 0, 5, "minecraft:spruce_trapdoor", HATCH);
  for (let h = 4; h >= -4; h--) if (!taken.has(K(4, 0, h))) put(4, 0, h, LADDER, { way: [1, 0] });
  // the ladder's wall inside the hull: the periscope's column
  for (let h = -4; h <= 0; h++) if (inside.has(K(3, 0, h)) && !taken.has(K(3, 0, h))) put(3, 0, h, "minecraft:iron_block");
  // the ladder up the tower's back; the periscope and a light on the bridge
  for (let h = 2; h <= 5; h++) put(1, 0, h, LADDER, { way: [-1, 0] });
  for (const h of [6, 7]) put(5, 0, h, "minecraft:iron_bars");
  put(5, 0, 8, trim);
  put(2, 0, 6, "minecraft:end_rod", { up: true });
  // planes on the tower; planes and fins at the stern; the propeller
  for (const b of [-3, -2, 2, 3]) put(4, b, 3, trim);
  {
    let w = 0;
    while (outer.has(K(-12, w + 1, AX))) w++;
    for (const b of [w + 1, w + 2]) for (const sgn of [-1, 1]) put(-12, sgn * b, AX, trim);
  }
  for (const a of [-14, -13]) {
    let topH = -9;
    let botH = 9;
    for (let h = -6; h <= 2; h++) {
      if (outer.has(K(a, 0, h))) {
        topH = Math.max(topH, h);
        botH = Math.min(botH, h);
      }
    }
    for (const h of [topH + 1, topH + 2, botH - 1, botH - 2]) put(a, 0, h, trim);
  }
  for (const [b, h] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1]]) put(-16, b, AX + h, "minecraft:waxed_cut_copper");
  // inside: the torpedo room (tubes and torpedoes), the control room, the bunks and their chest, the engine room
  const free = (a, b, h) => inside.has(K(a, b, h)) && !taken.has(K(a, b, h));
  for (const b of [-1, 1]) if (free(13, b, -3)) put(13, b, -3, "minecraft:dispenser", { face: [1, 0] });
  for (let a = 9; a <= 11; a++) for (const b of [-2, 2]) if (free(a, b, -2)) put(a, b, -2, "minecraft:iron_block");
  for (let a = 2; a <= 6; a++) {
    for (const b of [-2, 2]) {
      if (free(a, b, -2)) put(a, b, -2, "minecraft:smooth_stone");
      if (free(a, b, -1)) put(a, b, -1, "minecraft:redstone_lamp");
    }
  }
  if (free(6, 0, -3)) put(6, 0, -3, "minecraft:lectern", { card: [-1, 0] });
  for (let a = -6; a <= -2; a++) for (const b of [-2, 2]) if (free(a, b, -2)) put(a, b, -2, "minecraft:white_wool");
  if (free(-7, 1, -3)) put(-7, 1, -3, "minecraft:chest", { card: [0, -1], loot: "submarine" });
  if (free(-7, -1, -3)) put(-7, -1, -3, BARREL, BARREL_UP);
  for (let a = -11; a <= -9; a++) for (const b of [-2, -1, 1, 2]) for (const h of [-3, -2]) if (free(a, b, h)) put(a, b, h, Math.abs(b) === 1 && h === -3 ? "minecraft:blast_furnace" : "minecraft:iron_block", Math.abs(b) === 1 && h === -3 ? { card: [0, -b] } : undefined);
  for (const a of [-9, -4, 1, 8]) if (free(a, 0, 0)) put(a, 0, 0, LANTERN, { hanging: true });
  for (const k of inside) {
    if (taken.has(k)) continue;
    const [a, b, h] = k.split(",").map(Number);
    keep.push({ a, b, h });
  }
  for (let h = 1; h <= 4; h++) if (!taken.has(K(4, 0, h))) keep.push({ a: 4, b: 0, h });
  return { cells, keep, length: 33, beam: 7 };
}

/** A sailboat's pennant colours. */
export const PENNANTS = Object.freeze(["minecraft:blue_wool", "minecraft:red_wool", "minecraft:yellow_wool", "minecraft:lime_wool"]);

/**
 * The cells of a sailboat `len` long (odd) and 3 across, its bow at a (len - 1) / 2: a spruce hull at the water's
 * surface with its sides one higher, a mast, a white mainsail and jib, a pennant (as the mythic towns' boats).
 */
export function sailboatCells(len, pennant) {
  const half = (len - 1) / 2;
  const cells = [];
  const put = (a, b, h, id) => cells.push({ a, b, h, id });
  for (let a = -half; a <= half; a++) {
    for (let b = -1; b <= 1; b++) {
      const tip = Math.abs(a) === half;
      if (tip && b !== 0) continue;
      put(a, b, 0, PLANKS);
      if (tip || b !== 0) put(a, b, 1, PLANKS);
    }
  }
  for (let h = 1; h <= 6; h++) put(0, 0, h, FENCE);
  for (const [a, h] of [[-1, 2], [-2, 2], [-1, 3], [-2, 3], [-1, 4], [-2, 4], [-1, 5], [1, 2], [2, 2], [1, 3], [1, 4]]) put(a, 0, h, "minecraft:white_wool");
  put(-1, 0, 6, pennant);
  return { cells, keep: [], length: len, beam: 3 };
}

/** The states a cell's block takes in a frame facing fx fz (its local ways turned into the world's). */
function statesIn(F, c) {
  const st = c.st;
  if (!st) return undefined;
  if (st.stairs) return { weirdo_direction: STAIRS[CARD(...F.way(...st.stairs))], upside_down_bit: false };
  if (st.way) return { facing_direction: FACING[CARD(...F.way(...st.way))] };
  if (st.face) return { facing_direction: FACING[CARD(...F.way(...st.face))], triggered_bit: false };
  if (st.card) return { "minecraft:cardinal_direction": CARD(...F.way(...st.card)) };
  if (st.axis) {
    const [wx] = F.way(...st.axis);
    return { pillar_axis: st.axis[0] === 0 && st.axis[1] === 0 ? "y" : wx !== 0 ? "x" : "z" };
  }
  if (st.up) return { facing_direction: 1 };
  if (st.loot) return undefined;
  return st;
}

/**
 * The harbour's blocks: sh.harbour = { blocks Map("x,y,z" -> [id, states]), decor (the same, put in last), keep (the
 * air inside the ships, kept dry), tops Map(column -> the block on top: the quay, the promenade, the huts' floors),
 * chests [{ x, y, z, loot }], boats [{ x, y, z }] (where the boats anyone can take out are put), and what's where:
 * piers, ships, huts, stalls, lighthouse }.
 */
function* harbourSites(isl, sh) {
  const h = harbourOf(isl);
  const { hx, hz, B, G, y0, gx, gz, P, sp } = h;
  const s = isl.s;
  const blocks = new Map();
  const decor = new Map();
  const keep = new Set();
  const T = new Map();
  const chests = [];
  const key = (x, y, z) => `${x},${y},${z}`;
  const has = (x, y, z) => blocks.has(key(x, y, z)) || decor.has(key(x, y, z)) || keep.has(key(x, y, z));
  const set = (x, y, z, id, states) => {
    const k = key(x, y, z);
    (HARBOUR_DECOR.includes(id) ? decor : blocks).set(k, states ? [id, states] : [id]);
  };
  // the harbour's frame: u from its middle toward the island's far side (the lighthouse), v across
  const W = (u, v) => [hx + u * gx - v * gz, hz + u * gz + v * gx];
  const dq = (x, z) => Math.hypot(x - hx, z - hz);
  const col = (x, z) => at(sh, x, z);
  const pond = (x, z) => {
    const k = col(x, z);
    return k >= 0 && sh.kind[k] === POND;
  };
  const landAt = (x, z) => {
    const k = col(x, z);
    return k >= 0 && sh.kind[k] === LAND && sh.top[k] === G;
  };
  const tile = (x, z, id) => {
    const k = col(x, z);
    if (k >= 0 && sh.kind[k] === LAND) T.set(k, id);
  };
  const span = B + HARBOUR.flat + 2;
  // ---- the quay round the harbour: stone bricks from the top down past the bed beside it
  for (let z = hz - B - 2; z <= hz + B + 2; z++) {
    for (let x = hx - B - 2; x <= hx + B + 2; x++) {
      const d = dq(x, z);
      if (d < B || d >= B + 2 || !landAt(x, z)) continue;
      const u = unit(hash(s, x, z, 301));
      const id = u < 0.06 ? "minecraft:mossy_stone_bricks" : u < 0.09 ? "minecraft:cracked_stone_bricks" : SB;
      for (let y = G; y >= y0 - 4; y--) set(x, y, z, y === G ? id : SB);
      tile(x, z, id);
    }
  }
  // the promenade on the inland side, paved
  const promenade = (x, z) => {
    const d = dq(x, z);
    const u = (x - hx) * gx + (z - hz) * gz;
    return d >= B + 2 && d < B + 7 && u <= -0.17 * d;
  };
  for (let z = hz - span; z <= hz + span; z++) {
    for (let x = hx - span; x <= hx + span; x++) if (promenade(x, z) && landAt(x, z)) tile(x, z, "minecraft:polished_andesite");
  }
  yield;
  // ---- the piers: 3 wide, from the quay straight out toward the far side, lantern posts down their edges, a bell
  const piers = [];
  const firstWater = (v) => {
    for (let u = -B - 2; u <= 0; u++) {
      const [x, z] = W(u, v);
      if (pond(x, z)) return u;
    }
    return 0;
  };
  const pierFrom = (v0) => Math.max(firstWater(v0 - 1), firstWater(v0), firstWater(v0 + 1));
  /** Lays a pier along v0 from u0 (by the quay) to u1: its deck, its piles, its lantern posts. */
  function pier(v0, u0, u1) {
    for (let u = u0 - 1; u <= u1; u++) {
      for (let v = v0 - 1; v <= v0 + 1; v++) {
        const [x, z] = W(u, v);
        if (!pond(x, z) || has(x, G, z)) continue;
        set(x, G, z, PLANKS);
        // its piles, at its edges every 4 blocks, down to the bed
        if (v !== v0 && (u - u0) % 4 === 0) {
          const k = col(x, z);
          for (let y = y0; y > sh.floor[k]; y--) set(x, y, z, LOG);
        }
      }
    }
    for (let u = u1; u >= u0 + 2; u -= 5) {
      for (const v of [v0 - 1, v0 + 1]) {
        const [x, z] = W(u, v);
        set(x, G + 1, z, FENCE);
        set(x, G + 2, z, LANTERN, { hanging: false });
      }
    }
    return { v: v0, u0, u1, end: W(u1, v0) };
  }
  // the side piers now; the middle one once the submarine is moored, out as far as its tower
  for (const i of [0, 2]) {
    const v0 = (i - 1) * sp;
    piers[i] = pier(v0, pierFrom(v0), pierFrom(v0) + P - 1);
  }
  yield;
  // ---- the ships: each where it fits, in the harbour's water with water all round it, nothing else there
  const ships = [];
  /**
   * Builds `body` (from trawlerCells, submarineCells or sailboatCells) with its middle at u v, its bow toward +u (turned
   * `turn` quarter turns), if it fits.
   */
  function ship(body, u, v, deep, turn = 0) {
    let [fx, fz] = [gx, gz];
    for (let i = 0; i < turn; i++) [fx, fz] = [-fz, fx];
    const F = frame(...W(u, v), fx, fz);
    const room = new Set();
    for (const c of [...body.cells, ...body.keep]) {
      const [x, z] = F.at(c.a, c.b);
      const y = y0 + c.h;
      if (has(x, y, z)) return false;
      if (y <= y0) {
        if (!pond(x, z) || y <= sh.floor[col(x, z)] + (deep ? 1 : 0)) return false;
        room.add(`${x},${z}`);
      } else if (!pond(x, z) && !landAt(x, z)) return false;
    }
    // a block of open water all round it at the water's surface
    for (const c of room) {
      const [x, z] = c.split(",").map(Number);
      for (const [p, q] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const n = `${x + p},${z + q}`;
        if (room.has(n)) continue;
        if (!pond(x + p, z + q) || has(x + p, y0, z + q) || has(x + p, G, z + q)) return false;
      }
    }
    for (const c of body.cells) {
      const [x, z] = F.at(c.a, c.b);
      const st = statesIn(F, c);
      set(x, y0 + c.h, z, c.id, st);
      if (c.st?.loot) chests.push({ x, y: y0 + c.h, z, loot: c.st.loot });
    }
    for (const c of body.keep) {
      const [x, z] = F.at(c.a, c.b);
      keep.add(key(x, y0 + c.h, z));
    }
    ships.push({ u, v, length: body.length, at: W(u, v) });
    return true;
  }
  const colours = TRAWLER_COLOURS;
  const tr = [Math.floor(unit(hash(s, 7, 3, 7)) * colours.length)];
  tr.push((tr[0] + 1 + Math.floor(unit(hash(s, 7, 4, 7)) * (colours.length - 1))) % colours.length);
  // a trawler alongside each side pier, between it and the middle one, bow out; the submarine alongside the middle pier
  const trawlers = [];
  for (const [i, side] of [[0, -1], [1, 1]]) {
    // (the first one's skipper keeps a Deep Sea Rod in the wheelhouse chest)
    const body = trawlerCells(colours[tr[i]], i === 0 ? "captain" : "trawler");
    const v = side * (sp - 6);
    for (let u = -B + 10; u <= 0; u++) {
      if (ship(body, u, v, false)) {
        trawlers.push(ships[ships.length - 1]);
        break;
      }
    }
  }
  // a gangplank from each pier to its trawler's deck, through the gap in its bulwark
  for (const t of trawlers) {
    const side = Math.sign(t.v);
    for (const du of [-3, -2]) {
      const [x, z] = W(t.u + du, t.v + side * 4);
      if (!has(x, G, z) && pond(x, z)) set(x, G, z, PLANKS);
    }
  }
  const sub = submarineCells(SUB_COLOURS[Math.floor(unit(hash(s, 7, 5, 7)) * SUB_COLOURS.length)]);
  let subAt;
  for (let u = -B + 14; u <= B - 14 && !subAt; u++) {
    if (ship(sub, u, 6, true)) subAt = ships[ships.length - 1];
  }
  {
    const u0 = pierFrom(0);
    piers[1] = pier(0, u0, Math.max(u0 + P - 1, subAt ? subAt.u + 6 : -Infinity));
    // the harbour bell near its end, on the side away from the submarine
    const [x, z] = W(piers[1].u1 - 2, -1);
    set(x, G + 1, z, "minecraft:bell", { attachment: "standing", direction: 0, toggle_bit: false });
  }
  if (subAt) {
    // a gangplank from the middle pier to its deck, by the tower
    for (const du of [3, 4]) {
      for (let v = 2; v <= 4; v++) {
        const [x, z] = W(subAt.u + du, v);
        if (!has(x, G, z) && pond(x, z)) set(x, G, z, PLANKS);
      }
    }
  }
  yield;
  // ---- sailboats moored out in the harbour (a spruce hull at the water, a mast, a sail, a pennant), and buoys, red and
  // green, each with a light on it
  const sails = [];
  const nb = 3 + Math.floor(unit(hash(s, 7, 6, 7)) * 3);
  for (let t = 0; t < 60 && sails.length < nb; t++) {
    const a = (unit(hash(s, t, 61, 7)) - 0.5) * Math.PI * 1.4;
    const d = B * (0.35 + 0.4 * unit(hash(s, t, 62, 7)));
    const u = Math.round(Math.cos(a) * d);
    const v = Math.round(Math.sin(a) * d);
    const turn = Math.floor(unit(hash(s, t, 63, 7)) * 4);
    const pennant = PENNANTS[Math.floor(unit(hash(s, t, 64, 7)) * PENNANTS.length)];
    if (ship(sailboatCells(7, pennant), u, v, false, turn)) sails.push(ships.pop());
  }
  const buoys = [];
  for (let i = 0; i < 6; i++) {
    const a = ((i + 0.5) / 6 - 0.5) * Math.PI * 1.1;
    const u = Math.round(Math.cos(a) * B * 0.78);
    const v = Math.round(Math.sin(a) * B * 0.78);
    const [x, z] = W(u, v);
    let clear = pond(x, z);
    for (let dz = -2; dz <= 2 && clear; dz++) for (let dx = -2; dx <= 2 && clear; dx++) if (!pond(x + dx, z + dz) || has(x + dx, y0, z + dz) || has(x + dx, G, z + dz)) clear = false;
    if (!clear) continue;
    const paint = i % 2 ? "minecraft:green_concrete" : "minecraft:red_concrete";
    set(x, y0, z, paint);
    set(x, y0 + 1, z, paint);
    set(x, y0 + 2, z, LANTERN, { hanging: false });
    buoys.push([x, z]);
  }
  yield;
  // ---- the crane by the middle pier's foot: a post, a boom out over the water, a chain with a barrel on it
  {
    const mid = piers[1];
    const pu = mid.u0 - 2;
    const pv = -4;
    const [x, z] = W(pu, pv);
    if (landAt(x, z) && !has(x, G + 1, z)) {
      for (let y = G + 1; y <= G + 8; y++) set(x, y, z, LOG);
      const axis = gx !== 0 ? "x" : "z";
      for (let u = pu + 1; u <= pu + 7; u++) {
        const [bx, bz] = W(u, pv);
        set(bx, G + 8, bz, LOG, { pillar_axis: axis });
      }
      const [cx, cz] = W(pu + 7, pv);
      for (let y = G + 7; y >= G + 5; y--) set(cx, y, cz, CHAIN, { pillar_axis: "y" });
      set(cx, G + 4, cz, BARREL, BARREL_UP);
    }
  }
  // ---- two fish stalls on the promenade, between the piers: a counter (barrels and a smoker) under a striped awning
  const stalls = [];
  for (const v0 of [-Math.round(sp / 2), Math.round(sp / 2)]) {
    const u0 = -Math.round(Math.sqrt((B + 4.5) ** 2 - v0 * v0));
    const cells = [];
    for (let u = u0 - 1; u <= u0 + 1; u++) for (let v = v0 - 2; v <= v0 + 2; v++) cells.push([u, v]);
    if (!cells.every(([u, v]) => {
      const [x, z] = W(u, v);
      return landAt(x, z) && !has(x, G + 1, z) && !has(x, G + 4, z);
    })) continue;
    const F = frame(...W(u0, v0), gx, gz);
    for (let v = -1; v <= 1; v++) {
      const [x, z] = W(u0, v0 + v);
      if (v === 0) set(x, G + 1, z, "minecraft:smoker", statesIn(F, { st: { card: [-1, 0] } }));
      else set(x, G + 1, z, BARREL, BARREL_UP);
    }
    for (const [u, v] of [[u0 - 1, v0 - 2], [u0 - 1, v0 + 2], [u0 + 1, v0 - 2], [u0 + 1, v0 + 2]]) {
      const [x, z] = W(u, v);
      for (let y = G + 1; y <= G + 3; y++) set(x, y, z, FENCE);
    }
    for (const [u, v] of cells) {
      const [x, z] = W(u, v);
      set(x, G + 4, z, ((v - v0 + 10) & 1) === 0 ? "minecraft:red_wool" : "minecraft:white_wool");
    }
    stalls.push({ u: u0, v: v0 });
  }
  yield;
  // ---- the fishing huts behind the promenade, facing the harbour, and the fish store behind the middle pier: spruce on
  // a cobblestone sill, log corners, windows, an open door, a pitched roof of stairs overhanging by one, the gables
  // filled in; inside, a hut has a barrel, a smoker, a crafting table and a lantern, the store barrels and a lantern
  /**
   * A building with its front (and door) facing the harbour at d = B + 9 along v0: walls hw either side of v0 and
   * `deep` back, `tall` high; a door `door` either side of v0 and `doorTall` high. Returns its frame, or undefined if
   * it doesn't fit (all its ground, overhang included, the quay's level and nothing built there).
   */
  function building(v0, hw, deep, tall, door, doorTall, roof, ridge) {
    const uf = -Math.round(Math.sqrt((B + 9) ** 2 - v0 * v0));
    const ub = uf - deep + 1;
    for (let u = ub - 1; u <= uf + 1; u++) {
      for (let v = v0 - hw - 1; v <= v0 + hw + 1; v++) {
        const [x, z] = W(u, v);
        if (!landAt(x, z)) return undefined;
        for (let y = G + 1; y <= G + tall + hw + 2; y++) if (has(x, y, z)) return undefined;
      }
    }
    const F = frame(...W(uf, v0), gx, gz);
    for (let u = ub; u <= uf; u++) {
      for (let v = v0 - hw; v <= v0 + hw; v++) {
        const [x, z] = W(u, v);
        const dv = Math.abs(v - v0);
        const wall = u === ub || u === uf || dv === hw;
        tile(x, z, wall ? "minecraft:cobblestone" : PLANKS);
        if (!wall) continue;
        const post = ((u === ub || u === uf) && dv === hw) || (dv === hw && (u - ub) % 4 === 0 && hw > 3);
        for (let y = G + 1; y <= G + tall; y++) {
          if (u === uf && dv <= door && y <= G + doorTall) continue;
          const window = !post && y === G + 2 && ((dv === hw && (u - ub) % 4 === 2) || (u === uf && dv === door + 1) || (u === ub && dv === 0));
          set(x, y, z, post ? "minecraft:stripped_spruce_log" : window ? "minecraft:glass_pane" : PLANKS);
        }
      }
    }
    // the roof: the ridge along u, the slopes to either side, overhanging by one; the gables filled in
    const top = G + tall + hw + 1;
    for (let u = ub - 1; u <= uf + 1; u++) {
      for (let dv = -hw - 1; dv <= hw + 1; dv++) {
        const [x, z] = W(u, v0 + dv);
        if (dv === 0) set(x, top, z, ridge);
        else set(x, G + tall + (hw + 1 - Math.abs(dv)), z, roof, statesIn(F, { st: { stairs: [0, dv > 0 ? -1 : 1] } }));
      }
    }
    for (const u of [ub, uf]) {
      for (let dv = -hw + 1; dv <= hw - 1; dv++) {
        const [x, z] = W(u, v0 + dv);
        for (let y = G + tall + 1; y < G + tall + (hw + 1 - Math.abs(dv)); y++) set(x, y, z, PLANKS);
      }
    }
    // a path from its door to the promenade
    for (let u = uf + 1; u <= uf + 3; u++) {
      for (let v = v0 - door; v <= v0 + door; v++) {
        const [x, z] = W(u, v);
        const k = col(x, z);
        if (k >= 0 && !T.has(k) && landAt(x, z)) tile(x, z, "minecraft:grass_path");
      }
    }
    return { F, uf, ub, top, at: (du, dv) => /** @type {[number, number]} */ (W(uf - du, v0 + dv)) };
  }
  const huts = [];
  for (const v0 of [-1.5 * sp, -0.5 * sp, 0.5 * sp, 1.5 * sp].map(Math.round)) {
    const b = building(v0, 3, 6, 3, 0, 2, "minecraft:spruce_stairs", PLANKS);
    if (!b) continue;
    set(...pt(b.at(4, -2), G + 1), BARREL, BARREL_UP);
    set(...pt(b.at(4, 2), G + 1), "minecraft:smoker", statesIn(b.F, { st: { card: [1, 0] } }));
    set(...pt(b.at(3, 2), G + 1), "minecraft:crafting_table");
    set(...pt(b.at(2, 0), b.top - 1), LANTERN, { hanging: true });
    huts.push({ u: b.uf, v: v0, door: W(b.uf, v0) });
  }
  let store;
  {
    const b = building(0, 4, 9, 4, 1, 3, "minecraft:dark_oak_stairs", "minecraft:dark_oak_planks");
    if (b) {
      for (let du = 6; du <= 7; du++) {
        for (const dv of [-3, -2, 2, 3]) {
          set(...pt(b.at(du, dv), G + 1), BARREL, BARREL_UP);
          if (Math.abs(dv) === 3) set(...pt(b.at(du, dv), G + 2), BARREL, BARREL_UP);
        }
      }
      set(...pt(b.at(2, -3), G + 1), "minecraft:crafting_table");
      for (const du of [2, 6]) set(...pt(b.at(du, 0), b.top - 1), LANTERN, { hanging: true });
      store = { u: b.uf, v: 0, door: W(b.uf, 0) };
    }
  }
  yield;
  // ---- the lighthouse on the far side, near the shore: red and white, a ladder up inside, its light in glass at the
  // top with a gallery round it, a red cap
  let lighthouse;
  {
    const lu = B + 9;
    const [lx, lz] = W(lu, 0);
    const disc = (R) => {
      const out = [];
      const n = Math.ceil(R);
      for (let dz = -n; dz <= n; dz++) for (let dx = -n; dx <= n; dx++) if (Math.hypot(dx, dz) <= R) out.push([dx, dz, Math.hypot(dx, dz)]);
      return out;
    };
    if (disc(4.3).every(([dx, dz]) => landAt(lx + dx, lz + dz))) {
      const [ix, iz] = W(lu + 2, 0);
      const ladder = (y) => set(ix, y, iz, LADDER, { facing_direction: FACING[CARD(-gx, -gz)] });
      for (const [dx, dz, d] of disc(3.3)) {
        const x = lx + dx;
        const z = lz + dz;
        if (d <= 2.3) {
          tile(x, z, "minecraft:smooth_stone");
          continue;
        }
        tile(x, z, "minecraft:stone_bricks");
        const toward = (dx * -gx + dz * -gz) / Math.max(1e-9, d);
        for (let y = G + 1; y <= G + 18; y++) {
          // its door, toward the harbour; two windows above it
          if (toward > 0.85 && (y <= G + 2 || y === G + 9 || y === G + 15)) continue;
          const band = Math.floor((y - G - 1) / 4) % 2 === 1;
          set(x, y, z, band ? "minecraft:red_concrete" : "minecraft:white_concrete");
        }
      }
      for (let y = G + 1; y <= G + 19; y++) ladder(y);
      for (const [dx, dz] of disc(4.3)) if (!(lx + dx === ix && lz + dz === iz)) set(lx + dx, G + 19, lz + dz, "minecraft:smooth_stone");
      for (const [dx, dz, d] of disc(4.3)) if (d > 3.4) set(lx + dx, G + 20, lz + dz, "minecraft:iron_bars");
      for (const [dx, dz, d] of disc(3.3)) {
        if (d <= 2.3) continue;
        const toward = (dx * -gx + dz * -gz) / Math.max(1e-9, d);
        for (let y = G + 20; y <= G + 22; y++) if (!(toward > 0.85 && y <= G + 21)) set(lx + dx, y, lz + dz, "minecraft:glass");
      }
      for (const y of [G + 20, G + 21]) set(lx, y, lz, SEA_LANTERN);
      set(lx, G + 22, lz, "minecraft:glowstone");
      for (const [R, y] of [[3.3, G + 23], [2.3, G + 24], [1.3, G + 25]]) for (const [dx, dz] of disc(R)) set(lx + dx, y, lz + dz, "minecraft:red_concrete");
      set(lx, G + 26, lz, "minecraft:end_rod", { facing_direction: 1 });
      lighthouse = { x: lx, z: lz, top: G + 26 };
    }
  }
  yield;
  // ---- lamp posts round the quay, every 12 blocks or so, where nothing else is
  const nL = Math.round((2 * Math.PI * (B + 1)) / 12);
  for (let i = 0; i < nL; i++) {
    const a = (i * 2 * Math.PI) / nL + 0.13;
    const x = Math.round(hx + Math.cos(a) * (B + 1));
    const z = Math.round(hz + Math.sin(a) * (B + 1));
    if (!landAt(x, z)) continue;
    let clear = true;
    for (let dz = -2; dz <= 2 && clear; dz++) for (let dx = -2; dx <= 2 && clear; dx++) for (let y = G; y <= G + 4; y++) if (has(x + dx, y, z + dz) && !(y === G && blocks.get(key(x + dx, y, z + dz))?.[0]?.includes("stone_bricks"))) clear = false;
    if (!clear) continue;
    set(x, G + 1, z, FENCE);
    set(x, G + 2, z, FENCE);
    set(x, G + 3, z, LANTERN, { hanging: false });
  }
  // a few barrels by the piers' feet
  for (const p of piers) {
    for (const [du, dv] of [[-3, 2], [-3, 3], [-4, 2]]) {
      const [x, z] = W(p.u0 + du, p.v + dv);
      if (landAt(x, z) && !has(x, G + 1, z) && !has(x, G + 2, z)) set(x, G + 1, z, BARREL, BARREL_UP);
    }
  }
  // the boats anyone can take out: by the middle pier, on the side away from the submarine
  const boats = [];
  for (const du of [3, 8]) {
    const [x, z] = W(piers[1].u0 + du, -4);
    if (pond(x, z) && !has(x, y0, z) && !has(x, G, z)) boats.push({ x: x + 0.5, y: y0 + 0.9, z: z + 0.5 });
  }
  sh.harbour = { blocks, decor, keep, tops: T, chests, boats, piers, ships, trawlers, sub: subAt, sails, buoys, huts, store, stalls, lighthouse, h };
  // (the trees keep off the harbour, its town and its lighthouse)
  sh.patches.push({ x: hx, z: hz, r: B + HARBOUR.flat + 4 });
  if (lighthouse) sh.patches.push({ x: lighthouse.x, z: lighthouse.z, r: 8 });
}

const pt = ([x, z], y) => /** @type {[number, number, number]} */ ([x, y, z]);

/** A huge island's top block on a column: the quay, the promenade, the huts' floors and paths as laid; grass. */
function hugeTopOf(isl, sh, k) {
  return sh.harbour?.tops.get(k) ?? "minecraft:grass_block";
}

/** The harbour's bed: sand by the quay, then sand, gravel and clay in patches; it goes in after the stone under it. */
function harbourBedOf(isl, sh, k) {
  const x = sh.x0 + (k % sh.W);
  const z = sh.z0 + Math.floor(k / sh.W);
  if (sh.top[k] - sh.floor[k] <= 4) return "minecraft:sand";
  const n = noise2((isl.s ^ 0xc) >>> 0, x / 6, z / 6);
  return n > 0.45 ? "minecraft:gravel" : n < -0.45 ? "minecraft:clay" : "minecraft:sand";
}

function* harbourBed(isl, sh, cols, batches) {
  const xOf = (k) => sh.x0 + (k % sh.W);
  const zOf = (k) => sh.z0 + Math.floor(k / sh.W);
  for (const block of ["minecraft:clay", "minecraft:gravel", "minecraft:sand"]) {
    yield* batches(block, (function* () {
      for (const k of cols) if (sh.kind[k] === POND && harbourBedOf(isl, sh, k) === block) yield { x: xOf(k), y: sh.floor[k], z: zOf(k) };
    })());
  }
}

/** Seagrass on the harbour's sand, put into its water once it's in. */
function* harbourSeagrass(isl, sh, cols, taken, batches) {
  const xOf = (k) => sh.x0 + (k % sh.W);
  const zOf = (k) => sh.z0 + Math.floor(k / sh.W);
  for (const op of batches("minecraft:seagrass", (function* () {
    for (const k of cols) {
      if (sh.kind[k] !== POND || harbourBedOf(isl, sh, k) !== "minecraft:sand") continue;
      const x = xOf(k);
      const z = zOf(k);
      const y = sh.floor[k] + 1;
      if (taken.has(`${x},${y},${z}`) || unit(hash(isl.s, x, z, 303)) >= 0.18) continue;
      yield { x, y, z };
    }
  })())) yield { ...op, into: "minecraft:water" };
}

/** A huge island's trees: groves where the woods are (a broad noise, about 2 in 5 of its land), only the odd one in the meadows between. */
function hugeTrees(isl, sh) {
  const out = [];
  const total = COMMON_TREES.reduce((n, [, w]) => n + w, 0);
  for (let gz = -sh.R; gz <= sh.R; gz += 6) {
    for (let gx = -sh.R; gx <= sh.R; gx += 6) {
      const x = isl.x + gx + Math.floor(unit(hash(isl.s, gx, gz, 21)) * 5) - 2;
      const z = isl.z + gz + Math.floor(unit(hash(isl.s, gx, gz, 22)) * 5) - 2;
      const wood = fbm2((isl.s ^ 0xd) >>> 0, x / 40, z / 40);
      if (unit(hash(isl.s, gx, gz, 23)) >= (wood > 0.05 ? 0.55 : 0.04)) continue;
      const k = at(sh, x, z);
      if (k < 0 || sh.kind[k] !== LAND || sh.edge[k] > 80 || nearWater(sh, x, z, 3)) continue;
      if (Math.abs(sh.top[at(sh, x + 1, z)] - sh.top[k]) > 1 || Math.abs(sh.top[at(sh, x, z + 1)] - sh.top[k]) > 1) continue;
      if (sh.patches.some((q) => Math.hypot(x - q.x, z - q.z) < q.r + 3)) continue;
      let u = unit(hash(isl.s, gx, gz, 25)) * total;
      let id = COMMON_TREES[0][0];
      for (const [t, w] of COMMON_TREES) {
        if (u < w) {
          id = t;
          break;
        }
        u -= w;
      }
      out.push({ id, x, y: sh.top[k] + 1, z });
    }
  }
  return out;
}

/**
 * Whether the island is built in parts (a huge one, 0.1.280), and its parts: four quarters, each { clip(x, z): whether
 * a block there is this part's, from to (its box, 12 blocks wider all round, so a tree or a vein reaching over is
 * loaded too) }. Every block of the island is in exactly one part.
 */
export function partsOf(isl) {
  if (isl.kind !== "huge") return undefined;
  const R = reachOf(isl) + 1;
  const pad = 12;
  const out = [];
  for (const [x0, x1] of [[isl.x - R, isl.x - 1], [isl.x, isl.x + R]]) {
    for (const [z0, z1] of [[isl.z - R, isl.z - 1], [isl.z, isl.z + R]]) {
      out.push({ x0, x1, z0, z1, clip: (x, z) => x >= x0 && x <= x1 && z >= z0 && z <= z1, from: { x: x0 - pad, z: z0 - pad }, to: { x: x1 + pad, z: z1 + pad } });
    }
  }
  return out;
}

/** The box round all of an island's water (its harbour's), one block wider, or undefined if it has none. */
export function waterBoxOf(sh) {
  let x0 = Infinity;
  let x1 = -Infinity;
  let z0 = Infinity;
  let z1 = -Infinity;
  for (let k = 0; k < sh.kind.length; k++) {
    if (sh.kind[k] !== POND) continue;
    const x = sh.x0 + (k % sh.W);
    const z = sh.z0 + Math.floor(k / sh.W);
    x0 = Math.min(x0, x);
    x1 = Math.max(x1, x);
    z0 = Math.min(z0, z);
    z1 = Math.max(z1, z);
  }
  return x0 === Infinity ? undefined : { from: { x: x0 - 1, z: z0 - 1 }, to: { x: x1 + 1, z: z1 + 1 } };
}

/**
 * The nearest huge island (a harbour) to x z in the fishing sky, within `regions` regions of 2 by 2 cells each way (1
 * region in 12 holds one, so one is nearly always within a few hundred blocks). For the /zoocraft:harbour test command.
 */
export function skyHugeNear(seed, x, z, regions = 6, legacy = LEGACY) {
  const s2 = seed2Of(seed);
  const span = LAYOUT2.cell * 2;
  const rx0 = Math.floor(x / span);
  const rz0 = Math.floor(z / span);
  let best;
  let bestD = Infinity;
  for (let rz = rz0 - regions; rz <= rz0 + regions; rz++) {
    for (let rx = rx0 - regions; rx <= rx0 + regions; rx++) {
      if (regionKind2(s2, rx, rz) !== "huge") continue;
      const isl = skyIslandOf(seed, rx * 2, rz * 2, legacy);
      if (!isl || isl.kind !== "huge") continue;
      const d = Math.hypot(isl.x - x, isl.z - z);
      if (d < bestD) {
        best = isl;
        bestD = d;
      }
    }
  }
  return best;
}

/** Where /zoocraft:harbour puts a player: on the promenade in front of the fish store, facing the harbour. */
export function harbourStand(isl) {
  const h = harbourOf(isl);
  const u = -(h.B + 5);
  return { x: h.hx + u * h.gx, y: h.G + 1, z: h.hz + u * h.gz, yaw: (Math.atan2(-h.gx, h.gz) * 180) / Math.PI };
}

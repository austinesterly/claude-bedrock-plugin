import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { show } from "./forms.js";
import { system } from "@minecraft/server";
import { vetBoost } from "../residents/vetRules.js";
import { BALANCE } from "../data/balance.js";
import { SPECIES } from "../data/species.js";
import { recordSoldBack, getPark, claimPark, can, denyText, roleOf, setMember, insidePark, insideWords, setEntrance, setOpen, setSetting, setAdmission, knownPlayers, transferPark, parkOf, withPark, allParks, parkName, ownedPark, claimProblem, parkAt, insideParkColumn, renamePark, parkById, memberOfAny } from "../park/park.js";
import { balanceText, sandboxLine, settingsText, memberRows, ROLE_LABEL, ROLE_TEXT, GIVABLE_ROLES, canHandOver } from "../park/rules.js";
import { spend, earn, recent } from "../economy/economy.js";
import { sellBackLeft } from "../economy/ledger.js";
import { allExhibits, getExhibit } from "../exhibits/exhibits.js";
import { inHolding, allAnimals, welfare } from "../animals/animals.js";
import { band } from "../animals/welfare.js";
import { tutorialStatus, claimKit } from "../quests/tutorial.js";
import { expeditionStatus } from "../quests/expedition.js";
import { conservationStatus, releaseStatus } from "../quests/conservation.js";
import { packFromHolding } from "../transport/carriers.js";
import { allFixtures } from "../equipment/fixtures.js";
import { ratingNow } from "../visitors/visitors.js";
import { priceDemand, valueScore } from "../visitors/demand.js";
import { admission, pairedBooth, allPoints } from "../visitors/points.js";
import { allServices, serviceText, stockFromInventory, buyStock, setSnackPrice, SERVICE_NAMES } from "../visitors/services.js";
import { snackShare, amenityLines, facilityLines } from "../visitors/serviceRules.js";
import { pathSummary } from "../visitors/network.js";
import { fenceSummary } from "../park/fence.js";
import { currentMix } from "../visitors/guests.js";
import { mixText } from "../visitors/visitorMix.js";
import { newId } from "../core/ids.js";
import { openExhibit, openAnimal } from "./clipboard.js";
import { adoptGateNear } from "../park/gate.js";
import { countItem, giveItem, takeItem, message, onlinePlayers } from "../platform/mc.js";
import { db } from "../persistence/db.js";
import { allKeepers } from "../staff/staff.js";
import { tourSummary } from "../visitors/tours.js";
import { rideSummary } from "../visitors/rides.js";
import { fieldJournal } from "./fieldJournal.js";
import { RATIONS, rationPlural } from "../data/items.js";
import { siteAt, parkOfSite, claimSite, startOldPark, mayStartOldPark } from "../starter/site.js";
import { SITE } from "../starter/sitePlan.js";
import { residentsOfPark, residentState, moodNow } from "../residents/residents.js";
import { tierWith } from "../residents/bonds.js";
import { TIER_NAMES } from "../residents/bondRules.js";
import { doingText } from "../residents/residentRules.js";
import { RESIDENTS, residentById, unlockWords, MOOD_WORDS } from "../data/residents.js";
import { allResidents } from "../residents/residents.js";
import { isUnlocked } from "../residents/people.js";
import { progressOf, zooOnDisplay } from "../residents/unlocks.js";
import { residentPage } from "./mailboxMenu.js";

// Park Deed menu: claim the park, then the Park Ledger dashboard (overview, animals, exhibits,
// finances, journal, supplies, holding, members, settings). Every button is an intent; the
// owning module checks and commits.
//
// 0.1.114 (several parks a world): the Deed opens the player's park (park/park.js parkOf: the park they stand in if
// they belong to it, else their own, else one they belong to, else the park they stand in); a block's menu (the
// entrance gate, a Ticket Booth, a Snack Stand) the park the block stands in. A form's answer comes back outside
// any scope, so every part that reads the park runs inside withPark, and a page is handed its park.

const ITEM_LABEL = { "zoocraft:leafy_ration": "Leafy Rations", "zoocraft:fish_ration": "Fish Rations", "zoocraft:small_carrier": "Small Carrier", "zoocraft:livestock_crate": "Livestock Crate", "zoocraft:reinforced_crate": "Reinforced Crate", "minecraft:packed_ice": "Packed Ice", "zoocraft:mineral_pellets": "Mineral Pellets", "zoocraft:thermal_carrier": "Thermal Carrier", "minecraft:charcoal": "Charcoal", "zoocraft:ember_ration": "Ember Rations", "zoocraft:molten_plankton": "Molten Plankton Feed", "minecraft:warped_fungus": "Warped Fungi", "zoocraft:chorus_browse": "Chorus Browse", "zoocraft:stabilized_carrier": "Stabilized Carrier", "zoocraft:insect_ration": "Insect Rations" };
// The rations not named above by their own names (0.1.88: the shop showed the newer ones, Fruit Rations on, by their ids).
const itemLabel = (item) => ITEM_LABEL[item] ?? (RATIONS[item] ? rationPlural(item) : item);

// Park Ledger dashboard (spec section 16): the overview first, then one page per area. The
// Research tab arrives with that system.
export async function openDeed(player) {
  // 0.1.114: the Deed of a player who belongs to no park is for claiming (inside someone's park it says so).
  const park = memberOfAny(player) ? parkOf(player) : undefined;
  if (!park) return claimFlow(player);
  const { form, actions } = withPark(park, () => deedForm(player, park));
  const res = await show(player, form);
  if (res && res.selection !== undefined) await actions[res.selection]?.();
}

function deedForm(player, park) {
  const role = roleOf(player.id);
  const r = ratingNow();
  const tut = tutorialStatus();
  const exp = expeditionStatus();
  const con = conservationStatus();
  const rel = releaseStatus();
  const tours = tourSummary();
  const rides = rideSummary();
  const warnings = topWarnings(3);
  const several = allParks().length > 1;
  const body = [
    ...(several ? [`§6${parkName(park)} §8(park ${park.number ?? 1} of ${allParks().length} in this world${ownedPark(player) && ownedPark(player).id !== park.id ? `; your own is ${parkName(ownedPark(player))}` : ""})`] : []),
    `§fZoo Coins: ${balanceText(park)}   §fRating: §f${r.stars} stars §7(score ${r.score})`,
    ...(sandboxLine(park) ? [sandboxLine(park)] : []),
    `§fStatus: ${park.open ? "§aOpen" : "§7Closed"}${park.entrance ? "" : " §7(no entrance gate yet)"}`,
    `§fPark edge: §7${capital(fenceSummary())}`,
    `§fToday: §7${park.today.guests} guests, ${park.today.revenue} coins`,
    `§fGuests say: ${r.complaintLine ? `§e${r.complaintLine}` : "§aThey're enjoying the park."}`,
    `§fVisitors: §7${mixText(currentMix())}`,
    `§fAnimals: §7${allAnimals().length}   §fExhibits: §7${allExhibits().length}   §fIn holding: §7${inHolding().length}`,
    `§fKeepers: §7${allKeepers().length} §8(hire and manage them at a Staff Room)`,
    ...(residentsOfPark(park.id).length ? [`§fResidents: §7${residentsLine(park, r)}`] : []),
    `§fTours: §7${tours.guides} guide${tours.guides === 1 ? "" : "s"}, ${tours.tours} tour${tours.tours === 1 ? "" : "s"} and ${tours.tickets} ticket${tours.tickets === 1 ? "" : "s"} today §8(${tours.desks ? "hire and manage guides at a Tour Desk" : "build a Tour Desk beside a path to run tours"})`,
    `§fRides: §7${rides.rays} Void Ray${rides.rays === 1 ? "" : "s"} on the Expedition, ${rides.rides} ride${rides.rides === 1 ? "" : "s"} and ${rides.tickets} ticket${rides.tickets === 1 ? "" : "s"} today §8(${rides.platforms ? "assign rays and set the price at an Expedition Platform" : "build an Expedition Platform beside a path under open sky"})`,
    `§fConservation: §7${rel.count} released to the wild${rel.count ? ` §8(+${Math.round(rel.boost * 100)}% guests a day)` : " §8(from an animal's page on the Exhibit Clipboard)"}`,
    "",
    warnings.length ? `§fNeeds attention:\n${warnings.map((w) => `${SEVERITY_COLOR[w.severity] ?? "§e"}- ${w.where}: ${w.text}`).join("\n")}` : "§aNothing needs attention.",
    tut.next ? `\n§bTutorial ${tut.done}/${tut.total}: §f${tut.next.title}` : "",
    exp.started && !exp.finished ? `\n§dEnd expedition ${exp.done}/${exp.total}: §f${exp.next.title}` : "",
    con.started && !con.finished ? `\n§2Conservation ${con.done}/${con.total}: §f${con.next.title}` : "",
    `\n§7Your role: ${ROLE_LABEL[role] ?? role}. §8${ROLE_TEXT[role] ?? ""}`,
  ].join("\n");
  const form = new ActionFormData().title(several ? `Park Ledger: ${parkName(park)}` : "Park Ledger").body(body);
  const actions = [];
  const add = (label, fn) => {
    form.button(label);
    actions.push(fn);
  };
  add("Animals", () => animalsList(player, park));
  add("Exhibits", () => exhibitsList(player, park));
  add("Finances", () => finances(player, park));
  add(tut.next ? `Journal §8(tutorial ${tut.done}/${tut.total})` : "Journal", () => journal(player, park));
  add("Field Journal", () => fieldJournal(player));
  add("Supply shop", () => shop(player, park));
  if (inHolding().length) add(`Recovery holding (${inHolding().length})`, () => holding(player, park));
  add(`Residents (${residentsOfPark(park.id).length})`, () => residentsList(player, park)); // 0.1.220: always, with who can move in
  if (role === "owner") add("Members", () => members(player, park));
  if (role === "owner") add("Settings", () => settings(player, park));
  if (!ownedPark(player) && !claimProblem(player)) add("Claim a park of your own here", () => claimFlow(player));
  add("Close", () => {});
  return { form, actions };
}

const SEVERITY_COLOR = { 3: "§c", 2: "§6", 1: "§e" };

// The park's residents (0.1.217): how many, and what they add to the rating.
function residentsLine(park, r) {
  const n = residentsOfPark(park.id).length;
  return `${n} living by the park${r.residents ? `, adding ${r.residents} to the rating's score` : ""} §8(their page: Residents)`;
}

// The Residents page (0.1.217): each of the park's residents, their mood and what they're doing; one opens their page.
async function residentsList(player, park) {
  const list = residentsOfPark(park.id).filter((rec) => residentById(rec.id));
  const r = withPark(park, () => ratingNow());
  // 0.1.220: everyone not living anywhere yet, unlocked (waiting for a home) or how far the zoo is towards their goal.
  const stats = zooOnDisplay();
  const housed = new Set(allResidents().map((x) => x.id));
  // 0.1.319: someone a story unlocks (Damien) isn't listed until it has
  const coming = RESIDENTS.filter((res) => !housed.has(res.id) && (res.unlock.kind !== "quest" || isUnlocked(res.id))).map((res) => {
    if (isUnlocked(res.id)) return `§a${res.name}§7: can move in. They need an empty home with its Resident Mailbox set to Move-in ON.`;
    const pr = progressOf(res, stats);
    return `§f${res.name}§7: ${unlockWords(res.unlock)} (${pr.have} of ${pr.need})`;
  });
  const body = [
    list.length ? `§fThe people living in homes whose path comes to ${parkName(park)}.` : `§fNobody lives in a home whose path comes to ${parkName(park)} yet.`,
    r.residents ? `§7Happy ones add §f${r.residents}§7 to the park's score (out of 100; 10 points are half a star).` : "§7Happy ones would add to the park's score: a point for each heart over 3, 5 at most.",
    ...(coming.length ? ["", "§fStill to move in:", ...coming] : []),
  ].join("\n");
  const form = new ActionFormData().title("Residents").body(body);
  for (const rec of list) {
    const s = residentState(rec);
    // 0.1.223: with the reader's friendship, and who they're following
    form.button(`${residentById(rec.id).name}\n§8${MOOD_WORDS[moodNow(rec)] ?? ""} · ${TIER_NAMES[tierWith(rec.id, player.id)]} · ${doingText(s.state, s.phase, { ...s, you: s.leaderId === player.id })}`);
  }
  form.button("Close");
  const res = await show(player, form);
  if (res && res.selection !== undefined && res.selection < list.length) await residentPage(player, list[res.selection].id);
}

// The most urgent warnings across all exhibits, worst first, one per exhibit issue.
function topWarnings(count) {
  const out = [];
  for (const ex of allExhibits()) {
    for (const text of ex.issues) out.push({ severity: 3, where: ex.name, text });
    for (const w of ex.careWarnings) out.push({ severity: w.severity, where: ex.name, text: w.text });
  }
  return out.sort((a, b) => b.severity - a.severity).slice(0, count);
}

function whereIs(a) {
  if (a.location.kind === "exhibit") return getExhibit(a.location.id)?.name ?? "an exhibit";
  if (a.location.kind === "carrier") return "in a carrier";
  return "recovery holding";
}

async function animalsList(player, park) {
  const list = withPark(park, allAnimals);
  if (!list.length) return message(player, "§eNo animals yet. Catch one with a Small Carrier.");
  const form = new ActionFormData().title("Animals");
  for (const a of list) {
    const b = band(welfare(a), BALANCE.needs.bands);
    form.button(`${a.name} §8(${SPECIES[a.speciesId].displayName})\n${BAND_COLOR[b]}${BAND_TEXT[b]} §8· ${whereIs(a)}`);
  }
  const r = await show(player, form);
  if (r && r.selection !== undefined) openAnimal(player, list[r.selection].id);
}

const BAND_COLOR = { healthy: "§2", attention: "§6", urgent: "§6", critical: "§4" };
const BAND_TEXT = { healthy: "Healthy", attention: "Needs attention", urgent: "Urgent", critical: "Critical" };

async function finances(player, park) {
  const body = withPark(park, () => financesBody(park));
  await show(player, new ActionFormData().title("Finances").body(body).button("Close"));
}

function financesBody(park) {
  const r = ratingNow();
  const lines = recent(10).map((e) => `${e.amount >= 0 ? "§a+" : "§c"}${e.amount} §7${e.reason}`);
  return [
    `§fZoo Coins: ${balanceText(park)}`,
    `§fAdmission: §7${r.price} coins per guest ${pairedBooth() ? "(set at the Ticket Booth)" : "(place a Ticket Booth near the entrance gate to set it)"}`,
    `§fToday: §7${park.today.guests} guests, ${park.today.revenue} coins`,
    `§fYesterday: §7${park.lastDay.guests} guests, ${park.lastDay.revenue} coins`,
    `§fRating: §7${r.stars} stars (score ${r.score}). More stars bring more guests, and so do more kinds of animals on show: ${r.shownSpecies} now §8(each kind past the first ${BALANCE.economy.drawFromSpecies} brings more, up to ${BALANCE.economy.drawSpeciesCap} kinds)`,
    `§fGuest satisfaction: §7${r.satisfaction} §8(viewing ${r.factors.viewing}, cleanliness ${r.factors.cleanliness}, value ${r.factors.value}, services ${r.factors.services})`,
    `§fServices: §7food ${r.services.parts.food}, seating ${r.services.parts.seating}, tidy paths ${r.services.parts.litter}, restrooms ${r.services.parts.restrooms}, drinking water ${r.services.parts.drinks} §8(litter ${Math.round(park.litter ?? 0)})`,
    ...facilityLines(r.services.facilities),
    ...amenityLines(r.services.amenities, BALANCE),
    pathLine(),
    ...(r.unviewed.length ? [`§fNo working Viewing Point: §7${r.unviewed.join(", ")}`] : []),
    "",
    "§fRecent coins:",
    lines.join("\n") || "§7No transactions yet.",
  ].join("\n");
}

function pathLine() {
  const net = pathSummary();
  const features = allServices();
  const off = [...allPoints("viewpoint").filter((v) => v.problem === "path").map(() => "Viewing Point"), ...features.filter((f) => f.problem === "path").map((f) => SERVICE_NAMES[f.type])];
  if (!getPark()?.entrance) return "§fGuest paths: §7place a Park Entrance Gate first";
  if (!net) return "§fGuest paths: §7not checked yet (stand near the entrance gate)";
  const reach = `${net.size} path blocks reach from the entrance${net.remembered ? ` (${net.remembered} remembered from earlier visits)` : ""}${net.capped ? `; §estopped at ${BALANCE.paths.maxNodes} blocks, the nearest part§7` : ""}`;
  const edge = net.unloadedAt ? `; §eunchecked ground at ${net.unloadedAt.x}, ${net.unloadedAt.z}: walk there and the paths beyond it get checked` : "";
  return `§fGuest paths: §7${reach}${edge}${off.length ? `; §enot on a path: ${off.join(", ")}` : ""}`;
}

async function journal(player, park, title = "Journal") {
  const { form, kit } = withPark(park, () => journalForm(title));
  const r = await show(player, form);
  if (kit && r?.selection === 0) withPark(park, () => claimKit(player));
}

function journalForm(title) {
  const tut = tutorialStatus();
  const exp = expeditionStatus();
  const chain = (q, color) => q.steps.map((s) => (q.completed[s.id] !== undefined ? `§2Done: §7${s.title}` : s === q.next ? `${color}Now: §f${s.title}\n§7${s.hint}` : `§8Later: ${s.title}`));
  const parts = [`§6Caretaker tutorial ${tut.done}/${tut.total}\n\n${chain(tut, "§b").join("\n")}`];
  // The End expedition (spec section 4 stages) follows the tutorial: the campaign to the End wing.
  if (exp.open) parts.push(exp.finished ? `§dEnd expedition ${exp.done}/${exp.total}: §6complete` : `§dEnd expedition ${exp.done}/${exp.total}\n\n${chain(exp, "§d").join("\n")}`);
  // The conservation programme (spec phase 5): releases to the wild, beside the expedition.
  const con = conservationStatus();
  const rel = releaseStatus();
  if (con.open) parts.push((con.finished ? `§2Conservation programme ${con.done}/${con.total}: §6complete` : `§2Conservation programme ${con.done}/${con.total}\n\n${chain(con, "§2").join("\n")}`) + `\n§7Released to the wild: ${rel.count}${rel.count ? ` (${Object.entries(rel.species).map(([id, n]) => `${n} ${SPECIES[id]?.displayName ?? id}`).join(", ")}); ${Math.round(rel.boost * 100)}% more guests a day` : ""}`);
  const form = new ActionFormData().title(title).body(parts.join("\n\n"));
  const kit = Boolean(tut.next);
  if (kit) form.button(`Replacement starter kit\n§8${BALANCE.tutorial.maxKitClaims - tut.kitClaims} left, one per park day`);
  form.button("Close");
  return { form, kit };
}

const capital = (t) => (t ? t[0].toUpperCase() + t.slice(1) : t);

async function claimFlow(player) {
  // 0.1.114 (several parks a world): one park an owner, outside every other park's fence (park/park.js claimProblem).
  const problem = claimProblem(player);
  if (problem) return message(player, `§e${problem}`);
  // 0.1.101 (Austin: the fence is "Required"): a park is the ground its Aluminum Fence closes round.
  const area = "Your park will be the ground you fence in round where you stand, with Aluminum Fence from the Zoo Workshop";
  const next = "build a Zoo Workshop, then run an Aluminum Fence all the way round this spot";
  // 0.1.176 (module 13): or start from an old park, built round the player (starter/site.js), once a player a world.
  const old = player.dimension.id === "minecraft:overworld" && mayStartOldPark(player);
  const side = SITE.half * 2 + 1;
  const form = new ActionFormData()
    .title("Claim a park")
    .body(`Found a wildlife park here? ${area}, and you start with ${BALANCE.economy.startingFunds} Zoo Coins.\n\nNext: ${next}. The Journal in this menu walks you through your first exhibit.${old ? `\n\n§6Or start from an old park: §fan abandoned wildlife park is built round you: an old Aluminum Fence ${side} blocks a side with its gate, a caretaker cabin, a workshop shell, stores and an unfinished pen, fitted to the ground here. Its tutorial is mending it. Once a player in a world.` : ""}`);
  form.button("Claim here");
  if (old) form.button("Start from an old park\n§8builds an abandoned park round you");
  form.button("Not yet");
  const r = await show(player, form);
  if (old && r?.selection === 1) return startFromOldPark(player);
  if (r?.selection !== 0) return;
  const res = claimPark(player);
  if (!res.ok) return message(player, `§c${res.reason}`);
  message(player, `§aYou claimed ${parkName(res.park)}! §e${BALANCE.economy.startingFunds} Zoo Coins §ato start.${allParks().length > 1 ? " §7Rename it in the Park Ledger's settings." : ""}`);
}

// 0.1.176: the old park option of the claim page: what it does, then the build (starter/site.js startOldPark).
async function startFromOldPark(player) {
  const side = SITE.half * 2 + 1;
  const r = await show(
    player,
    new MessageFormData()
      .title("Start from an old park")
      .body(`This builds an abandoned wildlife park round where you stand, about ${side} x ${side} blocks, and makes it yours. Its yard and its pen are levelled at the ground's middle height, so trees and blocks where they go are cleared; everything else keeps its own ground and trees. It needs fairly level, dry ground in the Overworld.\n\nYou can do this once in this world.`)
      .button1("Build it")
      .button2("Not now"),
  );
  if (r?.selection !== 0) return;
  const why = startOldPark(player.dimension, player.location.x, player.location.z, player, (text) => message(player, text));
  if (why) message(player, `§c${why}`);
}

/**
 * The Noticeboard (0.1.176): the caretaker's board. On an old park nobody has claimed it offers the park; otherwise
 * it's the board of the park it stands in (or the player's): the tutorial and the quests, as the Park Ledger's Journal.
 */
export async function noticeboardMenu(player, block) {
  const d = block.dimension.id;
  const site = siteAt(d, block.location);
  if (site && !parkOfSite(site)) return offerOldPark(player, site);
  const park = (site && parkOfSite(site)) ?? parkAt(d, block.location) ?? parkOf(player);
  if (!park) return message(player, "§eThis Noticeboard belongs to no park yet. §fClaim a park with a Park Deed and it shows your park's tutorial and quests.");
  return journal(player, park, `Noticeboard: ${parkName(park)}`);
}

async function offerOldPark(player, site) {
  const r = await show(
    player,
    new MessageFormData()
      .title("An old wildlife park")
      .body(`This park has stood empty for years. Its Aluminum Fence is broken in ${site.gaps} places, its gate is overgrown, and its Rabbit Meadow was never finished.\n\nClaim it and bring it back to life? You start with ${BALANCE.economy.startingFunds} Zoo Coins, and the stores behind the cabin hold supplies to get started.`)
      .button1("Claim this old park")
      .button2("Not now"),
  );
  if (r?.selection !== 0) return;
  const res = claimSite(player, site);
  if (!res.ok) message(player, `§e${res.reason}`);
}

async function exhibitsList(player, park) {
  const list = withPark(park, allExhibits);
  if (!list.length) return message(player, "§eNo exhibits yet. Place an Exhibit Controller to start one.");
  const form = new ActionFormData().title("Exhibits");
  for (const ex of list) form.button(`${ex.name}\n§8${ex.animalIds.length} animals · ${ex.state}`);
  const r = await show(player, form);
  if (r && r.selection !== undefined) openExhibit(player, list[r.selection].id);
}

async function shop(player, park) {
  const entries = Object.entries(BALANCE.shop);
  const form = new ActionFormData().title("Supply shop").body(`§fZoo Coins: ${balanceText(park)}`);
  for (const [item, { price, bundle }] of entries) form.button(`${bundle} ${itemLabel(item)}\n§8${price * bundle} coins`);
  form.button(`Sell rations\n§8get coins back for rations you carry (${sellBackLeft(soldBackToday(park), BALANCE)} more today)`);
  form.button("Back");
  const r = await show(player, form);
  if (!r || r.selection === undefined || r.selection > entries.length) return;
  if (!can(player, "spend", park)) return message(player, denyText("spend", park));
  if (r.selection === entries.length) return sell(player, park);
  const [item, { price, bundle }] = entries[r.selection];
  const cost = price * bundle;
  const res = withPark(park, () => spend(player, cost, `Bought ${bundle} ${itemLabel(item)}`, newId("buy")));
  if (!res.ok) return message(player, `§cNot enough Zoo Coins (${cost} needed).`);
  db.flush();
  giveItem(player, item, bundle);
  message(player, `§aBought ${bundle} ${itemLabel(item)} for ${cost} coins.`);
}

// Rations the shop bought back from this park today, read fresh (0.1.178).
const soldBackToday = (park) => withPark(park, () => getPark()?.today?.soldBack ?? 0);

async function sell(player, park) {
  const entries = Object.entries(BALANCE.shop).filter(([item, e]) => e.sell > 0 && countItem(player, item) > 0);
  if (!entries.length) return message(player, "§eYou aren't carrying any rations to sell.");
  const per = BALANCE.economy.sellBackPerDay;
  const left = sellBackLeft(soldBackToday(park), BALANCE);
  if (left <= 0) return message(player, `§eThe shop has bought back all the rations it takes today (${per} a park day). §fIt buys more tomorrow.`);
  const form = new ActionFormData().title("Sell rations").body(`The shop buys rations back for less than it sells them, up to ${per} a park day: ${left} more today.`);
  for (const [item, { sell: each }] of entries) form.button(`${itemLabel(item)}\n§8you have ${countItem(player, item)} · ${each} coin${each === 1 ? "" : "s"} each`);
  const r = await show(player, form);
  if (!r || r.selection === undefined || !entries[r.selection]) return;
  const [item, { sell: each }] = entries[r.selection];
  const label = itemLabel(item);
  const have = countItem(player, item);
  const most = Math.min(have, left);
  let count = most;
  if (most > 1) {
    const m = await show(player, new ModalFormData().title(`Sell ${label}`).slider("How many?", 1, most, { valueStep: 1, defaultValue: most }));
    if (!m) return;
    count = Math.min(Number(m.formValues[0]), countItem(player, item));
  }
  // The day's allowance again, after the form: another member may have sold meanwhile.
  count = Math.min(count, sellBackLeft(soldBackToday(park), BALANCE));
  if (count < 1) return message(player, `§eThe shop has bought back all the rations it takes today (${per} a park day). §fIt buys more tomorrow.`);
  // Take the items first, so a failed or repeated sale can never pay out twice.
  if (!takeItem(player, item, count)) return message(player, `§cYou no longer have ${count} ${label}.`);
  withPark(park, () => {
    recordSoldBack(count);
    earn(count * each, `Sold ${count} ${label}`, newId("sell"));
  });
  db.flush();
  message(player, `§aSold ${count} ${label} for ${count * each} coins.`);
}

export async function holding(player, park = getPark()) {
  const list = withPark(park, inHolding);
  if (!list.length) return message(player, "§aNo animals in recovery holding.");
  const station = withPark(park, () => allFixtures("station").length > 0);
  const vetHere = station && vetBoost(park.id, system.currentTick) > 1; // 0.1.249
  const care = vetHere ? "§aDr. Pollo is at the Recovery Station, nursing them back to health faster." : station ? "§aThe Recovery Station is nursing them back to health." : "§eBuild a Recovery Station (Zoo Workshop) so unwell animals get better here.";
  const form = new ActionFormData().title("Recovery holding").body(`Animals here are safe but not on show. ${care}\n\n§fPick one to put it in an empty carrier from your inventory, then use the carrier inside an exhibit.`);
  for (const a of list) {
    const b = band(welfare(a), BALANCE.needs.bands);
    form.button(`${a.name} (${SPECIES[a.speciesId].displayName})\n${a.ill ? "§4Unwell" : `${BAND_COLOR[b]}${BAND_TEXT[b]}`} §8· ${a.location.why ?? ""}`);
  }
  const r = await show(player, form);
  if (r && r.selection !== undefined && list[r.selection]) withPark(park, () => packFromHolding(player, list[r.selection].id));
}

// Members (spec section 2 roles): everyone who has ever joined the world is listed, online or not,
// with their role; the owner picks one to change it or to hand the park over.
async function members(player, park) {
  if (!can(player, "members", park)) return message(player, denyText("members", park));
  const rows = memberRows(park, knownPlayers(), onlinePlayers().map((p) => p.id));
  const help = ["owner", "manager", "keeper", "visitor"].map((r) => `§f${ROLE_LABEL[r]}: §7${ROLE_TEXT[r]}`).join("\n");
  if (!rows.length) return show(player, new ActionFormData().title("Members").body(`§eNo other player has joined this world yet. When someone does, they appear here and you can give them a role.\n\n${help}`).button("Close"));
  const form = new ActionFormData().title("Members").body(`§fOwner: §7${park.members[park.ownerId]?.name ?? "?"}\n\n${help}\n\n§fPick a player to change their role:`);
  for (const m of rows) form.button(`${m.name}\n§8${ROLE_LABEL[m.role]} · ${m.online ? "§aonline" : "§7offline"}`);
  form.button("Close");
  const r = await show(player, form);
  if (!r || r.selection === undefined || !rows[r.selection]) return;
  await memberPage(player, rows[r.selection], park);
  return members(player, park);
}

async function memberPage(player, m, park) {
  const form = new ActionFormData().title(m.name).body(`§fRole now: §7${ROLE_LABEL[m.role]}\n§8${ROLE_TEXT[m.role]}\n\n§fGive them a role:`);
  for (const role of GIVABLE_ROLES) form.button(`${ROLE_LABEL[role]}${role === m.role ? " §8(now)" : ""}\n§8${ROLE_TEXT[role].split(":")[0]}`);
  form.button("Hand the park over to them\n§8you stay on as a manager");
  form.button("Back");
  const r = await show(player, form);
  if (!r || r.selection === undefined) return;
  if (r.selection < GIVABLE_ROLES.length) {
    const role = GIVABLE_ROLES[r.selection];
    setMember(m.id, m.name, role, park);
    message(player, `§a${m.name} is now a ${role}${allParks().length > 1 ? ` of ${parkName(park)}` : ""}.`);
    const target = onlinePlayers().find((p) => p.id === m.id);
    if (target) message(target, `§6${player.name} made you a ${role}${allParks().length > 1 ? ` of ${parkName(park)}` : ""}: §f${ROLE_TEXT[role]}.`);
    return;
  }
  if (r.selection === GIVABLE_ROLES.length) return handOverFlow(player, m, park);
}

async function handOverFlow(player, m, park) {
  const check = canHandOver(park, m.id);
  if (!check.ok) return message(player, `§e${check.reason}`);
  const r = await show(player, new MessageFormData().title("Hand the park over").body(`Make ${m.name} the park owner? They will control members and settings; you stay on as a manager (building and spending). Only they can hand it back.`).button1("Hand it over").button2("Cancel"));
  if (r?.selection !== 0) return;
  const res = transferPark(m.id, m.name, park);
  if (!res.ok) return message(player, `§e${res.reason}`);
  message(player, `§a${m.name} now owns the park. You're a manager.`);
  const target = onlinePlayers().find((p) => p.id === m.id);
  if (target) message(target, `§6${player.name} handed the park to you: §fyou're the owner now.`);
}

// Park settings (spec sections 2 and 19): sandbox mode and peaceful care, with what each does spelled
// out (park/rules.js). Switching sandbox mode tells every member online.
async function settings(player, park) {
  if (!can(player, "settings", park)) return message(player, denyText("settings", park));
  const r = await show(
    player,
    new ModalFormData()
      .title("Park settings")
      .label(settingsText(park))
      .textField("Park name (0.1.114: how guests, members and the sidebar know this park)", parkName(park), { defaultValue: parkName(park) })
      .toggle("Sandbox mode (unlimited coins, free research and wages)", { defaultValue: Boolean(park.settings.sandbox) })
      .toggle("Peaceful care (needs don't drop)", { defaultValue: Boolean(park.settings.peacefulCare) })
      .toggle("ZooCraft Park sidebar on screen (for everyone in the park)", { defaultValue: park.settings.sidebar !== false }),
  );
  if (!r) return;
  // The label takes a slot in formValues in some server-ui versions: read the fields from the end.
  const name = String(r.formValues[r.formValues.length - 4] ?? "");
  const sandbox = Boolean(r.formValues[r.formValues.length - 3]);
  const peaceful = Boolean(r.formValues[r.formValues.length - 2]);
  const sidebar = Boolean(r.formValues[r.formValues.length - 1]);
  const sandboxChanged = sandbox !== Boolean(park.settings.sandbox);
  setSetting("sandbox", sandbox, park);
  setSetting("peacefulCare", peaceful, park);
  setSetting("sidebar", sidebar, park);
  const renamed = name.trim() && name.trim() !== parkName(park) ? renamePark(name, park) : undefined;
  message(player, `§aSandbox mode ${sandbox ? "on" : "off"}, peaceful care ${peaceful ? "on" : "off"}, sidebar ${sidebar ? "on" : "off"}.${renamed ? ` §e${renamed}` : name.trim() && name.trim() === parkName(park) ? ` §7The park is ${parkName(park)}.` : ""}`);
  if (sandboxChanged) {
    const fresh = parkById(park.id) ?? park;
    for (const p of onlinePlayers()) if (p.id !== player.id && fresh.members[p.id]) message(p, sandbox ? `§dSandbox mode is on${allParks().length > 1 ? ` in ${parkName(fresh)}` : ""}: §fnothing costs Zoo Coins, research is free, keepers work for free.` : `§7Sandbox mode is off${allParks().length > 1 ? ` in ${parkName(fresh)}` : ""}: §fcoins, parts and wages count again.`);
  }
}

// The entrance gate's menu: the park whose fence holds the gate (0.1.114), else the player's.
export async function gateMenu(player, block) {
  const park = parkAt(block.dimension.id, block.location) ?? parkOf(player);
  if (!park) return message(player, "§eClaim a park with a Park Deed first.");
  if (!insideParkColumn(park, block.x, block.z)) return message(player, `§eThe entrance gate must be ${insideWords(park)} (in the fence is inside).`);
  if (!can(player, "build", park)) return message(player, denyText("build", park));
  const opening = !park.open;
  const price = withPark(park, () => `Each guest pays ${admission()} Zoo Coins${pairedBooth() ? "" : " (a Ticket Booth near this gate lets you set the price)"}.`);
  const r = await show(player, new MessageFormData().title("Park entrance").body(opening ? `Open the park to guests? ${price} More guests come when your animals are happy and easy to see.` : "Close the park? Guests stop arriving until you reopen.").button1(opening ? "Open" : "Close").button2("Cancel"));
  if (r?.selection !== 0) return;
  setEntrance(block.dimension.id, { x: block.x, y: block.y, z: block.z }, park);
  setOpen(opening, park);
  message(player, opening ? `§a${allParks().length > 1 ? parkName(park) : "The park"} is open!` : `§7${allParks().length > 1 ? parkName(park) : "The park"} is closed.`);
}

// Snack Stand (spec section 12): stock from the inventory or the supply line, and set the price.
export async function standMenu(player, stand) {
  const s = BALANCE.snacks;
  const rec = db.get("equipment", stand.id) ?? stand;
  const park = parkAt(rec.dimension, rec.pos) ?? parkOf(player);
  const status = withPark(park, () => serviceText(rec));
  const sold = rec.soldDay === park?.today.day ? rec.soldToday ?? 0 : 0;
  const buyers = Math.round(snackShare(rec.price, BALANCE) * 100);
  const body = [
    status,
    "",
    `§fStock: §7${rec.stock} of ${s.capacity} snacks`,
    `§fPrice: §7${rec.price} coins §8(guests think ${s.fair} is fair; about ${buyers}% of guests buy one)`,
    `§fSold today: §7${sold}`,
    "",
    "§7Stock it with bread, cookies, apples, melon slices, baked potatoes, pumpkin pie, cake or sweet berries, or buy snacks in from the supply line.",
  ].join("\n");
  const form = new ActionFormData().title("Snack Stand").body(body);
  const actions = [];
  const add = (label, fn) => {
    form.button(label);
    actions.push(fn);
  };
  if (can(player, "care", park)) add("Stock from my inventory", () => withPark(park, () => stockFromInventory(player, rec)));
  if (can(player, "spend", park)) {
    add(`Buy ${s.wholesaleBundle} snacks\n§8${s.wholesaleBundle * s.wholesaleCost} coins`, () => withPark(park, () => buyStock(player, rec)));
    add("Set the price", () => snackPrice(player, rec));
  }
  add("Close", () => {});
  const r = await show(player, form);
  if (r && r.selection !== undefined) await actions[r.selection]?.();
}

async function snackPrice(player, rec) {
  const s = BALANCE.snacks;
  const res = await show(player, new ModalFormData().title("Snack price").slider("Price per snack (Zoo Coins)", s.min, s.max, { valueStep: 1, defaultValue: rec.price }).label(`Guests think §e${s.fair} coins§r is fair. Dearer snacks sell to fewer guests.`));
  const value = res?.formValues?.find((v) => typeof v === "number");
  if (typeof value !== "number") return;
  const cur = db.get("equipment", rec.id);
  if (!cur) return message(player, "§cThat Snack Stand is gone.");
  setSnackPrice(cur, Math.round(value));
  message(player, `§aSnacks now cost ${cur.price} coins. §7About ${Math.round(snackShare(cur.price, BALANCE) * 100)}% of guests will buy one.`);
}

// Ticket Booth (spec section 13): sets the admission price while it stands near the entrance gate (0.1.114: of the
// park the booth stands in).
export async function boothMenu(player, booth) {
  const park = parkAt(booth.dimension, booth.pos) ?? parkOf(player);
  if (!park) return message(player, "§eClaim a park with a Park Deed first.");
  const range = BALANCE.ticketBooth.pairRange;
  if (!park.entrance && !adoptGateNear(booth.dimension, booth.pos, range)) return message(player, `§eTicket Booth: place a Park Entrance Gate within ${range} blocks. Then this booth sets the admission price.`);
  const paired = withPark(park, pairedBooth);
  if (!paired) return message(player, `§eTicket Booth: too far from the Park Entrance Gate. Put it within ${range} blocks of the gate.`);
  if (paired.id !== booth.id) return message(player, "§eAnother Ticket Booth already sets the price at this entrance.");
  const r = withPark(park, ratingNow);
  if (!can(player, "spend", park)) return message(player, `§6Ticket Booth: §fadmission is ${r.price} Zoo Coins.`);
  const a = BALANCE.admission;
  const res = await show(
    player,
    new ModalFormData()
      .title("Ticket Booth")
      .slider("Admission price (Zoo Coins)", a.min, a.max, { valueStep: 1, defaultValue: r.price })
      .label(`Guests think about §e${r.fair} coins§r is fair for a ${r.stars}-star park. Charge more and fewer come and they rate the park's value lower. Charge less and a few more come.`),
  );
  const value = res?.formValues?.find((v) => typeof v === "number");
  if (typeof value !== "number") return;
  const price = Math.round(value);
  if (price === r.price) return;
  setAdmission(price, park);
  const more = Math.round((priceDemand(price, r.fair, BALANCE) - 1) * 100);
  const effect = more > 0 ? `about ${more}% more guests` : more < 0 ? `about ${-more}% fewer guests` : "the usual number of guests";
  message(player, `§aAdmission is now ${price} coins. §7Expect ${effect}; value rating ${valueScore(price, r.fair, BALANCE)}/100.`);
}

// A resident's friendship rewards (0.1.243; Austin's NPC Expansion spec: Sophia's book at 80 friendship; 0.1.245:
// Terra's plans at 40 and 60). A resident's `reward` (data/residents.js) is { at (friendship points), book (a
// data/lore.js book's id) or item (an item id), name, line (their words handing it over; "reward" if not given) }; one
// with several has `rewards`, a list of them in the order they come. Once handed over a reward is the player's for
// good: the friendship record keeps `rewards[<book or item id>]` (the day), whatever friendship does later.
// 0.1.281: rewards ready at the same friendship are handed over together (Jack's Steel Rod and his Flint and Steel at
// 100; `give` is how the hand-over names one, `lineWith` their words when others come with it). `again: false` is one
// they don't give a second of (Jack sells spares of his rod instead; `spares` says where).
// No engine calls here.

// 0.1.250: a reward can need more than friendship (Dr. Pollo's formula: `vetLevel`, his veterinary level, 0-based).
// Whoever knows the answer says so here (residents.js); with nobody asked, a reward needs its friendship only.
/** @type {(res: any, r: any) => boolean} */
let gate = () => true;
export function setRewardGate(fn) {
  gate = fn ?? (() => true);
}

/** What a reward is filed under in the friendship record. */
// 0.1.254: or an ability (Jaylen's Hairline Painting: `ability`), which is nothing to carry.
export const rewardKey = (r) => r.book ?? r.item ?? r.ability;

/** A resident's rewards, in the order they come. */
export function rewardsOf(res) {
  return res?.rewards ?? (res?.reward ? [res.reward] : []);
}

/** The reward a resident has ready for this friendship record and hasn't handed over yet (the first of them), or undefined. */
export function rewardDue(res, bond) {
  return rewardsOf(res).find((r) => (bond?.points ?? 0) >= r.at && gate(res, r) && bond?.rewards?.[rewardKey(r)] === undefined);
}

/**
 * 0.1.281: the rewards a resident hands over now: the first one ready, and every other one ready at the same friendship
 * (Jack's two at 100). Rewards at different friendships still come a talk apart, in their order (Terra's plans).
 */
export function rewardsDueNow(res, bond) {
  const first = rewardDue(res, bond);
  if (!first) return [];
  if (first.ability) return [first];
  return rewardsOf(res).filter((r) => r === first || (!r.ability && r.at === first.at && (bond?.points ?? 0) >= r.at && gate(res, r) && bond?.rewards?.[rewardKey(r)] === undefined));
}

/** Whether a player may ask a resident for another of a reward they earned (0.1.281: not one marked `again: false`). */
export const askAgain = (r) => Boolean(r) && !r.ability && r.again !== false;

/** The rewards this player already earned from a resident (to ask for another of). */
export function rewardsEarned(res, bond) {
  return rewardsOf(res).filter((r) => bond?.rewards?.[rewardKey(r)] !== undefined);
}

/** The first reward this player already earned from a resident, or undefined. */
export function rewardEarned(res, bond) {
  return rewardsEarned(res, bond)[0];
}

/** The friendship record with the reward marked as handed over on `day`. */
export function withReward(bond, reward, day) {
  return { ...bond, rewards: { ...(bond.rewards ?? {}), [rewardKey(reward)]: day } };
}

/** What a resident's page says about their rewards: locked with the friendship it takes, ready, or earned. */
export function rewardText(res, bond) {
  const all = rewardsOf(res);
  if (!all.length) return undefined;
  const earned = rewardsEarned(res, bond);
  const lines = earned.map((r) => (r.ability ? `Their gift to you: ${r.name} (yours for good; it's on their menu).` : !askAgain(r) ? `Their gift to you: ${r.name} (yours${r.spares ? `; ${r.spares}` : ""}).` : `Their gift to you: ${r.name} (yours; ask them for another ${r.book ? "copy if you lose it" : "if you carry none"}).`));
  if (rewardDue(res, bond)) lines.push(`They have something for you: talk to them.`);
  else {
    const next = all.find((r) => !earned.includes(r));
    if (next) lines.push(next.vetLevel !== undefined ? `At veterinary level ${next.vetLevel + 1} and ${next.at} friendship they have something special for you.` : `At ${next.at} friendship they have something special for you.`);
  }
  return lines.join("\n");
}

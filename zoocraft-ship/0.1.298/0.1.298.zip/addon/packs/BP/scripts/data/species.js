// Species catalogue (spec section 5.5). Adding an animal = an entry here + its entity and art.
// The zoo rabbit is a zoo copy of the vanilla rabbit that keeps its coat; the otter is the first
// custom animal (original model), caught from wild otters near rivers and swamps; the capybara
// (M3) is a calm grazer that rests in groups and swims in shallow water, found in swamps and jungles;
// the deer (M3) is a wary herd grazer of forests and meadows that wants quiet cover in its exhibit;
// the penguin (M3) lives in colonies in frozen places and needs a cold exhibit (a Cooling Unit);
// the giraffe (M3) is a tall savanna browser that eats only from an Elevated Browse Feeder;
// the elephant (M3) is a big savanna herd animal that needs a mud wallow and loves an Enrichment Ball.
// Every species can breed (spec section 9, M3 breeding controls): see animals/breeding.js.
// The Basalt Tortoise (M4, spec 5.3) is the first Nether animal: it needs heat (a fuelled Thermal
// Regulator), basking pads (magma blocks in the floor) and Mineral Pellets, and travels in a Thermal Carrier.
// The Ember Fox (M4, spec 5.3) needs heat too, a Warm Ash bed to dig in, an Ember Den to curl up in,
// lava to drink and Ember Rations.
// The Lava Ray (M4, spec 5.3) swims in lava: a lava pool exhibit, Molten Plankton Feed from a Thermal
// Feeder at the pool edge. Nether animals have their own toys (species.toys, Austin 0.1.46): a Blaze
// Bone for Ember Foxes and a Wither Skull Ball for Basalt Tortoises.
// The Strider (M4, spec 5.1: "Lava pool, warm resting zones, thermal transport") is a zoo copy of the
// vanilla strider, caught from wild striders: it walks across a lava pool (species.lavaWalker), rests
// on magma blocks on the bank and shivers anywhere else, and eats warped fungus from a Basic Feeder.
// The Chorus Deer (M5, spec 5.4: "Slender lavender grazer, branching antlers | Browses chorus growth in
// groups | Chorus browse, quiet retreat, herd room") is the first End animal: a herd browser of the
// End islands that wants end stone underfoot (species.endGround), quiet cover and Chorus Browse, and
// travels in a Stabilized Carrier (Dimensional Preparation research).
// The Void Ray (M5, spec 5.4: "Wide dark ray with a luminous underside | Glides through the air in slow
// arcs, rests on perches | Flight room, perches, chorus browse") is the first flyer (species.flies):
// a roofed exhibit with 14 blocks of air (large_aerial, measured by a flood through the air) and Void
// Perches floating in it to rest on; steered by animals/flight.js. End ground underfoot like the deer.
// The Raccoon (0.1.71, the Animal wave; spec 5.x "Manipulates puzzle feeders | Climbing; attracted to
// unsecured bins") is the first climber (species.climbs): its exhibit is measured for climbing too
// (exhibits/geometry.js floodClimb) and one it could climb out of is unsafe. It wants a climbing tree
// or a Climbing Frame and water to wash its food in, works Puzzle Feeders, and raids Litter Bins
// without a Bin Latch when it's loose at night (animals/raccoon.js).
// The Flamingo (0.1.72, the Animal wave; spec 5.2 "Flock wading | Shallow water and mud nesting") wades
// (species.wades: its exhibit needs shallows, water 1 block deep), lives in flocks, gets its pink from
// its food (species.pink: Flamingo Pellets) and nests (species.nest): only in a flock big enough (Flock
// Mirrors help), every grown-up rosy, on mud at the water's edge (animals/flamingo.js).
// The Zebra (0.1.74, the Animal wave; spec 5.2 "Coordinated herd movement | Savanna mixing and broad
// grazing") grazes (species.graze: grass blocks in the exhibit floor give it part of its food), lives in
// harems (species.harem: one stallion with the mares; rival stallions fight), eats from a Hay Rack
// (species.rack; deer and elephants do too) and feeds in rank order (species.feedRank: with too few
// feeding places the low-ranking ones get pushed off). Herds walk off in single file and run from a
// fright (animals/zebra.js).
// The Lion (0.1.75, Big predators; spec 5.2 "Pride rest and scent investigation | Group dens, secure
// service access") is dangerous (species.dangerous: a Holding Den for each grown one, keepers go in only
// through a double Keeper Gate with every one shut in, and a player inside its exhibit is warned off,
// then charged and swiped; wild ones hunt people), fasts one park day in seven (species.fasts), rests up
// high (species.ledge), and the males wear a light or dark mane (species.manes). A pride rests in a pile,
// patrols and marks its fence, investigates a Scent Post, roars at dusk and dawn (animals/lion.js).
// The Tiger (0.1.76, spec 5.2 "Solitary patrolling and swimming | Privacy and separate adult territories")
// is dangerous too, and solitary (species.solitary): one grown tiger loose at a time, the others in their
// Holding Dens taking turns out (animals/tigerTurns.js), a tigress's cubs in and out with her
// (dens.cubsFollow); it wants screened floor to get out of sight (species.privacy), swims and lies in the
// shallows (its "tiger" profile), and each has its own stripe pattern (species.patterns, the mob's
// skin_id) and its sex on the mob (species.sexLook: a male is bigger, with a full ruff). animals/tiger.js.
// The Crocodile (0.1.77, spec 5.2 "Basking and submerged resting | Secure keeper access, shore clearance") is
// dangerous too: it basks on a sunny bank (species.basks) and rests under the water (species.submerges: deep
// water for all at once), its keepers need the shore kept clear (species.shoreClear), it eats about once a week
// (species.meals), the biggest first (species.rank), each has its own size (species.sizes: the mob's
// zoocraft:size), its sex (species.sexLook: a male is bigger, his head broader) and its tail crest (species.patterns),
// and it nests in sand (species.sandNest), the nest's warmth setting the hatchlings' sex. animals/croc.js.
// The Red Panda (0.1.79, spec 5.2 "Elevated travel and resting | Continuous climbing routes, nest boxes") climbs
// like the raccoon (species.climbs, climbTree), lives up on the canopy reached from a trunk (species.canopy),
// sleeps in a Nest Box (species.nestBox) and needs shade in a hot biome (species.heatShade). animals/redpanda.js.
// The Gorilla (0.1.80, spec 5.2 "Social interaction and puzzle solving | Strong fixtures and climbing structures")
// lives in a troop (species.troop: one silverback), is dangerous (dens, the double Keeper Gate), needs strong
// walls (species.ape: the ape measure), drowns in deep water (species.noSwim) and wants something to climb
// (climbTree). animals/gorilla.js.
// The Owl (0.1.81, the Eurasian eagle-owl; spec 5.2 "Nocturnal flight and perch watching | Enclosed airspace, nesting
// boxes") flies (an "aviary": the flight measure) and roosts on Perches at varied heights (species.roosts), a
// night bird out at dusk and dawn, and lays its eggs in a Nest Box (breeding.nestBox). animals/owl.js.
// The Crimson Grazer (0.1.84, the Nether trio; spec 5.3 "Stocky six-legged fungal herbivore | Herd browsing and
// fungus rubbing | Crimson ground, fungal feed, herd shelter") is a fantasy herd animal built on the musk ox: crimson
// nylium underfoot (species.nylium), a crimson stem to rub on (species.rubStem), shelter over part of the floor
// (cover), heat, and the herd's ring against a threat. animals/grazer.js.
// The Warped Gecko (0.1.85, the Nether trio; spec 5.3 "Blue-green luminous climber | Wall clinging and vertical
// hunting | Registered climbing surfaces and insect feed") is a fantasy gecko built on the New Caledonian giant
// gecko: it climbs walls and glass (species.clings: the exhibit is measured for its walls and needs a roof), hides
// in a crack or a Burrow Shelter by day and is up at night (nightLife), hunts the moths an Insect Feeder lets out
// (insectFeeder), and keeps one grown male to an exhibit (oneMale). animals/gecko.js.
// The Cinder Boar (0.1.87, the Nether trio; spec 5.3 "Ash-colored rooting animal | Digs and uses cooling mud pockets |
// Ash, thermal mud, strong barrier") is a fantasy boar built on the wild boar: it roots in Warm Ash (ash), wallows in
// Thermal Mud in the heat (species.wallow), breaks through wooden fences, gates and doors (species.boarProof: the boar
// measure), lives in sounders of sows and piglets with one grown boar (oneMale), and a sow defends her piglets.
// animals/boar.js.
// The Soul Moth (0.1.88, the Nether pair; spec 5.3 "Pale blue moth | Gathers around soul light | Enclosed airspace,
// soul lights, nectar") is a fantasy hawk moth, drawn big (Austin's "Big moth"): it flies in a roofed moth house (the
// flight measure), circles soul light (species.soulLight), sips nectar from a Nectar Feeder (nectarFeeder), rests on a
// wall by day and flies at night (nightLife; soul light counts as dark, houseLight), and its young are caterpillars that
// eat host plants and lie in the floor as a pupa (breeding.hostPlants, pupaDays). animals/moth.js.
// The Quartz Beetle (0.1.89, the Nether pair; spec 5.3 "Chunky beetle with quartz plates | Burrows through mineral
// substrate | Heated cave, mineral bed") is a fantasy rhinoceros beetle, drawn big (Austin's "Big beetle"): it lives
// in a cave (a roof over the floor, species.cover), lies buried by day in Mineral Substrate (species.substrate, the
// walking measure's count), walks at night (nightLife), and two males that meet wrestle; its young are grubs that live
// and feed in the substrate and pupate in it (breeding.substrate, pupaDays). animals/beetle.js.
// The End Hopper (0.1.91, the End trio; spec 5.4 "Small creature with long angular legs | High jumps between platforms |
// Jump clearance, roof, landing pads") is a fantasy springhare with a jerboa's long angular hind legs, life-size (about
// a rabbit's): it leaps from Landing Pad to Landing Pad (species.pads: the jump measure counts them), so its exhibit
// needs a roof (species.hops: the jump measure's flood through the air mustn't lead out); in the wild it gets away from
// someone close in zigzag darts. animals/hopper.js.
// The Shimmer Snail (0.1.92, the End trio; spec 5.4 "Pale body, pearlescent spiral shell | Leaves a fading luminous
// trail | Mineral bed, shade, crevices") is a fantasy giant land snail, drawn big (three quarters of a block crawling):
// the rock snails' crevices to rest in (species.crevices: the crevice measure counts them) and their grazing of the rock
// (species.mineralBed: Mineral Substrate in the floor), Quantula's glowing foot and trail, and the giant African land
// snail's bouts, sealed rest and eggs laid in the ground (breeding.eggBed). A hermaphrodite: any two can pair
// (species.hermaphrodite, animals/breeding.js). animals/snail.js.
// The Obsidian Crab (0.1.93, the End trio; spec 5.4 "Low armored black shell | Scrapes minerals and digs | Rocky cave,
// mineral feeder, substrate") is a fantasy coconut crab (its size, its burrow plugged with its big claw, its nose for
// food, alone) drawn as a true crab, low and wide and walking sideways: the rock crabs' scraping of bare rock
// (species.rockFaces: the rock measure counts the faces), the sand crabs' digging in backwards (species.burrows: Mineral
// Substrate in the floor), Mineral Pellets from a Mineral Feeder only (species.mineralFeeder). The mother carries her
// eggs under her tail (breeding.carried). animals/crab.js.
// The Chorus Moth (0.1.94, the End pair; spec 5.4 "Purple angular wings | Hovers around chorus flowers | Flight space,
// chorus nectar, low light") is a fantasy elephant hawk-moth, drawn big: it flies in a roofed moth house (the Soul
// Moth's profile), hovers at chorus flowers to sip (species.chorusFlowers: the chorus measure counts them), takes
// Nectar Rations from a Nectar Feeder (nectarFeeder), and keeps its bouts at any hour in a dim house (lowLight: the
// nocturnal house's test), only at night in a bright one. Its caterpillars eat chorus on the floor and lie in it as a
// pupa (breeding.hostPlants, hostText, pupaDays). animals/chorusMoth.js.
// The Starback Tortoise (0.1.95, the End pair; spec 5.4 "Dark shell with star-like markings | Slow browsing and resting
// | End vegetation, warm pad, large retreat") is a fantasy Indian star tortoise, drawn big: it keeps to bouts, resting
// under a low roof (species.retreat), basking on a Warm Pad till it's warm (warmPads), then browsing the chorus standing
// on the floor (endPlants: the tortoise measure counts all three). She digs her nest in the Mineral Substrate
// (substrateNest, breeding.eggBed, breeding.nestDig). animals/starback.js.
// The Lush Okapi (0.1.137, the cave wing; research/cave_plan.md) is a real okapi at real size, found in lush caves: it
// browses the lush plants beside its floor with its long tongue (species.lushGround: moss in the floor and lush plants
// to browse, which the okapi measure counts; part of its food), licks clay (clayLick), eats Leafy Rations from a Basic
// Feeder or an Elevated Browse Feeder (browsesEither), keeps one grown male to an exhibit (oneMale; his ossicones:
// sexLook), and its calf lies hidden its first park day (hiddenCalf). A Reinforced Crate carries one after Cave
// Expeditions research (species.research). animals/okapi.js.
// The Earth Molebear (0.1.138, the cave wing) is a fantasy animal at a black bear's size, with a mole's spade hands and
// velvet coat and a star-nosed mole's star, found in ordinary caves below y 0: it tunnels into Burrow Soil beside its
// floor, and only that (species.burrowSoil: the molebear measure counts the soil and the faces it can dig; grubs it digs
// up are part of its food), and eats Insect Rations. A Reinforced Crate carries one after Cave Expeditions research.
// animals/molebear.js.
// The Skulker (0.1.139, the cave wing) is a fantasy animal of the deep dark, the warden's shape and senses but gentle,
// 1.9 blocks tall: blind, it hears someone moving near without sneaking and walks over to sniff them. It lives in the
// dark (lowLight: the nocturnal house's test, no daylight and nothing brighter than light 7), on a sculk floor
// (species.sculkFloor: the skulker measure counts the sculk and any shrieker, which frightens it), and eats Insect
// Rations. Its ribs, heart and tendrils glow, so guests see it in the dark (glows). A Reinforced Crate carries one after
// Cave Expeditions research. animals/skulker.js; its Ancient Cities animals/ancientCityRules.js.
// The Unicorn (0.1.149, module 9: the Mythical Glade) is a fantasy animal on a light riding horse's frame and at its
// size, with a long spiral horn that glows faintly: a grazer (species.graze, as the zebra) that eats from a Hay Rack too
// and needs the glade's glowing flowers on its floor (species.gladeFlowers: the unicorn measure counts them, and the
// floor cells with water beside them, where it dips its horn). Herds of 2 to 6; a Livestock Crate carries one.
// animals/unicorn.js.
// The Dragon (0.1.150, module 9; wild in the Lava Falls since 0.1.156) is the great flier of the Nether's caverns: four legs and a pair of great wings, about 7 blocks nose to
// tail with an 11-block span. It flies round a great hall (great_aerial: roofed over, 16 blocks of air) and lands on its
// floor, so it needs no perches; it basks by a lit campfire on the floor (species.warmth: the dragon measure counts
// them), roars and breathes a stream of fire (particles only). Alone or a few together; a Reinforced Crate carries one.
// animals/dragon.js.
// The Griffin (0.1.151, module 9): a lion's body with an eagle's head, wings and forelegs, about 4.5 blocks nose to tail
// with an 8-block span. It flies round the dragons' kind of hall (great_aerial) and lands on its floor; it guards gold
// (species.hoard: a block of gold or raw gold on the floor, the griffin measure counts them), screeches rearing up,
// preens, and climbs to the roof to dive like an eagle. Alone, a pair or a few; a Reinforced Crate carries one.
// animals/griffin.js.
// The Glowhorn Stag (0.1.152, module 9) is a great deer on an elk's frame and at its size (1.6 blocks at the shoulder)
// whose antlers glow, bone-pale to mint and turquoise, brighter at night: a grazer (species.graze, as the unicorn) that
// eats Leafy Rations from a Hay Rack too, and rubs its antlers on tree trunks (species.trunks: the stag measure counts the
// spots on the floor it can rub from). Both sexes carry antlers, a hind's smaller (the coat sets the sex). Herds of 2 to
// 8; a Livestock Crate carries one. animals/glowhorn.js.
// The Giant Yeti (0.1.159, module 10: the first boss, research/boss_plan.md) is a great white-furred ape 3.6 blocks tall
// that lives alone in a lair in the taigas, one to an area (animals/boss.js makes the lairs): calm till someone hits it
// or walks right up to it, then a boss fight (its energy on a boss bar; a swipe, a ground slam and a hurled snowball,
// each with a wind-up). It is never killed: worn down to a tenth it slumps down tired out, and only then its Yeti Cage
// works (species.boss; Yeti Tracking research). In a zoo it is calm, a guest favourite (species.favourite): a big cold
// exhibit (a Cooling Unit) with snow or ice under half the floor (species.snowFloor: the snow measure) and a den (cover),
// Fruit and Fish Rations. Alone or a pair, no young. animals/yeti.js.
// The Soul Sloth (0.1.161, the second boss) is a giant ground sloth from the soul sand valleys, 2.4 blocks high on all
// fours and 4 long, that hangs upside down under the bone beam of its lair's fossil arch, asleep much of the time
// (animals/boss.js makes the lairs, one to an area): calm till someone hits it or walks right up to it, then it drops
// and fights (a claw rake, a soul wail all round it, a lobbed clump of soul sand). Never killed: worn down it curls up
// tired out, and only then its Soul Cage works (Soul Tracking research). In a zoo it is calm, a guest favourite: a
// Thermal Regulator, soul sand or soul soil under half the floor (species.soulFloor) and a beam to hang from
// (species.beam: the sloth measure), Fungal Rations. Alone or a pair, no young. animals/sloth.js.
// The Baby Dragon (0.1.162, the third boss) is a young dragon of the outer End islands, dusky purple-black with violet
// eyes, 1.7 blocks at the back, 6 long with a 10-block span, that perches on the nest atop its lair's obsidian pillar
// (animals/boss.js makes the lairs, one to an area): calm till someone hits it or walks up under it, then it fights in
// the air (animals/babyDragon.js: a dive, a void bolt, a wing gust). Never killed: worn down it glides down and lies
// panting, and only then its Dragon Crate works (Dragon Tracking research). In a zoo it is calm, a guest favourite: a
// Dragon's great hall (it is flown by animals/dragon.js) with End ground underfoot (species.endGround), Meat Rations.
// Alone or a pair, no young.
// The zoo's mobs (0.1.163, module 11, the Hostile Mob House: research/mobhouse_plan.md; species.mob). A vanilla zombie or
// skeleton (species.mobSource: the one the journal spots) weakened to a quarter of its health turns into a calmed one
// (its wildSource, zoocraft:calm_zombie) when a Passivity Serum is used on it (Mob Taming research; animals/mobs.js), and
// a Mob Cage carries that to a mob pen: an exhibit beside a Mob House's hall (the mob_pen profile, a 5 x 5 floor for the
// first), shut in all round with a roof and walled off from the hall with glass or bars (animals/mobRules.js). In a pen
// they look as in the wild, never attack, never burn in the sun and never despawn. Zombies want the dark (lowLight) and
// graveyard earth underfoot, skeletons a crypt floor (species.mobFloor), Meat Rations or Bone Rations. No young.
// The creeper and the spider (0.1.164) the same way: a creeper never swells or explodes, a spider never climbs. Creepers
// want grass underfoot and leaves or ferns in the pen (species.mobDecor), Grain Rations, and are a guest favourite;
// spiders a darker pen (light 4 or less on the floor: species.darkLight) with cobwebs, Meat Rations. Each keeps a pen
// to itself.
// The Cyclops (0.1.165), the first rare mob: its wild one is fought as a boss is (animals/boss.js, its camp in the
// windswept hills or stony peaks) and calmed with the serum once it sits down tired out; in the zoo it wants a tall pen
// (mob_pen_giant: 7 x 7 and 6 high), stone underfoot and a pile of mossy boulders, Meat Rations, and is a guest
// favourite; alone or a pair.
// The Necromancer Skeleton (0.1.166), the second rare mob: its wild one is fought as a boss is (animals/boss.js, its crypt
// in a soul sand valley or beside a Nether fortress) and calmed with the serum once it kneels tired out; in the zoo it
// lives in a Mob House pen with soul sand or soul soil under half the floor and a soul lantern or more, Bone Rations, and
// is a guest favourite; alone or a pair.
// The Voidling (0.1.167), the third rare mob: its wild one is fought as a boss is (animals/boss.js, its rift on the outer
// End islands by an edge) and calmed with the serum once it crouches tired out; in the zoo it lives in a Mob House pen
// with a solid floor, end stone or end stone bricks under half of it, and a crying obsidian or more, eats Chorus Browse,
// and is a guest favourite; alone or a pair.

export const SPECIES = {
  "zoocraft:zoo_rabbit": {
    id: "zoocraft:zoo_rabbit",
    displayName: "Rabbit",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:rabbit", // catching this wild mob creates this species
    // Let go, a wild one the game spawned young (one time in four) grows up by the game's rabbit's own event (0.1.175).
    wildGrowUp: "grow_up",
    entityType: "zoocraft:zoo_rabbit",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["leafy"],
    carrierProfile: "small",
    baitItem: "zoocraft:leafy_ration", // one is used up when the rabbit is coaxed into a carrier
    // Field Journal (spec section 8): what to watch before one can be moved safely, and where to look.
    observe: ["spot"],
    where: "Plains, meadows, flower forests, deserts and snowy slopes",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: true },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "dig"],
    // Coat comes from the wild rabbit's minecraft:variant (0 brown .. 5 salt).
    coats: ["Brown", "White", "Black", "Splotched", "Gold", "Salt"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 2, gestationDays: 1, matureDays: 2, cooldownDays: 2, juvenileScale: 0.5, young: "kit", youngPlural: "kits" },
    names: ["Pebble", "Clover", "Biscuit", "Thistle", "Maple", "Juniper", "Hazel", "Nutmeg", "Willow", "Poppy", "Sorrel", "Bramble", "Dot", "Fennel", "Sage", "Toffee"],
  },
  "zoocraft:otter": {
    id: "zoocraft:otter",
    displayName: "Otter",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_otter",
    entityType: "zoocraft:otter",
    movementProfile: "amphibious",
    habitatProfile: "small_wetland",
    dietTags: ["fish"],
    carrierProfile: "small",
    baitItem: "zoocraft:fish_ration",
    observe: ["spot", "swim", "bank"],
    where: "Rivers and swamps, in pairs or threes",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["swim", "manipulate", "forage"],
    coats: ["River"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 2, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "pup", youngPlural: "pups" },
    names: ["Ripple", "Pebble", "Bubbles", "Splash", "Brook", "Minnow", "Kelpie", "Skipper", "Puddle", "Wade", "Sprat", "Marlin", "Eddy", "Tumble", "Otto", "Nessie"],
  },
  "zoocraft:capybara": {
    id: "zoocraft:capybara",
    displayName: "Capybara",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_capybara",
    entityType: "zoocraft:capybara",
    movementProfile: "amphibious",
    habitatProfile: "medium_wetland",
    dietTags: ["leafy"],
    carrierProfile: "livestock",
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot", "swim", "bank"],
    where: "Swamps, mangrove swamps and jungles, in groups",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["swim", "forage"],
    coats: ["Russet"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 2, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.45, young: "pup", youngPlural: "pups" },
    names: ["Cappy", "Mochi", "Barley", "Pudding", "Bean", "Hazel", "Tater", "Waffles", "Nugget", "Coco", "Sprout", "Pickles", "Dumpling", "Truffle", "Basil", "Marshmallow"],
  },
  "zoocraft:deer": {
    id: "zoocraft:deer",
    displayName: "Deer",
    plural: "Deer",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_deer",
    entityType: "zoocraft:deer",
    family: "deer", // the mob family the Field Journal counts as its herd
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    dietTags: ["leafy"],
    carrierProfile: "livestock",
    baitItem: "zoocraft:leafy_ration",
    rack: true, // it eats from a Hay Rack too (0.1.74)
    observe: ["spot", "graze", "herd"],
    where: "Forests, birch forests, taigas, meadows and plains, in small herds. They keep away unless you sneak or hold food",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    // Quiet cover (spec section 5.2): trees or a roof over part of the ground, or comfort stays low.
    cover: { minFraction: 0.1 },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // Coat comes from the wild deer's minecraft:variant: 0 doe, 1 buck (antlers).
    coats: ["Doe", "Buck"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 1, gestationDays: 3, matureDays: 4, cooldownDays: 5, juvenileScale: 0.55, young: "fawn", youngPlural: "fawns" },
    sexByCoat: ["female", "male"], // a doe is female, a buck male
    names: ["Fern", "Bramble", "Hazel", "Rowan", "Willow", "Acorn", "Birch", "Clover", "Juniper", "Maple", "Thistle", "Aspen", "Bracken", "Sorrel", "Holly", "Ash"],
  },
  "zoocraft:penguin": {
    id: "zoocraft:penguin",
    displayName: "Penguin",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_penguin",
    entityType: "zoocraft:penguin",
    family: "penguin", // the mob family the Field Journal counts as its colony
    movementProfile: "amphibious",
    habitatProfile: "small_polar",
    dietTags: ["fish"],
    carrierProfile: "small",
    baitItem: "zoocraft:fish_ration",
    observe: ["spot", "swim", "colony"],
    where: "Frozen places (snowy plains, ice spikes, snowy beaches, frozen rivers), in colonies",
    social: { minGroup: 3, recommendedMax: 12, prefersCompany: true },
    // A cold habitat (spec section 5.5): a stocked Cooling Unit, or comfort stays low.
    cold: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["swim", "forage"],
    coats: ["Gentoo"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 1, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.6, young: "chick", youngPlural: "chicks" },
    names: ["Pip", "Waddles", "Pebble", "Flipper", "Tux", "Sprat", "Skipper", "Nugget", "Biscuit", "Bubbles", "Frost", "Pingu", "Domino", "Sardine", "Puffin", "Mumble"],
  },
  "zoocraft:giraffe": {
    id: "zoocraft:giraffe",
    displayName: "Giraffe",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_giraffe",
    entityType: "zoocraft:giraffe",
    family: "giraffe", // the mob family the Field Journal counts as its herd
    movementProfile: "terrestrial",
    habitatProfile: "tall_terrestrial",
    dietTags: ["leafy"],
    // Elevated browse (spec section 5.5): giraffes eat only from an Elevated Browse Feeder.
    browsesHigh: true,
    carrierProfile: "large",
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot", "browse", "herd"],
    where: "Savannas, in small herds",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Reticulated"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 1, gestationDays: 4, matureDays: 6, cooldownDays: 8, juvenileScale: 0.45, young: "calf", youngPlural: "calves" },
    names: ["Twiga", "Stretch", "Acacia", "Patches", "Sunny", "Marigold", "Kito", "Zuri", "Amber", "Biscuit", "Lofty", "Savanna", "Toffee", "Jengo", "Pippa", "Rafiki"],
  },
  "zoocraft:elephant": {
    id: "zoocraft:elephant",
    displayName: "Elephant",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_elephant",
    entityType: "zoocraft:elephant",
    family: "elephant", // the mob family the Field Journal counts as its herd
    movementProfile: "terrestrial",
    habitatProfile: "large_terrestrial",
    dietTags: ["leafy"],
    carrierProfile: "large",
    baitItem: "zoocraft:leafy_ration",
    rack: true, // it eats from a Hay Rack too (0.1.74)
    observe: ["spot", "trunk", "herd"],
    where: "Savannas, in small herds",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    // Mud bathing (spec section 5.2; item list: "Mud Wallow | Vanilla mud (registered)"): enough
    // blocks of mud in the exhibit floor, or comfort stays low.
    mud: { minCells: 6 },
    rationUnitsPerParkDay: 4,
    // Durable enrichment: the Enrichment Ball (manipulate) and a Hanging Food Basket (forage).
    enrichmentTags: ["manipulate", "forage"],
    coats: ["Savanna"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 1, gestationDays: 5, matureDays: 8, cooldownDays: 10, juvenileScale: 0.4, young: "calf", youngPlural: "calves" },
    names: ["Tembo", "Nandi", "Pebbles", "Jumbo", "Kibo", "Amara", "Dumbo", "Ruby", "Mosi", "Thandi", "Boulder", "Nala", "Juma", "Olive", "Rumble", "Ellie"],
  },
  "zoocraft:hedgehog": {
    id: "zoocraft:hedgehog",
    displayName: "Hedgehog",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_hedgehog",
    entityType: "zoocraft:hedgehog",
    family: "hedgehog",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["insect"],
    carrierProfile: "small",
    baitItem: "zoocraft:insect_ration",
    observe: ["spot", "forage", "curl"],
    where: "Forests, plains and meadows at night, nosing through the grass alone. By day they sleep curled up, so look after dark",
    // A pair and a litter (0.1.81: below that, the first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: false },
    // Spec 5: "Night foraging and curling | Small tunnels and nocturnal viewing". Asleep by Minecraft
    // day and up at night (animals/night.js); a nocturnal house (a fully enclosed, dark building lit by
    // Nocturnal Lamps) turns that round so guests see them by day (animals/nightRules.js).
    nocturnal: true,
    // Its den is a Burrow Shelter (a leaf-litter mound over a log), not an Ember Den.
    den: "burrow",
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "dig"],
    // Coat comes from minecraft:variant: 0 Brown (the common coat), 1 Blonde (pale spines, rarer).
    coats: ["Brown", "Blonde"],
    breeding: { litter: 3, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "hoglet", youngPlural: "hoglets" },
    names: ["Prickles", "Bramble", "Sonic", "Mrs Tiggy", "Conker", "Quill", "Hazel", "Nutkin", "Pudding", "Twiggy", "Hedwig", "Thistle", "Acorn", "Moss", "Pip", "Dusk"],
  },
  "zoocraft:basalt_tortoise": {
    id: "zoocraft:basalt_tortoise",
    displayName: "Basalt Tortoise",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_basalt_tortoise",
    entityType: "zoocraft:basalt_tortoise",
    family: "basalt_tortoise",
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    dietTags: ["mineral"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:mineral_pellets",
    observe: ["spot", "bask", "gnaw"],
    where: "Basalt deltas in the Nether, basking on magma blocks",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator, or comfort stays low and after
    // the recovery window it goes to recovery holding.
    heat: true,
    // Basking pads (spec 5.3: "Hot stones, basalt ground"): magma blocks in the exhibit floor.
    bask: { minCells: 4 },
    // It drinks lava, not water (Austin, 0.1.44): a Lava Trough filled with lava buckets.
    drinksLava: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage", "manipulate"],
    // Its favourite toy: a Wither Skull Ball to nudge around with its beak.
    toys: ["skull"],
    coats: ["Basalt"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 2, gestationDays: 3, matureDays: 6, cooldownDays: 6, juvenileScale: 0.4, young: "hatchling", youngPlural: "hatchlings" },
    names: ["Cinder", "Slag", "Pumice", "Ember", "Obsidian", "Clinker", "Basil", "Tuff", "Magma", "Scoria", "Ash", "Flint", "Smoky", "Kiln", "Coal", "Rocky"],
  },
  "zoocraft:ember_fox": {
    id: "zoocraft:ember_fox",
    displayName: "Ember Fox",
    plural: "Ember Foxes",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_ember_fox",
    entityType: "zoocraft:ember_fox",
    family: "ember_fox",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["ember"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:ember_ration",
    observe: ["spot", "sniff", "prowl"],
    where: "Soul sand valleys and crimson forests in the Nether, trotting over soul soil",
    // A pair and a litter (0.1.81: below that, the first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: false },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator, or comfort stays low and after
    // the recovery window it goes to recovery holding.
    heat: true,
    // Spec 5.3: "Digs warm ash and curls in heated den | Ash bed, den, heat supply".
    ash: { minCells: 4 },
    den: true,
    // Like the Basalt Tortoise, it drinks lava from a Lava Trough.
    drinksLava: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "manipulate", "dig"],
    // Its favourite toy: a Blaze Bone to chew and bury in the ash.
    toys: ["bone"],
    coats: ["Charcoal"],
    breeding: { litter: 3, gestationDays: 3, matureDays: 5, cooldownDays: 6, juvenileScale: 0.5, young: "kit", youngPlural: "kits" },
    names: ["Sooty", "Flicker", "Kindle", "Scorch", "Tinder", "Wick", "Blaze", "Smudge", "Sizzle", "Charcoal", "Pepper", "Toast", "Spark", "Ashby", "Glow", "Fennel"],
  },
  "zoocraft:lava_ray": {
    id: "zoocraft:lava_ray",
    displayName: "Lava Ray",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_lava_ray",
    entityType: "zoocraft:lava_ray",
    family: "lava_ray",
    movementProfile: "lava",
    habitatProfile: "lava_pool",
    dietTags: ["plankton"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:molten_plankton",
    observe: ["spot", "glide", "drift"],
    where: "The Lava Falls in the Nether most of all, and lava lakes in basalt deltas and the Nether wastes, gliding just under the surface",
    // A pair and a litter (0.1.81: below that, the first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // Spec 5.3: it swims in lava (a lava pool counts as its space; see exhibits/geometry.js swimLava).
    // The lava keeps it warm, so it needs no Thermal Regulator, and it drinks nothing else.
    lavaSwimmer: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Ember"],
    breeding: { litter: 2, gestationDays: 3, matureDays: 6, cooldownDays: 6, juvenileScale: 0.45, young: "pup", youngPlural: "pups" },
    names: ["Cinder", "Glimmer", "Molten", "Ripple", "Flare", "Ashwing", "Ignis", "Lumen", "Sear", "Drift", "Magmar", "Kindle", "Ember", "Glow", "Coral", "Smolder"],
  },
  "zoocraft:zoo_strider": {
    id: "zoocraft:zoo_strider",
    displayName: "Strider",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "minecraft:strider", // catching a wild strider creates this species
    // Let go grown with no rider (0.1.175): the game's own spawn for a grown one. Its usual spawn rolls a young one half the
    // time, and one time in ten a rider on its back (a zombified piglin, or a young strider).
    wildGrown: "spawn_adult",
    entityType: "zoocraft:zoo_strider",
    family: "strider",
    movementProfile: "lava_walker",
    habitatProfile: "lava_shore",
    dietTags: ["fungus"],
    carrierProfile: "thermal",
    baitItem: "minecraft:warped_fungus",
    observe: ["spot", "stride", "ashore"],
    where: "Lava seas all over the Nether, walking across the lava; they shiver and turn purple when they step ashore",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    // It walks on lava (a lava pool counts as its space, see exhibits/geometry.js swimLava) and the lava
    // keeps it warm, so it needs no Thermal Regulator and drinks nothing else.
    lavaWalker: true,
    // Warm resting spots (spec 5.1): magma blocks on the bank. On lava or magma it's warm; anywhere
    // else it shivers (the vanilla cold look).
    bask: { minCells: 4, rest: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Crimson"],
    breeding: { litter: 1, gestationDays: 2, matureDays: 4, cooldownDays: 4, juvenileScale: 0.5, young: "baby strider", youngPlural: "baby striders" },
    names: ["Stilts", "Wobble", "Crimson", "Toasty", "Lanky", "Fungo", "Scorch", "Warp", "Sizzle", "Basalt", "Wade", "Ember", "Shiver", "Magma", "Tiptoe", "Pudding"],
  },
  "zoocraft:chorus_deer": {
    id: "zoocraft:chorus_deer",
    displayName: "Chorus Deer",
    plural: "Chorus Deer",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_chorus_deer",
    entityType: "zoocraft:chorus_deer",
    family: "chorus_deer", // the mob family the Field Journal counts as its herd
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    dietTags: ["chorus"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "browse", "herd"],
    where: "The Chorus Meadows on the outer End islands (green turf, white trees and ponds) and the outer islands' end stone among the chorus plants, in small herds. They keep away unless you sneak or hold food",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    // Quiet retreat (spec 5.4): trees, chorus plants or a roof over part of the ground.
    cover: { minFraction: 0.1 },
    // End ground (spec 5.4 "End ground | vanilla end stone"): end stone in the exhibit floor, or comfort
    // stays low.
    endGround: { minCells: 8 },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Lavender (the common coat), 1 Dusk (deep violet, starry flecks).
    coats: ["Lavender", "Dusk"],
    // Breeding (spec section 9): young per birth, park days expecting, park days to grow up, rest
    // after a birth, and how big the young look next to an adult.
    breeding: { litter: 1, gestationDays: 3, matureDays: 4, cooldownDays: 5, juvenileScale: 0.55, young: "fawn", youngPlural: "fawns" },
    names: ["Chorus", "Echo", "Lilac", "Violet", "Pearl", "Nova", "Wisp", "Hollow", "Drift", "Twilight", "Aster", "Iris", "Mauve", "Orchid", "Rift", "Lumen"],
  },
  "zoocraft:void_ray": {
    id: "zoocraft:void_ray",
    displayName: "Void Ray",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_void_ray",
    entityType: "zoocraft:void_ray",
    family: "void_ray",
    movementProfile: "aerial",
    habitatProfile: "large_aerial",
    flies: true, // steered through the air by animals/flight.js; the exhibit is measured by floodAerial
    dietTags: ["chorus"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "soar", "loop"],
    where: "High over the outer End islands and around End Cities, gliding in slow arcs. Hold Chorus Browse and one comes down to hover over you; keep feeding it and it may let you ride it",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: true },
    endGround: { minCells: 16 },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Void", "Nebula"],
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 6, juvenileScale: 0.5, young: "pup", youngPlural: "pups" },
    names: ["Umbra", "Nebula", "Comet", "Zephyr", "Halo", "Eclipse", "Vesper", "Aurora", "Quasar", "Nimbus", "Sable", "Stardust", "Lyra", "Orion", "Mist", "Glimmer"],
  },
  "zoocraft:rift_ferret": {
    id: "zoocraft:rift_ferret",
    displayName: "Rift Ferret",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_rift_ferret",
    entityType: "zoocraft:rift_ferret",
    family: "rift_ferret",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["chorus"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "blink", "peer"],
    where: "The Rift Willows on the outer End islands (violet turf under great white willows) most of all, and the outer islands' end stone, nosing about alone or in pairs. One blinks away through a rift when you come close, unless you sneak or hold Chorus Browse",
    // A pair and a litter (0.1.81: below that, the first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: true },
    endGround: { minCells: 6 },
    // Spec 5.4: "Short puzzle-route teleports | Active containment anchor, hiding tunnels". A charged
    // Containment Anchor keeps its blinks inside the exhibit (animals/rift.js); without one it doesn't
    // blink and is unsettled. Rift Tunnels on the floor are its route and its hiding places.
    anchor: true,
    tunnels: { min: 2 },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "manipulate", "dig"],
    // Coat comes from minecraft:variant: 0 Twilight (the common coat), 1 Moonlit (pale, magenta shimmer).
    coats: ["Twilight", "Moonlit"],
    breeding: { litter: 3, gestationDays: 3, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "kit", youngPlural: "kits" },
    names: ["Blink", "Flicker", "Scamper", "Portal", "Pip", "Wisp", "Ripple", "Vex", "Nimble", "Quill", "Dash", "Fidget", "Shimmer", "Zip", "Mote", "Skitter"],
  },
  "zoocraft:raccoon": {
    id: "zoocraft:raccoon",
    displayName: "Raccoon",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_raccoon",
    entityType: "zoocraft:raccoon",
    family: "raccoon",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    // It eats nearly anything: Fruit Rations (apples, berries, melon), Insect Rations or Fish Rations.
    dietTags: ["fruit", "insect", "fish"],
    carrierProfile: "small",
    baitItem: "zoocraft:fruit_ration",
    observe: ["spot", "climb", "wash"],
    where: "Forests, swamps and riversides, out at night: up the trees, washing food at the water's edge, and raiding Litter Bins that have no latch. Hold a Fruit Ration and one comes to you",
    // A pair and a litter (0.1.81: below that, the first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: false },
    // Spec 5.x: "Manipulates puzzle feeders | Climbing; attracted to unsecured bins". It climbs out of
    // an exhibit that isn't climb-proof (climbs), wants a climbing tree or a Climbing Frame (climbTree)
    // and water to wash its food in (wash), and works a stocked Puzzle Feeder (manipulate).
    climbs: true,
    climbTree: true,
    wash: { minCells: 1 },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["manipulate", "climb", "forage"],
    // Coat comes from minecraft:variant: 0 Grey (the common coat), 1 Cinnamon (warm brown, rarer).
    coats: ["Grey", "Cinnamon"],
    breeding: { litter: 3, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "kit", youngPlural: "kits" },
    names: ["Bandit", "Rascal", "Ringo", "Mischief", "Pepper", "Smudge", "Socks", "Nibbles", "Rummage", "Scout", "Juniper", "Mango", "Pickles", "Zorro", "Maple", "Tumble"],
  },
  "zoocraft:flamingo": {
    id: "zoocraft:flamingo",
    displayName: "Flamingo",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_flamingo",
    entityType: "zoocraft:flamingo",
    family: "flamingo",
    movementProfile: "amphibious",
    habitatProfile: "wading",
    // Flamingo Pellets keep them pink (pink, below); Insect Rations feed them but don't.
    dietTags: ["pellet", "insect"],
    carrierProfile: "small",
    baitItem: "zoocraft:flamingo_pellets",
    observe: ["spot", "filter", "oneleg", "display"],
    where: "Mangrove swamps, swamps and warm beaches, in flocks by day: wading in the shallows, filter feeding with their heads upside down, and resting on one leg. A wild flock walks away from anyone who isn't sneaking or holding Flamingo Pellets",
    social: { minGroup: 3, recommendedMax: 16, prefersCompany: true },
    // Spec 5.2: "Flock wading | Shallow water and mud nesting". They wade in the shallows (wades: the
    // wading profile's shallows), get their pink from their food (pink: Flamingo Pellets, or they fade)
    // and nest only in a flock of nest.flock grown-ups (each Flock Mirror counts as nest.mirrorBirds
    // more, up to twice the flock), every grown-up rosy, on mud at the water's edge (nest.sites or more).
    wades: true,
    pink: true,
    nest: { flock: 6, sites: 2, mirrorBirds: 2 },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["swim", "forage"],
    coats: ["Greater"],
    // One egg: a park day building the nest, then two sitting on the egg in turns. The chick is grey.
    breeding: { litter: 1, gestationDays: 3, matureDays: 4, cooldownDays: 4, juvenileScale: 0.4, young: "chick", youngPlural: "chicks" },
    names: ["Rosa", "Coral", "Blush", "Peaches", "Flossie", "Paloma", "Sorbet", "Petal", "Carmen", "Lola", "Bubblegum", "Shrimp", "Sunset", "Guava", "Flora", "Rosita"],
  },
  "zoocraft:zebra": {
    id: "zoocraft:zebra",
    displayName: "Zebra",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_zebra",
    entityType: "zoocraft:zebra",
    family: "zebra",
    movementProfile: "terrestrial",
    habitatProfile: "grassland",
    // Grain Rations (hay with a little grain), from a Basic Feeder or a Hay Rack (rack, below).
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "graze", "file", "groom"],
    where: "Savannas, in herds by day: grazing spread out, walking off in single file, and galloping away from anyone who runs at them. A wild herd moves off from anyone who isn't sneaking or holding a Grain Ration",
    social: { minGroup: 3, recommendedMax: 10, prefersCompany: true },
    // Spec 5.2: "Coordinated herd movement | Savanna mixing and broad grazing". They graze (graze:
    // perAnimal grass blocks in the floor for each give them up to `share` of their food), live in harems
    // (harem: one stallion with the mares and foals, other stallions in a bachelor group), eat from a Hay
    // Rack (rack) and feed in rank order (feedRank: with too few feeding places the low-ranking ones get
    // pushed off). animals/zebra.js, animals/zebraRules.js.
    graze: { perAnimal: 30, share: 0.5 },
    harem: true,
    rack: true,
    feedRank: true,
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage", "manipulate"],
    // Coat comes from minecraft:variant: 0 Burchell's (the southern form: brown shadow stripes, paler
    // lower legs), 1 Grant's (the northern form: crisp black and white down to the hooves). Foals are brown.
    coats: ["Burchell's", "Grant's"],
    // One foal after a long wait; it grows up slowly.
    breeding: { litter: 1, gestationDays: 4, matureDays: 5, cooldownDays: 6, juvenileScale: 0.6, young: "foal", youngPlural: "foals" },
    names: ["Ziggy", "Stripes", "Zola", "Duma", "Jabari", "Amani", "Imani", "Baraka", "Dazzle", "Barcode", "Tamu", "Kesi", "Zebedee", "Pinstripe", "Humbug", "Zigzag"],
  },
  "zoocraft:lion": {
    id: "zoocraft:lion",
    displayName: "Lion",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_lion",
    entityType: "zoocraft:lion",
    family: "lion",
    movementProfile: "terrestrial",
    habitatProfile: "pride",
    // Meat Rations (zoos feed a meat mix, bones and whole prey), from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "large",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "pile", "scent", "roar"],
    where: "Savannas, in prides: lying up in the shade most of the day, hunting at dusk, through the night and at dawn. Very dangerous: a wild pride stalks anyone it spots and charges. Throw a Meat Ration down near one: while it eats it's calm, and can be crated",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    // Spec 5.2: "Pride rest and scent investigation | Group dens, secure service access". dangerous: the
    // keepers' rules and the danger to players (animals/predators.js); dens: a Holding Den for each grown
    // lion and `spare` more (three dens for two cats); fasts: one park day in seven without food; ledge: a
    // raised place to rest for each (BALANCE.lion.ledgePerLion); manes: the males' mane, light or dark
    // (their mark_variant); shade over part of the ground (cover). animals/lion.js, animals/lionRules.js.
    dangerous: true,
    dens: { spare: 1 },
    fasts: true,
    ledge: true,
    manes: true,
    cover: { minFraction: 0.1, why: "shade" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["scent", "manipulate", "forage"],
    // Coat comes from minecraft:variant: 0 a lioness, 1 a lion (the maned male). The mane is its own mark.
    coats: ["Lioness", "Lion"],
    sexByCoat: ["female", "male"],
    // 1 to 3 cubs (litterMax) after a few park days; cubs grow up slowly, in the pride's care.
    breeding: { litter: 1, litterMax: 3, gestationDays: 3, matureDays: 6, cooldownDays: 6, juvenileScale: 0.48, young: "cub", youngPlural: "cubs" },
    sounds: { warn: "mob.polarbear.warning", warnPitch: 0.55, swipe: "mob.ravager.bite", swipePitch: 0.9 },
    names: ["Simba", "Dhahabu", "Asha", "Imara", "Malaika", "Jasiri", "Tau", "Subira", "Shani", "Bahati", "Zawadi", "Jabali", "Neema", "Sefu", "Kesho", "Ayo"],
  },
  "zoocraft:tiger": {
    id: "zoocraft:tiger",
    displayName: "Tiger",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_tiger",
    entityType: "zoocraft:tiger",
    family: "tiger",
    movementProfile: "terrestrial",
    habitatProfile: "tiger",
    // Meat Rations (zoos feed a meat mix, bones and whole prey), from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "large",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mark", "swim", "ambush"],
    where: "Jungles (Bengal tigers) and cold taigas (Amur tigers), alone: resting by day, patrolling and marking at dusk and by night, swimming in the heat. Very dangerous: one creeps up behind anyone it spots and rushes them; it freezes when you look at it. Throw a Meat Ration down near one: while it eats it's calm, and can be crated",
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: false },
    // Spec 5.2: "Solitary patrolling and swimming | Privacy and separate adult territories". dangerous: the
    // keepers' rules and the danger to players (animals/predators.js); dens: a Holding Den each (spare 0),
    // a tigress's cubs going in with her (cubsFollow); fasts: one park day in seven without food;
    // solitary: one grown tiger loose at a time, the turns; privacy: screened floor to get out of sight
    // (BALANCE.tiger.screenPerTiger); patterns: 3 stripe patterns a coat (minecraft:skin_id); sexLook: the
    // male's size and ruff (minecraft:mark_variant 1); shade over part of the ground (cover).
    // Happy alone; an exhibit holds up to 5 (a pair and their cubs, say), one grown tiger (or a tigress
    // and her cubs) out at a time, the others taking turns in their dens.
    dangerous: true,
    dens: { spare: 0, cubsFollow: true },
    fasts: true,
    solitary: true,
    privacy: true,
    patterns: 3,
    sexLook: true,
    cover: { minFraction: 0.1, why: "shade" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["scent", "manipulate", "swim"],
    // Coat comes from minecraft:variant: 0 a Bengal tiger (deep orange, black stripes), 1 an Amur tiger
    // (paler and longer-furred, brown-black stripes spaced wider).
    coats: ["Bengal", "Amur"],
    // 1 to 3 cubs (litterMax) after an introduction day; cubs stay with their mother a long while.
    breeding: { litter: 1, litterMax: 3, gestationDays: 3, matureDays: 8, cooldownDays: 8, juvenileScale: 0.45, young: "cub", youngPlural: "cubs" },
    sounds: { warn: "mob.cat.hiss", warnPitch: 0.45, swipe: "mob.ravager.bite", swipePitch: 0.95 },
    names: ["Raja", "Mira", "Kavi", "Sundari", "Bagha", "Tara", "Arjun", "Rani", "Shere", "Leela", "Vikram", "Ishani", "Bodhi", "Nisha", "Rudra", "Sasha", "Yuri", "Anya", "Dasha", "Misha"],
  },
  "zoocraft:crocodile": {
    id: "zoocraft:crocodile",
    displayName: "Crocodile",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_crocodile",
    entityType: "zoocraft:crocodile",
    family: "crocodile",
    movementProfile: "amphibious",
    habitatProfile: "crocodile",
    // Meat Rations (zoos feed whole prey and meat, about once a week), from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "large",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "gape", "roll", "lurk"],
    where: "Swamps and mangrove swamps, one or two together: lurking in the water with only the eyes showing, basking on the bank by day. Very dangerous: one lunges out of the water at anyone near the edge, drags them in and rolls (hit it to make it let go), and you can't outswim one. Throw a Meat Ration down near one: while it eats it's calm, and can be crated",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Spec 5.2: "Basking and submerged resting | Secure keeper access, shore clearance". dangerous: the
    // keepers' rules and the danger to players (animals/predators.js); dens: a Holding Den for each grown one
    // (the young stay out: they're no danger); basks: a sunny basking bank in size order
    // (BALANCE.croc.bankPerCroc each); submerges: deep water for all to go under at once; shoreClear: keepers go
    // in only with the water's edge clear and the inner Keeper Gate back from it; meals: a grown one eats about
    // once a week (its satiety drains at a seventh of the rate, and it eats when it's down to 75); rank: the
    // biggest first at the food and on the bank; sizes: 5 size classes (zoocraft:size), a male a third bigger
    // (sexLook: minecraft:mark_variant 1); patterns: 3 tail crests (minecraft:skin_id: Bouwman and Cronje 2016
    // tell wild ones apart by them); sandNest: she digs a nest in sand near the water, and its warmth sets the
    // hatchlings' sex (tsd). Shade over part of the ground (cover: SA DENR, "shade for all").
    dangerous: true,
    dens: { spare: 0 },
    basks: true,
    submerges: true,
    shoreClear: true,
    meals: { every: 7, at: 75 },
    rank: true,
    sizes: 5,
    sexLook: true,
    patterns: 3,
    sandNest: { sites: 1, tsd: true },
    cover: { minFraction: 0.1, why: "shade" },
    dangerMoves: "warn anyone inside their exhibit (reared up, puffed, the jaws wide, hissing), then charge and snap sideways",
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage", "swim"],
    // One coat, the Nile crocodile's: dark olive-bronze with faded cross-bands, the young greener and boldly banded.
    coats: ["Nile"],
    // 2 to 4 hatchlings (the ones that make it: real clutches are 25 to 80 eggs) after the incubation in the
    // sand nest; most nest every 2 to 3 years.
    breeding: { litter: 2, litterMax: 4, gestationDays: 4, matureDays: 10, cooldownDays: 12, juvenileScale: 0.1, young: "hatchling", youngPlural: "hatchlings" },
    sounds: { warn: "mob.cat.hiss", warnPitch: 0.35, swipe: "mob.ravager.bite", swipePitch: 0.8 },
    names: ["Kubwa", "Mara", "Gena", "Nkosi", "Sobek", "Ayana", "Ziwa", "Mamba", "Ramla", "Khufu", "Nefer", "Nia", "Sadiki", "Lulu", "Gugu", "Pili", "Tumo", "Sefa"],
  },
  "zoocraft:red_panda": {
    id: "zoocraft:red_panda",
    displayName: "Red Panda",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_red_panda",
    entityType: "zoocraft:red_panda",
    family: "red_panda",
    movementProfile: "terrestrial",
    habitatProfile: "arboreal",
    // Bamboo, offered freely in zoos (the AZA manual): Leafy Rations.
    dietTags: ["leafy"],
    carrierProfile: "small",
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot", "headfirst", "drape", "tailwrap"],
    where: "Bamboo jungles, one or two together, out at dawn and dusk: up in the trees, draped over a branch through the day. A wild one goes up a tree when someone comes near; hold a Leafy Ration and one comes to you",
    // A mother with her cubs (0.1.81: at 2, a pair's first litter could never come: "the group is full").
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // Spec 5.2: it climbs out of an exhibit that isn't climb-proof (climbs) and wants something to climb
    // (climbTree), as the raccoon does; it travels and rests up on the canopy, which has to be reached from a
    // trunk (canopy: balance.redpanda.canopyPer blocks for each); it sleeps in a Nest Box (nestBox, one each); in
    // a hot biome it needs shade (heatShade).
    climbs: true,
    climbTree: true,
    canopy: true,
    nestBox: true,
    heatShade: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["climb", "forage"],
    // One coat, the western (Himalayan) red panda's; the cubs are born buff-grey and turn red as they grow.
    coats: ["Western"],
    // Usually 2 cubs, 1 to 4 (SDZ); born in the Nest Box and staying in it their first park day.
    breeding: { litter: 2, litterMax: 3, gestationDays: 3, matureDays: 3, cooldownDays: 5, juvenileScale: 0.35, young: "cub", youngPlural: "cubs" },
    names: ["Momo", "Ginger", "Pabu", "Rusty", "Bamboo", "Sherpa", "Tashi", "Nima", "Kesar", "Pemba", "Mishka", "Tenzin", "Chestnut", "Russet", "Saffron", "Cinnamon"],
  },
  "zoocraft:gorilla": {
    id: "zoocraft:gorilla",
    displayName: "Gorilla",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_gorilla",
    entityType: "zoocraft:gorilla",
    family: "gorilla",
    movementProfile: "terrestrial",
    habitatProfile: "troop",
    // Browse and leaves (EAZA 2024: vegetables, browse and pellets; little fruit): Leafy Rations, and Fruit
    // Rations (the items list's gorilla food), which bait a wild one.
    dietTags: ["leafy", "fruit"],
    carrierProfile: "large",
    baitItem: "zoocraft:fruit_ration",
    observe: ["spot", "chestbeat", "nightnest", "picking"],
    where: "Jungles, in troops: one silverback with his females and young, feeding by day and building nests of branches to sleep in at dusk. Come close and the silverback warns you off, beating his chest; keep coming and he charges. Throw a Fruit Ration down near one: while it eats it can be crated",
    social: { minGroup: 2, recommendedMax: 10, prefersCompany: true },
    // Spec 5.2: dangerous: the keepers' rules and the danger to players (animals/predators.js); dens: a
    // Holding Den each, an infant going in with its mother (cubsFollow); troop: one silverback (two with the
    // females fight, as zebra stallions do; a bachelor group is fine); ape: strong walls, the ape measure
    // (exhibits/geometry.js floodApe: they climb trees, frames and fences and reach up 3.5 blocks); noSwim:
    // deep water is a danger; climbTree: something to climb; sexLook: the silverback's size, saddle and crest
    // (minecraft:mark_variant 1).
    dangerous: true,
    dens: { spare: 0, cubsFollow: true },
    dangerMoves: "warn anyone inside their exhibit (up on the legs, beating the chest), then charge and shove",
    troop: true,
    ape: true,
    noSwim: true,
    climbTree: true,
    sexLook: true,
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["climb", "forage", "manipulate"],
    // One coat, the western lowland gorilla's: black-brown, a reddish crown, a silverback's silver saddle.
    coats: ["Western lowland"],
    // One infant (twins are rare), carried on its mother's back; slow to grow up, a long while between births.
    breeding: { litter: 1, gestationDays: 4, matureDays: 8, cooldownDays: 10, juvenileScale: 0.4, young: "infant", youngPlural: "infants" },
    sounds: { warn: "mob.polarbear.warning", warnPitch: 0.75, swipe: "mob.irongolem.throw", swipePitch: 0.8 },
    names: ["Kumbuka", "Ndume", "Kouillou", "Ozala", "Shufai", "Moja", "Lope", "Bakari", "Mekili", "Mbeli", "Tumani", "Nyota", "Sango", "Kwame", "Asali", "Djala"],
  },
  "zoocraft:owl": {
    id: "zoocraft:owl",
    displayName: "Owl",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_owl",
    entityType: "zoocraft:owl",
    family: "owl",
    movementProfile: "aerial",
    habitatProfile: "aviary",
    flies: true, // steered through the air by animals/owl.js; the aviary is measured by floodAerial
    // Whole prey (AZA 2019: mice, rats, rabbits, quail, chicks): Meat Rations, which tempt a wild one down.
    dietTags: ["meat"],
    carrierProfile: "small",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "hoot", "pounce", "pellet"],
    where: "Taiga, dark forest and windswept hills, alone or a pair: roosting in a treetop by day, hooting at dusk and flying from tree to tree at night. Hold a Meat Ration and one comes down to land by you",
    // A pair shares an aviary and stays together (AZA 2019), with their young: up to 5 (a pair and 3 owlets).
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: true },
    // Spec 5.2: perches at varied heights (roosts: Perches, the fixture "roost", 2 or more apart in height for
    // comfort); the sexes look alike but the female is bigger (sexLook: a male is minecraft:mark_variant 1, drawn
    // at 0.88 of her).
    roosts: true,
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // One coat, the eagle-owl's: tawny, streaked dark, the ear tufts and orange eyes; owlets in grey-buff down.
    coats: ["Eagle-owl"],
    // Usually 2 eggs (up to 3 here; 1 to 4, König & Weick 2008), laid only in a Nest Box (nestBox) and sat on by the
    // female; the owlets stay in the box their first park days (balance.owl.nestDays).
    breeding: { litter: 2, litterMax: 3, gestationDays: 3, matureDays: 6, cooldownDays: 8, juvenileScale: 0.6, young: "owlet", youngPlural: "owlets", nestBox: true },
    names: ["Bubo", "Strix", "Hoolet", "Duskwing", "Fenwick", "Ural", "Eyrie", "Gloaming", "Corvin", "Moonbeam", "Nightjar", "Barnaby", "Talon", "Oakley", "Tawny", "Midnight"],
  },
  // The Midnight Owl (0.1.238 wild, 0.1.239 in the zoo; Austin, 2026-11-10: "midnight owls ... dark black, with bright
  // blue eyes, they are the size of the players, they are not dangerous", then "Zoo animal too"). The Exotic
  // Formation's owl: the game flies it (the fly movement the parrots have), it lands, looks at whoever comes close and
  // harms nothing. The halls are features, not a biome, so the wild ones are kept there by world/midnightOwls.js.
  "zoocraft:midnight_owl": {
    id: "zoocraft:midnight_owl",
    displayName: "Midnight Owl",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_midnight_owl",
    entityType: "zoocraft:midnight_owl",
    family: "midnight_owl",
    movementProfile: "aerial",
    habitatProfile: "owl_cavern",
    flies: true, // the game's own fly movement and navigation; the cavern is measured by floodAerial
    dietTags: ["meat"], // whole prey, as the zoo's other owl
    carrierProfile: "large", // as big as a player: the Reinforced Crate
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "flock"],
    where: "The great halls of the Exotic Formation, deep underground (/zoocraft:formation points to one), up to five to a hall: black, as tall as you, with bright blue eyes that shine in the dark. They fly about the hall, land on its floor and ledges and turn to look at you. Harmless",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true }, // a hall's owls keep together
    rationUnitsPerParkDay: 2, // a big bird
    enrichmentTags: ["forage"],
    coats: ["Midnight"],
    // A game choice (nothing is known of them): 1 or 2 owlets after 4 park days, grown in 8; an owlet is half size.
    breeding: { litter: 1, litterMax: 2, gestationDays: 4, matureDays: 8, cooldownDays: 10, juvenileScale: 0.5, young: "owlet", youngPlural: "owlets" },
    names: ["Cobalt", "Raven", "Sapphira", "Lazuli", "Sootwing", "Bluewink", "Glintwing", "Midnighter", "Evenfall", "Darkling", "Cerulea", "Nightglass", "Inkfeather", "Deepwatch", "Hollowhoot", "Blackquill"],
  },
  "zoocraft:crimson_grazer": {
    id: "zoocraft:crimson_grazer",
    displayName: "Crimson Grazer",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_crimson_grazer",
    entityType: "zoocraft:crimson_grazer",
    family: "crimson_grazer",
    movementProfile: "terrestrial",
    habitatProfile: "herd",
    // Fungal Rations (crimson and warped fungus with nether wart; items list "Fungal Ration | Crimson Grazer,
    // mooshrooms | Crimson and warped fungus"), or plain warped fungus, from a Basic Feeder.
    dietTags: ["fungus"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:fungal_ration",
    observe: ["spot", "ring", "rub", "cud"],
    where: "Crimson forests in the Nether, in herds of 3 to 5 on the crimson nylium. Come near and the herd forms a ring, horns out, and a bull rushes at you and stops short; hurt one and he means it. Hold a Fungal Ration and they let you close",
    // Musk oxen live in herds of 8 to 24; 3 to 8 fits an exhibit. Alone or in twos they're uneasy.
    social: { minGroup: 3, recommendedMax: 8, prefersCompany: true },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator, or comfort stays low and after the recovery
    // window it goes to recovery holding. Crimson ground: balance.grazer.nyliumCells crimson nylium blocks in the
    // floor (nylium); a crimson stem or hyphae beside the floor to rub on (rubStem); herd shelter: trees or a roof
    // over a tenth of the floor (cover). Spec 5.3: "Crimson ground, fungal feed, herd shelter".
    heat: true,
    nylium: true,
    rubStem: true,
    cover: { minFraction: 0.1, why: "herd shelter" },
    // A bull is bigger, with the heavy boss across his brow (minecraft:mark_variant 1).
    sexLook: true,
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // One coat: a crimson-maroon hide, a shaggy dark mane, a pale shroomlight-yellow muzzle, fungus caps on the shoulders.
    coats: ["Crimson"],
    // One calf after a long wait (musk ox: 8 months), slow to grow.
    breeding: { litter: 1, gestationDays: 4, matureDays: 8, cooldownDays: 8, juvenileScale: 0.4, young: "calf", youngPlural: "calves" },
    names: ["Grumble", "Thatch", "Mossback", "Porcini", "Cobble", "Burl", "Morel", "Toadstool", "Hob", "Hummock", "Bristle", "Crumpet", "Wart", "Nylon", "Shroom", "Stomp"],
  },
  "zoocraft:warped_gecko": {
    id: "zoocraft:warped_gecko",
    displayName: "Warped Gecko",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_warped_gecko",
    entityType: "zoocraft:warped_gecko",
    family: "warped_gecko",
    movementProfile: "terrestrial",
    habitatProfile: "terrarium",
    // Insect Rations (mealworms, from an Insect Hatchery) in an Insect Feeder (items list: "Insect Ration | Warped
    // Gecko, hedgehogs"); at night a stocked one lets out moths, which they hunt along the walls.
    dietTags: ["insect"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:insect_ration",
    observe: ["spot", "cling", "hunt", "call"],
    where: "Warped forests and the Lava Falls in the Nether, alone or in twos on the warped nylium and up the stems, glowing a dim blue-green. By day they hide in cracks; at dusk they call, a cluck and then a growl, and at night they hunt moths. Walk right up to one and it hisses and runs up the wall; hold an Insect Ration and it comes down to you",
    // Giant geckos live alone or in pairs, and two grown males fight: one male with a female or two, and their young.
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator. Walls to climb (clings: the wall measure, a
    // roof over it all, balance.gecko.wallFaces wall faces each), a hide each by day (a crack, or a Burrow Shelter),
    // an Insect Feeder (insectFeeder), asleep by day and up at night (nightLife: a nocturnal house turns it round),
    // one grown male (oneMale). Let out on warped nylium (homeGround).
    heat: true,
    clings: true,
    insectFeeder: true,
    nightLife: true,
    oneMale: true,
    // Its spots and eyes glow (entity_emissive_alpha): guests see it in the dark (animals/nightRules.js nocturnalLine).
    glows: true,
    homeGround: { id: "minecraft:warped_nylium", text: "on warped nylium" },
    // A male is broader in the head, his glow spots brighter and more of them (minecraft:mark_variant 1).
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // One coat: a deep teal hide with rows of glowing cyan spots, a pale belly and amber eyes.
    coats: ["Warped"],
    // Two eggs a clutch (giant geckos: two, a few times a year); hatchlings are a third of a grown one's length.
    breeding: { litter: 2, gestationDays: 3, matureDays: 6, cooldownDays: 4, juvenileScale: 0.35, young: "hatchling", youngPlural: "hatchlings" },
    names: ["Sticky", "Velcro", "Neon", "Glowtoe", "Nyx", "Lichen", "Cyan", "Gripper", "Teal", "Glint", "Murk", "Gloam", "Suki", "Kiwi", "Sprocket", "Gecky"],
  },
  "zoocraft:cinder_boar": {
    id: "zoocraft:cinder_boar",
    displayName: "Cinder Boar",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_cinder_boar",
    entityType: "zoocraft:cinder_boar",
    family: "cinder_boar",
    movementProfile: "terrestrial",
    habitatProfile: "sounder",
    // Ember Rations (items list "Ember Ration | Ember Fox, Cinder Boar") or Fungal Rations (a boar eats mostly roots,
    // fungi and plants), from a Basic Feeder. A crimson fungus held up draws one over (the hoglin's lure).
    dietTags: ["ember", "fungus"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:ember_ration",
    observe: ["spot", "root", "wallow", "scrub"],
    where: "Basalt deltas and the Nether wastes, in sounders of sows and their striped piglets rooting in the soul soil; old boars wander alone. In the heat of the day they wallow. Come near the piglets and their mother stands in your way, bristling; keep coming and she charges. Hold an Ember Ration and they let you close",
    // Wild boar sounders are 6 to 20 sows and their young; 2 to 8 fits an exhibit. Alone they're uneasy.
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator. Warm Ash to root in (ash), Thermal Mud to wallow
    // in (wallow; without it comfort stays under balance.boar.wallowComfortCap: the heat is too much for them), strong
    // walls (boarProof: the boar measure), one grown boar (oneMale: boars live apart and fight in the rut). Spec 5.3:
    // "Ash, thermal mud, strong barrier". Let out on the ground of its home biomes (homeGround).
    heat: true,
    ash: { minCells: 8 },
    wallow: { minCells: 4 },
    boarProof: true,
    oneMale: true,
    homeGround: { ids: ["minecraft:basalt", "minecraft:blackstone", "minecraft:netherrack", "minecraft:soul_soil"], text: "on basalt, blackstone, netherrack or soul soil" },
    // A boar is bigger, with tusks (minecraft:mark_variant 1).
    sexLook: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage", "dig"],
    // One coat: ash-grey bristles, a near-black crest tipped ember-orange, ember eyes; piglets striped buff.
    coats: ["Cinder"],
    // A litter of 3 to 5 (litterMax; wild boar: 3 to 12, 5 or 6 on average).
    breeding: { litter: 3, litterMax: 5, gestationDays: 3, matureDays: 5, cooldownDays: 6, juvenileScale: 0.35, young: "piglet", youngPlural: "piglets" },
    names: ["Snuffle", "Rooter", "Tusker", "Trotter", "Mudlark", "Grubber", "Hogan", "Tufa", "Huff", "Gristle", "Wallop", "Snorter", "Haggis", "Cobnut", "Burdock", "Mudpie"],
  },
  "zoocraft:soul_moth": {
    id: "zoocraft:soul_moth",
    displayName: "Soul Moth",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_soul_moth",
    entityType: "zoocraft:soul_moth",
    family: "soul_moth",
    movementProfile: "aerial",
    habitatProfile: "moth_house",
    flies: true, // steered through the air by animals/moth.js; the moth house is measured by floodAerial
    // Nectar Rations (butterfly houses feed a sugar solution) from a Nectar Feeder only (nectarFeeder); one held up
    // draws a wild one over to hover and sip from it.
    dietTags: ["nectar"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:nectar_ration",
    observe: ["spot", "orbit", "tumble", "sip"],
    where: "Soul sand valleys in the Nether, 2 to 4 together. At night they circle the soul fire burning on the soul soil; by day they rest flat against a basalt pillar or the valley wall, wings swept back. Hold a Nectar Ration near one and it flies over to hover and sip from it; walk right up to one at rest and it flashes the eyespots on its hindwings and flies off",
    // Moths aren't social: alone or many, gathering only at the light.
    social: { minGroup: 1, recommendedMax: 12, prefersCompany: false },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator. A roofed moth house (the profile), soul light
    // inside (soulLight: without one comfort stays under balance.moth.soulComfortCap), nectar from a Nectar Feeder
    // (nectarFeeder), at rest by day and flying at night (nightLife: a dark house turns it round; soul light counts as
    // dark, houseLight 10 where the Nocturnal Lamps give 7). Spec 5.3: "Enclosed airspace, soul lights, nectar". Let out
    // on the soul soil or soul sand of its valleys (homeGround).
    heat: true,
    soulLight: true,
    nectarFeeder: true,
    nightLife: true,
    houseLight: 10,
    // Its eyes, body rings and wing bands glow faint cyan (entity_emissive_alpha): guests see it in the dark.
    glows: true,
    homeGround: { ids: ["minecraft:soul_soil", "minecraft:soul_sand"], text: "on soul soil or soul sand" },
    // A male has broad feathery antennae and is a little smaller (minecraft:mark_variant 1).
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // One coat: pale blue wings with darker zigzag bands, a furry pale blue body, eyespots on the hindwings.
    coats: ["Soul"],
    // A clutch of 3 to 6 eggs (litterMax), laid only where host plants grow in the floor (hostPlants: the caterpillars
    // eat them, not from the feeder); they grow up in 5 park days, the last pupaDays as a pupa in the floor. The
    // caterpillar and the pupa are bones of their own drawn at the moth's scale: juvenileScale is the caterpillar's
    // length over the moth's span (9 units to 10, gen/moth.py).
    breeding: { litter: 3, litterMax: 6, gestationDays: 2, matureDays: 5, cooldownDays: 4, juvenileScale: 0.9, young: "caterpillar", youngPlural: "caterpillars", hostPlants: 4, pupaDays: 2 },
    names: ["Sphinx", "Candle", "Lantern", "Flit", "Ghostwing", "Soulwing", "Dusky", "Nocturne", "Pallid", "Azure", "Taper", "Gossamer", "Hawkmoth", "Silkie", "Moondust", "Willowisp"],
  },
  "zoocraft:quartz_beetle": {
    id: "zoocraft:quartz_beetle",
    displayName: "Quartz Beetle",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_quartz_beetle",
    entityType: "zoocraft:quartz_beetle",
    family: "quartz_beetle",
    movementProfile: "terrestrial",
    habitatProfile: "cave",
    // Mineral Pellets (a rhinoceros beetle eats fruit and sap; a Nether one, minerals) from a Basic Feeder. A nether
    // quartz held up draws one over too (balance.beetle.bait).
    dietTags: ["mineral"],
    carrierProfile: "thermal",
    baitItem: "zoocraft:mineral_pellets",
    observe: ["spot", "burrow", "wrestle", "hiss"],
    where: "The Nether wastes and basalt deltas, where nether quartz is commonest, 1 to 3 together. By day they lie buried in netherrack, soul soil, soul sand or gravel, only the quartz-plated back showing; at night they come out to walk and eat, and two males that meet wrestle. Walk right up to one on its feet and it rears and hisses; hold a Mineral Pellet or a nether quartz and it comes over",
    // Beetles aren't social: alone or many.
    social: { minGroup: 1, recommendedMax: 8, prefersCompany: false },
    // A Nether animal (spec section 10): a fuelled Thermal Regulator. A cave (cover: a roof over nearly all of the
    // floor), Mineral Substrate to bury itself in by day (substrate: without it comfort stays under
    // balance.beetle.bedComfortCap), buried by day and out at night (nightLife: a dark cave turns it round). Spec 5.3:
    // "Heated cave, mineral bed". Let out on the ground it buries itself in (homeGround).
    heat: true,
    cover: { minFraction: 0.9, why: "a cave roof" },
    substrate: { minCells: 6 },
    nightLife: true,
    homeGround: { ids: ["minecraft:netherrack", "minecraft:soul_soil", "minecraft:soul_sand", "minecraft:gravel"], text: "on netherrack, soul soil, soul sand or gravel" },
    // A male has the long horn on his pronotum over a short head horn (its length his own, zoocraft:horn); a female
    // has none and is a little smaller (minecraft:mark_variant 1).
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "dig"],
    // One coat: near-black, the wing covers plated with milky quartz.
    coats: ["Quartz"],
    // 2 to 4 grubs (litterMax), laid only in Mineral Substrate enough (substrate: the grubs live and feed in it, not
    // from the feeder); they grow up in 6 park days, the last pupaDays as a pupa in it. The grub is bones of its own
    // drawn at the beetle's scale: juvenileScale is its length over the beetle's (gen/beetle.py).
    breeding: { litter: 2, litterMax: 4, gestationDays: 2, matureDays: 6, cooldownDays: 4, juvenileScale: 0.8, young: "grub", youngPlural: "grubs", substrate: 6, pupaDays: 2 },
    names: ["Quartzy", "Hercules", "Rhino", "Atlas", "Goliath", "Chip", "Shard", "Scarab", "Dynamo", "Crag", "Gneiss", "Mica", "Beryl", "Obelisk", "Tank", "Prism"],
  },
  "zoocraft:end_hopper": {
    id: "zoocraft:end_hopper",
    displayName: "End Hopper",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_end_hopper",
    entityType: "zoocraft:end_hopper",
    family: "end_hopper",
    movementProfile: "terrestrial",
    habitatProfile: "hopper",
    // Chorus Browse (a springhare eats roots, stems, leaves and seeds; an End one, chorus) from a Basic Feeder; held up,
    // one draws it over to sniff it.
    dietTags: ["chorus"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "leap", "zigzag", "listen"],
    where: "The end stone of the outer End islands, 1 to 3 together, out and about at any hour (the End has no day or night). They leap up onto blocks and across the ground, never out over the void. Come close in Survival without sneaking and one gets away in zigzag leaps; hold Chorus Browse and it comes to sniff it",
    // Springhares forage in groups of up to nine without fighting, but don't need company.
    social: { minGroup: 1, recommendedMax: 8, prefersCompany: false },
    // End ground (spec 5.4 "End ground | vanilla end stone"); a roof, as it leaps 3 blocks high (hops: the jump
    // measure's flood through the air mustn't lead out); Landing Pads to leap between (pads: without them comfort
    // stays under balance.hopper.padComfortCap). Spec 5.4: "Jump clearance, roof, landing pads".
    endGround: { minCells: 8 },
    hops: true,
    pads: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Pale (end-stone cream, the common one), 1 Purpur (lilac grey).
    coats: ["Pale", "Purpur"],
    // One pup at a time (a springhare's single young), grown in 4 park days; it keeps to the floor and doesn't leap.
    breeding: { litter: 1, gestationDays: 3, matureDays: 4, cooldownDays: 4, juvenileScale: 0.5, young: "pup", youngPlural: "pups" },
    names: ["Pogo", "Boing", "Kip", "Skip", "Jinx", "Ricochet", "Lark", "Pounce", "Springer", "Sprig", "Tansy", "Cricket", "Zest", "Wink", "Dart", "Hopscotch"],
  },
  "zoocraft:shimmer_snail": {
    id: "zoocraft:shimmer_snail",
    displayName: "Shimmer Snail",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_shimmer_snail",
    entityType: "zoocraft:shimmer_snail",
    family: "shimmer_snail",
    movementProfile: "terrestrial",
    habitatProfile: "snail",
    // Mineral Pellets from a Basic Feeder (a rock snail rasps the rock itself; an End one, minerals); held up, one draws
    // it over to reach up at it. It also grazes the Mineral Substrate.
    dietTags: ["mineral"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:mineral_pellets",
    observe: ["spot", "trail", "withdraw", "seal"],
    where: "The end stone of the outer End islands, 2 to 4 together, out at any hour (the End has no day or night). They crawl slowly over the end stone grazing it, leave a glowing trail that fades, and rest sealed in their shells in crevices at the foot of rocks. Come close in Survival without sneaking and one pulls into its shell; hold Mineral Pellets and it crawls over to you",
    // Snails aren't social, but they rest near each other and follow each other's trails.
    social: { minGroup: 1, recommendedMax: 8, prefersCompany: false },
    // End ground (spec 5.4 "End ground | vanilla end stone"); shade (cover: a roof or leaves over a quarter of the
    // floor); a crevice each to rest in (crevices: without them comfort stays under balance.snail.creviceComfortCap);
    // Mineral Substrate to graze (mineralBed: without it comfort stays under balance.snail.bedComfortCap). Spec 5.4:
    // "Mineral bed, shade, crevices".
    endGround: { minCells: 4 },
    cover: { minFraction: 0.25, why: "shade" },
    crevices: true,
    mineralBed: { minCells: 4 },
    // No sexes: any two grown ones that aren't related can pair, and one of them lays the eggs.
    hermaphrodite: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Pearl (ivory, a pearl-white shell, the common one), 1 Opal (pale lilac, a
    // lavender shell).
    coats: ["Pearl", "Opal"],
    // 2 or 3 eggs laid in the Mineral Substrate (eggBed: 4 or more blocks of it in the floor); the hatchlings glow, leave
    // a fainter trail and crawl after their parent, grown in 4 park days.
    breeding: { litter: 2, litterMax: 3, gestationDays: 2, matureDays: 4, cooldownDays: 4, juvenileScale: 0.35, young: "hatchling", youngPlural: "hatchlings", eggBed: 4 },
    names: ["Spiral", "Twirl", "Gleam", "Slick", "Dewdrop", "Lustre", "Swirl", "Whorl", "Trickle", "Sheen", "Coil", "Shelly", "Escargot", "Nacre", "Helix", "Glisten"],
  },
  "zoocraft:obsidian_crab": {
    id: "zoocraft:obsidian_crab",
    displayName: "Obsidian Crab",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_obsidian_crab",
    entityType: "zoocraft:obsidian_crab",
    family: "obsidian_crab",
    movementProfile: "terrestrial",
    habitatProfile: "crab",
    // Mineral Pellets from a Mineral Feeder, and nothing else (a coconut crab eats other crabs' moulted shells for their
    // minerals; an End one, the zoo's pellets). Held up, they draw one from far off: it smells them.
    dietTags: ["mineral"],
    mineralFeeder: true,
    carrierProfile: "stabilized",
    baitItem: "zoocraft:mineral_pellets",
    observe: ["spot", "scrape", "dig", "claws"],
    where: "The end stone of the outer End islands, alone or 2 together, out at any hour (the End has no day or night). They walk sideways over the end stone, scrape minerals off the rock with their claws, and rest dug in backwards at a rock's foot with only the eyes and the big claw showing. Come at one in Survival without sneaking and it rears with its claws up, then bolts and digs in; hold Mineral Pellets and it walks over to you",
    // Coconut crabs live alone, and a big one eats a small one: 1 to 4 together, keeping an exhibit of their own.
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // End ground (spec 5.4 "End ground | vanilla end stone"); a rocky cave (cover: a roof over nearly all of the floor;
    // rockFaces: rock to scrape, without it comfort stays under balance.crab.rockComfortCap); Mineral Substrate to dig
    // its burrow in (burrows: without it comfort stays under balance.crab.burrowComfortCap); a Mineral Feeder.
    endGround: { minCells: 4 },
    cover: { minFraction: 0.9, why: "a cave roof" },
    rockFaces: { first: 4, extra: 2 },
    burrows: { perCrab: 2, minCells: 4 },
    // A male is bigger, his shell 144 mm across to her 101 (Christmas Island): she is 0.7 of him (minecraft:mark_variant
    // 1 a male).
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "dig"],
    // Coat comes from minecraft:variant: 0 Obsidian (glossy black, a violet sheen, the common one), 1 Crying (flecked
    // with glowing violet, like crying obsidian).
    coats: ["Obsidian", "Crying"],
    // She carries 2 or 3 eggs under her tail (carried) 3 park days; the crablets come out from under her, each with a
    // little spiral shell on its back (as young coconut crabs carry snail shells), grown in 5 park days. A crablet is
    // half a female's size (juvenileScale is of a female's, as a gorilla's: 0.35 of a male).
    breeding: { litter: 2, litterMax: 3, gestationDays: 3, matureDays: 5, cooldownDays: 4, juvenileScale: 0.5, young: "crablet", youngPlural: "crablets", carried: true },
    names: ["Pincer", "Clacker", "Snips", "Nipper", "Scuttle", "Onyx", "Jet", "Ebony", "Grit", "Crusher", "Sidle", "Rubble", "Knuckles", "Chisel", "Barnacle", "Tephra"],
  },
  "zoocraft:chorus_moth": {
    id: "zoocraft:chorus_moth",
    displayName: "Chorus Moth",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_chorus_moth",
    entityType: "zoocraft:chorus_moth",
    family: "chorus_moth",
    movementProfile: "aerial",
    habitatProfile: "moth_house",
    flies: true, // steered through the air by animals/chorusMoth.js; the moth house is measured by floodAerial
    // Nectar Rations from a Nectar Feeder only (nectarFeeder; 2 sugar and a chorus fruit make 2): chorus nectar. One
    // held up draws a wild one over to hover and sip from it.
    dietTags: ["nectar"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:nectar_ration",
    observe: ["spot", "flower", "warmup", "sip"],
    where: "The outer End islands where chorus grows, 2 to 4 together, out in bouts at any hour (the End has no day or night). Out, they work from chorus flower to chorus flower, hovering at each to sip; between, they rest on an end stone face with the wings folded into an arrowhead, and each shivers its wings warm before it flies. Hold a Nectar Ration near one and it flies over to sip from it; walk right up to one at rest and it gives a quick shiver and flies off",
    // Moths aren't social: alone or many.
    social: { minGroup: 1, recommendedMax: 12, prefersCompany: false },
    // A roofed moth house (the profile), chorus flowers inside, one for each and 2 at least (chorusFlowers: without
    // them comfort stays under balance.chorusMoth.flowerComfortCap), nectar from a Nectar Feeder (nectarFeeder), low
    // light (lowLight: no daylight and nothing brighter than the Nocturnal Lamps; in a bright house it flies only at night
    // and comfort stays under balance.chorusMoth.dimComfortCap), End ground (spec 5.4 "vanilla end stone").
    chorusFlowers: { perMoth: 1, min: 2 },
    nectarFeeder: true,
    lowLight: true,
    endGround: { minCells: 4 },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Chorus (deep purple forewings with lilac-pink bars, the common one), 1 Popped
    // (pale lilac, like popped chorus fruit). The sexes look alike.
    coats: ["Chorus", "Popped"],
    // A clutch of 3 to 6 eggs (litterMax), laid only where chorus stands on the floor (hostPlants, hostText: the
    // caterpillars eat it, not from the feeder); they grow up in 5 park days, the last pupaDays as a pupa in the floor.
    // The caterpillar and the pupa are bones of their own drawn at the moth's scale: juvenileScale is the caterpillar's
    // length over the moth's span (7 units to 8, gen/chorusmoth.py).
    breeding: { litter: 3, litterMax: 6, gestationDays: 2, matureDays: 5, cooldownDays: 4, juvenileScale: 0.875, young: "caterpillar", youngPlural: "caterpillars", hostPlants: 4, hostText: "chorus plants or flowers standing on the floor", pupaDays: 2 },
    names: ["Elpenor", "Plume", "Hoverwing", "Sipper", "Corolla", "Heather", "Wisteria", "Foxglove", "Popcorn", "Phlox", "Verbena", "Hum", "Bloom", "Purpura", "Willowherb", "Fuchsia"],
  },
  "zoocraft:starback_tortoise": {
    id: "zoocraft:starback_tortoise",
    displayName: "Starback Tortoise",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_starback_tortoise",
    entityType: "zoocraft:starback_tortoise",
    family: "starback_tortoise",
    movementProfile: "terrestrial",
    habitatProfile: "tortoise",
    // Chorus Browse from a Basic Feeder (an Indian star tortoise grazes grasses and herbs and eats fruit and flowers; an
    // End one, chorus), and the chorus standing on the floor, browsed at its foot. Held up (or a chorus fruit), one draws
    // it over to nibble at it.
    dietTags: ["chorus"],
    carrierProfile: "stabilized",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "warm", "chorus", "withdraw"],
    where: "Among the chorus of the outer End islands, alone or 2 together, keeping to bouts at any hour (the End has no day or night). They rest under cover (a chorus plant, a rock), come out to bask with the legs and neck stretched out till they're warm, and browse the chorus at its foot. Come close in Survival without sneaking and one pulls into its shell with a hiss; hold Chorus Browse or a chorus fruit and it plods over to nibble at it",
    // Solitary, but the males seldom or never fight: 1 to 6 together, keeping an exhibit of their own.
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // End vegetation (endPlants: chorus standing on the floor, 2 for each and 3 at least), a warm pad (warmPads: a Warm
    // Pad for every 2, 1 at least), a large retreat (retreat: a low roof over 2 blocks of floor for each, 4 at least);
    // without any of them comfort stays under its balance.starback cap. End ground (spec 5.4 "vanilla end stone"). She
    // nests in Mineral Substrate (substrateNest: it's counted).
    endPlants: { perTortoise: 2, min: 3 },
    warmPads: { perPad: 2, min: 1 },
    retreat: { perTortoise: 2, min: 4 },
    substrateNest: true,
    endGround: { minCells: 4 },
    // A male is 0.64 of a female (17.5 cm to her 27.5), his tail longer and thicker (minecraft:mark_variant 1 a male).
    sexLook: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // One coat (minecraft:variant 0), Starback: a black, high-domed shell, a yellow star on each scute, the stars'
    // centres glowing faintly.
    coats: ["Starback"],
    // She digs a nest in the Mineral Substrate with her hind feet (nestDig; only with eggBed blocks of it in the floor),
    // lays 2 to 4 eggs, fills it and pats it flat; they hatch in 3 park days and dig out, grown in 6. A hatchling is 0.3
    // of a female (a real one 0.13, too small to see), black with yellow blotches, no stars yet.
    breeding: { litter: 2, litterMax: 4, gestationDays: 3, matureDays: 6, cooldownDays: 6, juvenileScale: 0.3, young: "hatchling", youngPlural: "hatchlings", eggBed: 2, nestDig: true },
    names: ["Twinkle", "Polaris", "Vega", "Sirius", "Astra", "Galileo", "Dome", "Plod", "Ponder", "Meteor", "Celeste", "Starla", "Mosaic", "Dipper", "Shelby", "Kepler"],
  },
  // Fish (0.1.119, module 6, Austin's idea 9: "Add fish species so zoos can have an aquarium. Players can gather fish in
  // large numbers, and fish need less watching than the animals"): zoo copies of the vanilla fish (the game's own models
  // and skins, as the Zoo Rabbit), kept as SCHOOLS (animals/schoolRules.js): one record a species a tank, `count` fish in
  // it (species.school.max at most), at most species.school.shown of them shown as mobs. Caught in bulk with a Water
  // Transport Tank (carrier profile `aquatic`: the one and its kind within BALANCE.aquarium.catchRange), no bait (fish
  // can't be fed), no Field Journal task but spotting one, no breeding, never ill. They eat Fish Flakes from an Aquarium
  // Feeder (species.aquariumFeeder) and nothing else: rationUnitsPerParkDay is a FISH's share (an eighth of a unit).
  // Their space is the water (the `aquarium` profile). All four share the Reef community (with the two squid, 0.1.121).
  // `bucket`: a water bucket used on a shown zoo fish takes one out in that bucket (0.1.121).
  "zoocraft:zoo_cod": {
    id: "zoocraft:zoo_cod",
    displayName: "Cod",
    plural: "Cod",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:cod",
    bucket: "minecraft:cod_bucket",
    entityType: "zoocraft:zoo_cod",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes", // what they eat (never used as bait: a school is scooped up, not coaxed)
    aquariumFeeder: true,
    school: { max: 16, shown: 6 },
    observe: ["spot"],
    where: "Cold and lukewarm oceans, in schools",
    social: { minGroup: 2, recommendedMax: 16, prefersCompany: true },
    rationUnitsPerParkDay: 0.125,
    enrichmentTags: [],
    coats: ["Silver"],
    names: ["Shoal", "Drift", "Current", "Tide", "Ripple", "Eddy", "Swell", "Surge", "Flow", "Wake", "Gale", "Breaker", "Spray", "Foam", "Crest", "Trough"],
  },
  "zoocraft:zoo_salmon": {
    id: "zoocraft:zoo_salmon",
    displayName: "Salmon",
    plural: "Salmon",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:salmon",
    bucket: "minecraft:salmon_bucket",
    entityType: "zoocraft:zoo_salmon",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 16, shown: 6 },
    observe: ["spot"],
    where: "Cold and frozen oceans and rivers, in runs",
    social: { minGroup: 2, recommendedMax: 16, prefersCompany: true },
    rationUnitsPerParkDay: 0.125,
    enrichmentTags: [],
    coats: ["Red"],
    names: ["Run", "Leap", "Rapids", "Torrent", "Cascade", "Brook", "Spring", "Riffle", "Chute", "Falls", "Stream", "Creek", "Burn", "Beck", "Ford", "Weir"],
  },
  "zoocraft:zoo_tropical_fish": {
    id: "zoocraft:zoo_tropical_fish",
    displayName: "Tropical Fish",
    plural: "Tropical Fish",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:tropicalfish",
    bucket: "minecraft:tropical_fish_bucket", // the bucket's fish takes a look of its own (a script-made bucket carries none)
    entityType: "zoocraft:zoo_tropical_fish",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 16, shown: 6 },
    // A school keeps the look of the fish it was caught from (the body shape, the pattern and the two colours: record
    // `look`, animals/schoolRules.js tropicalLook), shown with zoocraft:shape_N, pattern_N, base_N and pat_N.
    looks: true,
    observe: ["spot"],
    where: "Warm and lukewarm oceans, over the coral",
    social: { minGroup: 2, recommendedMax: 16, prefersCompany: true },
    rationUnitsPerParkDay: 0.125,
    enrichmentTags: [],
    coats: ["Reef"],
    names: ["Coral", "Lagoon", "Reef", "Atoll", "Anemone", "Kelp", "Pearl", "Shell", "Sunburst", "Rainbow", "Glimmer", "Dapple", "Paisley", "Tango", "Bubble", "Sparkle"],
  },
  "zoocraft:zoo_pufferfish": {
    id: "zoocraft:zoo_pufferfish",
    displayName: "Pufferfish",
    plural: "Pufferfish",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:pufferfish",
    bucket: "minecraft:pufferfish_bucket",
    entityType: "zoocraft:zoo_pufferfish",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 16, shown: 6 },
    observe: ["spot"],
    where: "Warm and lukewarm oceans. Keep back: a puffed one stings",
    social: { minGroup: 2, recommendedMax: 16, prefersCompany: true },
    rationUnitsPerParkDay: 0.125,
    enrichmentTags: [],
    coats: ["Spiny"],
    names: ["Puff", "Balloon", "Bloat", "Prickle", "Spike", "Globe", "Button", "Pip", "Bulge", "Quill", "Burr", "Pincushion", "Marble", "Bobble", "Blimp", "Needle"],
  },
  // The squid (0.1.121): zoo copies of the vanilla squid and glow squid (gen121/squid121.py), kept as schools like the
  // fish but bigger (8 a school, 4 shown). No bucket: the game's buckets hold fish only.
  "zoocraft:zoo_squid": {
    id: "zoocraft:zoo_squid",
    displayName: "Squid",
    plural: "Squid",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:squid",
    entityType: "zoocraft:zoo_squid",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 8, shown: 4 },
    observe: ["spot"],
    where: "Oceans and rivers, in small groups",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    rationUnitsPerParkDay: 0.25,
    enrichmentTags: [],
    coats: ["Blue"],
    names: ["Ink", "Inky", "Blot", "Squirt", "Tentacle", "Kraken", "Calamari", "Siphon", "Sucker", "Mantle", "Cuttle", "Splotch", "Nib", "Sepia", "Noodle", "Wiggle"],
  },
  "zoocraft:zoo_glow_squid": {
    id: "zoocraft:zoo_glow_squid",
    displayName: "Glow Squid",
    plural: "Glow Squid",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:glow_squid",
    entityType: "zoocraft:zoo_glow_squid",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 8, shown: 4 },
    observe: ["spot"],
    where: "Dark water deep underground, in small groups",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    rationUnitsPerParkDay: 0.25,
    enrichmentTags: [],
    coats: ["Teal"],
    names: ["Beacon", "Firefly", "Shine", "Radiant", "Flash", "Luster", "Dawn", "Pulse", "Starlight", "Torch", "Opal", "Lumi", "Lamp", "Fathom", "Nightlight", "Phosphor"],
  },
  // The Whale Shark (0.1.124, module 6b part 1; Austin 2026-10-27: "whale sharks ... should be" among the sharks, then
  // "whale sharks are passive"; research/trench_plan.md, trench_facts.md): the first BIG FISH (species.bigFish): a single
  // named animal in a giant tank, not a school, caught one at a time in the Large Water Tank (carrier `marine`, Marine
  // Husbandry research) with Fish Flakes held out; it filter-feeds Fish Flakes from the Aquarium Feeder (8 units a park
  // day: it is 12 m long), never breeds, never falls ill in a tank (as the schools), and is harmless. Found near the
  // surface of warm and lukewarm deep oceans, alone.
  "zoocraft:whale_shark": {
    id: "zoocraft:whale_shark",
    displayName: "Whale Shark",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_whale_shark",
    entityType: "zoocraft:whale_shark",
    movementProfile: "aquatic",
    habitatProfile: "giant_tank",
    dietTags: ["flakes"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    bigFish: true,
    observe: ["spot", "gulp"],
    where: "Near the surface of warm and lukewarm deep oceans, alone: cruising slowly, every so often slowing right down with its huge mouth wide open to filter the water. Harmless, and much bigger than anything else in the sea",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    rationUnitsPerParkDay: 8,
    enrichmentTags: [],
    coats: ["Spotted"],
    names: ["Wanderer", "Gentle", "Luna", "Bruno", "Marina", "Pacific", "Grande", "Checkers", "Plankton", "Harbor", "Juno", "Voyager", "Moonlit", "Odyssey", "Sapphire", "Titan"],
  },
  // The Great White (0.1.125, module 6b part 2; Austin 2026-10-27: "great whites, hammerheads ... They should be
  // dangerous"; research/trench_plan.md "Danger", trench_facts.md): a dangerous big fish (`shark`): the predators'
  // warn-then-charge danger with water moves (animals/shark.js: it circles a swimmer in its tank, then rushes and bites, 3
  // hearts and a shove), no Holding Dens (keepers fill the Aquarium Feeder from the bank and never go in), Fish Rations
  // from the Aquarium Feeder, caught in the Large Water Tank only while it eats a Fish Ration thrown into the water. It
  // surges to the surface now and then (the breach). Alone in deep oceans; a wild one hunts swimmers.
  "zoocraft:great_white": {
    id: "zoocraft:great_white",
    displayName: "Great White Shark",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_great_white",
    entityType: "zoocraft:great_white",
    movementProfile: "aquatic",
    habitatProfile: "large_tank",
    dietTags: ["fish"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_ration",
    aquariumFeeder: true,
    bigFish: true,
    shark: true,
    dangerous: true,
    dangerMoves: "circle anyone swimming in their tank, then rush and bite",
    observe: ["spot", "breach"],
    where: "The upper water of the Deep Trench (clear teal water over its abyss), alone. Very dangerous: a wild one goes for anyone swimming near it. Throw a Fish Ration into the water near one: while it eats it's calm, and the Large Water Tank can take it",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    rationUnitsPerParkDay: 3,
    enrichmentTags: [],
    coats: ["Grey"],
    sounds: { warn: "mob.dolphin.idle_water", warnPitch: 0.4, swipe: "mob.ravager.bite", swipePitch: 0.7 },
    names: ["Jaws", "Carcharo", "Nero", "Rip", "Bianca", "Razor", "Tempest", "Mako", "Bruce", "Ivory", "Whitecap", "Saltwater", "Torpedo", "Keel", "Undertow", "Pale"],
  },
  // The Hammerhead (0.1.125): the same shark rules, in a smaller tank and happier in company (young hammerheads school);
  // it sweeps the floor with its wide head now and then. Ones and threes in warm and lukewarm oceans.
  "zoocraft:hammerhead": {
    id: "zoocraft:hammerhead",
    displayName: "Hammerhead Shark",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_hammerhead",
    entityType: "zoocraft:hammerhead",
    movementProfile: "aquatic",
    habitatProfile: "large_tank",
    dietTags: ["fish"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_ration",
    aquariumFeeder: true,
    bigFish: true,
    shark: true,
    dangerous: true,
    dangerMoves: "circle anyone swimming in their tank, then rush and bite",
    observe: ["spot", "sweep"],
    where: "Warm and lukewarm oceans, alone or in small groups, in the upper water. Dangerous: a wild one goes for anyone swimming near it. Throw a Fish Ration into the water near one: while it eats it's calm, and the Large Water Tank can take it",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: [],
    coats: ["Bronze"],
    sounds: { warn: "mob.dolphin.idle_water", warnPitch: 0.5, swipe: "mob.ravager.bite", swipePitch: 0.85 },
    names: ["Anvil", "Mallet", "Scallop", "Sledge", "Cocos", "Galapagos", "Bronze", "Sphyrna", "Lewini", "Tacker", "Wedge", "Hatchet", "Banner", "Sextant", "Compass", "Lookout"],
  },
  // The Goblin Shark (0.1.126, module 6b part 3; Austin 2026-10-27: goblin sharks among the dangerous ones;
  // research/trench_plan.md, trench_facts.md): a shark of the deep, slow (sharkPace: half the others' steps, it drifts up
  // to a swimmer) with the same danger (the circle, the rush, the bite), caught the same way (a thrown Fish Ration, the
  // Large Water Tank). It lives in the dark: a trench tank (lowLight: no daylight on the water, nothing brighter than the
  // Nocturnal Lamps, measured as a nocturnal house is; in daylight comfort can't rise above the dim cap). Its show is the
  // jaw lunge (act 6: the jaws slung forward to the snout tip). Alone on the floor of deep oceans.
  "zoocraft:goblin_shark": {
    id: "zoocraft:goblin_shark",
    displayName: "Goblin Shark",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_goblin_shark",
    entityType: "zoocraft:goblin_shark",
    movementProfile: "aquatic",
    habitatProfile: "trench_tank",
    dietTags: ["fish"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_ration",
    aquariumFeeder: true,
    bigFish: true,
    shark: true,
    sharkPace: 0.5,
    lowLight: true,
    dangerous: true,
    dangerMoves: "drift up to anyone swimming in their tank, then shoot their jaws out and bite",
    observe: ["spot", "lunge"],
    where: "The dark bottom of the Deep Trench's abyss and down its canyons, alone, drifting slowly. Dangerous: a wild one comes for anyone swimming near it, jaws first. Throw a Fish Ration into the water near one: while it eats it's calm, and the Large Water Tank can take it",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    rationUnitsPerParkDay: 2,
    enrichmentTags: [],
    coats: ["Pink"],
    sounds: { warn: "mob.dolphin.idle_water", warnPitch: 0.3, swipe: "mob.ravager.bite", swipePitch: 0.5 },
    names: ["Mitsu", "Owston", "Blade", "Rosy", "Pinky", "Slingshot", "Phantom", "Canyon", "Trench", "Abyss", "Sakura", "Ghost", "Stiletto", "Deepwater", "Ravine", "Slope"],
  },
  // The Anglerfish (0.1.126; trench_facts.md: the humpback anglerfish, drawn "giant" at 1 m since the real one is 15 cm):
  // a harmless big fish (one named animal, the Large Water Tank, Fish Rations from the Aquarium Feeder) that hangs in the
  // dark of a small trench tank (lowLight) and barely moves. Its lure glows (the client's emissive bulb); now and then the
  // mouth gapes and the rod twitches (zoocraft:luring, the entity's timers), which the journal's "lure" task sees. Alone
  // on the floor of deep oceans.
  "zoocraft:anglerfish": {
    id: "zoocraft:anglerfish",
    displayName: "Anglerfish",
    plural: "Anglerfish",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_anglerfish",
    entityType: "zoocraft:anglerfish",
    movementProfile: "aquatic",
    habitatProfile: "dark_tank",
    dietTags: ["fish"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_ration",
    aquariumFeeder: true,
    bigFish: true,
    lure: true,
    lowLight: true,
    glows: true,
    observe: ["spot", "lure"],
    where: "The dark bottom of the Deep Trench's abyss and down its canyons, alone, hanging in the water with its lure lit. Harmless, and so slow the Large Water Tank takes it as it is",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    rationUnitsPerParkDay: 1,
    enrichmentTags: [],
    coats: ["Black"],
    names: ["Bulb", "Gloom", "Pitch", "Starlet", "Lampy", "Luminara", "Deeplight", "Lanterna", "Glowworm", "Lightkeeper", "Photon", "Nightfall", "Lucent", "Nightglow", "Fathoms", "Blackwater"],
  },
  // The Giant Stingray (0.1.127, module 6b part 4; Austin 2026-10-27: "giant stingrays ... at the bottom";
  // research/trench_plan.md, trench_facts.md §5c: drawn as the smooth stingray, the largest stingray of the sea, 2 m across
  // and 4 m long with its tail): a harmless big fish of the sea floor (one named animal, the Large Water Tank, Fish Rations
  // from the Aquarium Feeder). It wants a sand floor in its tank (species.sandBed: sand under half the water, 32 blocks at
  // least; animals/rayRules.js), and every so often it glides down and buries itself in the sand, only its eyes showing,
  // then bursts out, early when someone swims close (animals/ray.js). Alone on the sandy floor of warm and lukewarm oceans.
  "zoocraft:giant_stingray": {
    id: "zoocraft:giant_stingray",
    displayName: "Giant Stingray",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_giant_stingray",
    entityType: "zoocraft:giant_stingray",
    movementProfile: "aquatic",
    habitatProfile: "ray_tank",
    dietTags: ["fish"],
    carrierProfile: "marine",
    baitItem: "zoocraft:fish_ration",
    aquariumFeeder: true,
    bigFish: true,
    sandBed: { minFraction: 0.5, minCells: 32 },
    observe: ["spot", "bury"],
    where: "The sandy floor of warm and lukewarm oceans, alone: gliding low over the sand, or buried in it with only its eyes showing. Harmless (the spine on its tail is only for defence), and the Large Water Tank takes it as it is",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    rationUnitsPerParkDay: 2,
    enrichmentTags: [],
    coats: ["Grey-brown"],
    names: ["Sandy", "Dune", "Silt", "Glider", "Kite", "Seabed", "Flatty", "Brevi", "Whiptail", "Hideaway", "Sunken", "Dasy", "Shallows", "Seafloor", "Skate", "Mudflat"],
  },
  // The Jellyfish (0.1.127; Austin 2026-10-27: "some big glowing beautiful jelly fish", "keep them harmless", "they should
  // drift very slowly"; trench_facts.md §9: a lion's mane sized bell, 1.25 m here, glowing like the deep sea's crown
  // jellies): a school (the module 6 record, the Water Transport Tank, Fish Flakes from the Aquarium Feeder) drifting at a
  // tenth of a fish's speed, pulsing its bell. Its shown jellies take its three colours by turns (a school's coats,
  // animals.js spawnFish); swim close to one and it flashes a ring of light round its bell (species.flashes,
  // animals/jelly.js), as the Atolla jelly does. Mid-water in deep oceans, in small groups.
  "zoocraft:jellyfish": {
    id: "zoocraft:jellyfish",
    displayName: "Jellyfish",
    plural: "Jellyfish",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_jellyfish",
    entityType: "zoocraft:jellyfish",
    movementProfile: "aquatic",
    habitatProfile: "jelly_tank",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 8, shown: 4 },
    flashes: true,
    glows: true,
    observe: ["spot", "flash"],
    where: "Drifting through the Deep Trench, from down in its abyss up to the upper water, in small groups, glowing: crimson, sapphire and violet bells that pulse slowly as they drift. Harmless, and they never swim fast; swim close and one flashes a ring of light round its bell",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    rationUnitsPerParkDay: 0.25,
    enrichmentTags: [],
    coats: ["Crimson", "Sapphire", "Violet"],
    names: ["Medusa", "Billow", "Drifter", "Crown", "Pulsar", "Aurelia", "Cyanea", "Atolla", "Ribbon", "Bellflower", "Parasol", "Velella", "Chrysaora", "Mastigias", "Jellybean", "Moonbell"],
  },
  // The Catfish (0.1.129, module 6b part 5; idea 14 "catfish"; research/trench_plan.md "0.1.129", trench_facts.md §7: the
  // channel catfish, 0.6 m): a school (the module 6 record, the Water Transport Tank, Fish Flakes from the Aquarium
  // Feeder) of the river bottom. Every so often one goes down to the floor and creeps along it nose down, sweeping its
  // whiskers side to side to taste the bottom (species.bottomFeeder, animals/catfish.js), then swims up again. Harmless.
  // 2 to 4 together near the bottom of rivers, swamps and mangrove swamps.
  "zoocraft:catfish": {
    id: "zoocraft:catfish",
    displayName: "Catfish",
    plural: "Catfish",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_catfish",
    entityType: "zoocraft:catfish",
    movementProfile: "aquatic",
    habitatProfile: "aquarium",
    dietTags: ["flakes"],
    carrierProfile: "aquatic",
    baitItem: "zoocraft:fish_flakes",
    aquariumFeeder: true,
    school: { max: 8, shown: 4 },
    bottomFeeder: true,
    observe: ["spot", "whiskers"],
    where: "Near the bottom of rivers, swamps and mangrove swamps, 2 to 4 together: cruising slowly, or creeping along the floor nose down, sweeping their whiskers over it to taste for food. Harmless",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    rationUnitsPerParkDay: 0.25,
    enrichmentTags: [],
    coats: ["Channel"],
    names: ["Whiskers", "Barbel", "Mudcat", "Bayou", "Gumbo", "Flathead", "Bullhead", "Murky", "Rivercat", "Ozark", "Channel", "Silty", "Dredge", "Catty", "Muddy", "Sandbar"],
  },
  // The Manatee (0.1.129; idea 14 "manatees"; trench_facts.md §8: the West Indian manatee, 3 m): one named animal in a
  // lagoon (the `lagoon` profile: its space is the water), a mammal of the water (species.aquaticMammal): it breeds (one
  // calf, born in the water, so a lagoon needs no sheltered corner), travels in the Large Water Tank (Marine Husbandry),
  // coaxed in with a Leafy Ration, and is harmless. Leafy Rations from an Aquarium Feeder over the water (zoos float
  // lettuce for them), and the seagrass and kelp growing in its water (species.seagrass: perAnimal columns of water with
  // seagrass or kelp in them for each, a calf half; with enough, `share` of its food comes from grazing). Every 3 to 5
  // minutes it rises and holds its nostrils just out of the water to breathe; between breaths it grazes the seagrass,
  // head down (animals/manatee.js). A guest favourite (species.favourite: its exhibit's view counts a quarter more). Alone
  // or two together in rivers, mangrove swamps and the shallows of warm and lukewarm oceans.
  "zoocraft:manatee": {
    id: "zoocraft:manatee",
    displayName: "Manatee",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_manatee",
    entityType: "zoocraft:manatee",
    movementProfile: "aquatic",
    habitatProfile: "lagoon",
    dietTags: ["leafy"],
    carrierProfile: "marine",
    baitItem: "zoocraft:leafy_ration",
    aquariumFeeder: true,
    aquaticMammal: true,
    seagrass: { perAnimal: 6, share: 0.4 },
    favourite: true,
    observe: ["spot", "breathe"],
    where: "Rivers, mangrove swamps and the shallows of warm and lukewarm oceans, alone or two together: grazing the seagrass on the bottom, and every few minutes rising to put their nostrils out of the water to breathe. Harmless and gentle",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    rationUnitsPerParkDay: 4,
    enrichmentTags: [],
    coats: ["Grey"],
    // One calf after a long wait (a manatee carries hers about a year); it stays by its mother and grows up slowly.
    breeding: { litter: 1, gestationDays: 5, matureDays: 6, cooldownDays: 7, juvenileScale: 0.4, young: "calf", youngPlural: "calves" },
    names: ["Snooty", "Hugh", "Buffett", "Potato", "Lettuce", "Mellow", "Cabbage", "Calypso", "Bumble", "Seacow", "Gentleman", "Chubby", "Moo", "Waddle", "Sirena", "Manny"],
  },
  "zoocraft:okapi": {
    id: "zoocraft:okapi",
    displayName: "Lush Okapi",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_okapi",
    entityType: "zoocraft:okapi",
    family: "okapi",
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    // Leafy Rations from a Basic Feeder or an Elevated Browse Feeder (browsesEither: the giraffe's relative reaches
    // both), and the lush plants beside its floor.
    dietTags: ["leafy"],
    browsesEither: true,
    carrierProfile: "large",
    research: "cave_expeditions", // a Reinforced Crate carries one after Cave Expeditions research (transport/carriers.js)
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot", "tongue", "eyewash", "clay"],
    where: "Lush caves, alone: look under azalea trees, where rooted dirt and hanging roots lead down to them. Out by day browsing azalea, dripleaf and glow berries with a long dark tongue and licking the clay round the cave pools. Shy: one slips away unless you sneak or hold a Leafy Ration",
    // Okapis live alone, a mother with her calf; two or three get on in a big enough exhibit.
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    // Lush ground (the okapi measure): moss in the floor, and lush plants beside it to browse, plantsPer for each grown one
    // (minPlants at least), up to `share` of its food. A clay lick. Quiet cover, as the deer's.
    lushGround: { moss: 8, plantsPer: 2, minPlants: 2, share: 0.3 },
    clayLick: { min: 1 },
    cover: { minFraction: 0.1 },
    // One grown male to an exhibit (each marks his own ground); a male has two short furred ossicones (minecraft:mark_variant 1).
    oneMale: true,
    sexLook: true,
    hiddenCalf: true, // a calf lies hidden its first park day, in the okapi measure's best-covered spot (animals/nursery.js)
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // One coat: chocolate brown, white stripes on the rump and legs, a grey-white face, a tuft of moss along the crest
    // (a female a little redder; a calf its own skin).
    coats: ["Okapi"],
    // One calf after a long wait (15 months, as the giraffe's), on the giraffe's scale.
    breeding: { litter: 1, gestationDays: 4, matureDays: 6, cooldownDays: 8, juvenileScale: 0.45, young: "calf", youngPlural: "calves" },
    names: ["Ituri", "Epulu", "Velvet", "Cocoa", "Mossy", "Dripple", "Glowberry", "Kivu", "Mocha", "Pecan", "Fernie", "Hickory", "Rootsy", "Liana", "Umber", "Pippin"],
  },
  "zoocraft:molebear": {
    id: "zoocraft:molebear",
    displayName: "Earth Molebear",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_molebear",
    entityType: "zoocraft:molebear",
    family: "molebear",
    movementProfile: "terrestrial",
    // Twice the size since 0.1.140 (Austin), in the big animals' room (data/profiles.js big_burrower).
    habitatProfile: "big_burrower",
    // Insect Rations (grubs) from a Basic Feeder or an Insect Feeder, and the grubs it digs out of its Burrow Soil.
    dietTags: ["insect"],
    carrierProfile: "large",
    research: "cave_expeditions", // a Reinforced Crate carries one after Cave Expeditions research (transport/carriers.js)
    baitItem: "zoocraft:insect_ration",
    observe: ["spot", "spade", "starnose", "rearup"],
    where: "Ordinary caves deep down, below y 0, alone: not the lush caves or the deep dark. On the cave floor of stone, deepslate, tuff, gravel or dirt, sniffing with a pink star nose. Come close without sneaking and one digs itself into the ground",
    // Solitary, as a black bear: one alone, or a pair in a big enough exhibit, with their two cubs.
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // Burrow Soil (the molebear measure): `min` blocks or more beside the floor, and faces of it to tunnel into; with a
    // face for each grown one, the grubs it digs up are `share` of its food. 0.1.140: 12, the front of a bank 4 wide and
    // 3 high (a tunnel 2 by 2 with soil each side and over it).
    burrowSoil: { min: 12, share: 0.25 },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage", "dig"],
    // Two coats: Slate (dark slate-grey velvet) and Loam (warm brown); a cub has its own skin.
    coats: ["Slate", "Loam"],
    // Two cubs, as a black bear's, after a short wait; on a bear cub's scale.
    breeding: { litter: 2, gestationDays: 3, matureDays: 6, cooldownDays: 8, juvenileScale: 0.4, young: "cub", youngPlural: "cubs" },
    names: ["Digby", "Loamy", "Burrows", "Clod", "Tunnel", "Nubbin", "Gravel", "Moley", "Spade", "Shovel", "Mudge", "Starling", "Rootbeer", "Dusty", "Grubby", "Furrow"],
  },
  "zoocraft:skulker": {
    id: "zoocraft:skulker",
    displayName: "Skulker",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_skulker",
    entityType: "zoocraft:skulker",
    family: "skulker",
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    // Insect Rations from a Basic Feeder or an Insect Feeder: blind cave animals such as the olm live on small
    // invertebrates.
    dietTags: ["insect"],
    carrierProfile: "large",
    // One look: sculk-dark hide, glowing ribs, heart and tendrils (its glow layers); a sculkling the same at half size.
    coats: ["Sculk"],
    research: "cave_expeditions", // a Reinforced Crate carries one after Cave Expeditions research (transport/carriers.js)
    baitItem: "zoocraft:insect_ration",
    observe: ["spot", "tendrils", "meet", "emerge"],
    where: "The deep dark only, very rarely, on its sculk and deepslate. The first time you walk into an Ancient City, one rests somewhere near, out of sight. Move near it without sneaking and it walks over to sniff you",
    // Alone or a pair, with their one young.
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    // The dark: no daylight on the floor and nothing brighter than light 7 (the nocturnal house's test; comfort capped
    // in light). Its ribs, heart and tendrils glow, so guests see it there.
    lowLight: true,
    glows: true,
    // Sculk in the floor (the skulker measure): `min` blocks or more; and no sculk shrieker in or beside the floor.
    sculkFloor: { min: 8 },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // One young at a time, a sculkling, half its size.
    breeding: { litter: 1, gestationDays: 4, matureDays: 8, cooldownDays: 10, juvenileScale: 0.5, young: "sculkling", youngPlural: "sculklings" },
    names: ["Hush", "Murmur", "Thrum", "Tremor", "Sonar", "Quaver", "Whisper", "Shade", "Rattle", "Rustle", "Thud", "Patter", "Cadence", "Sculky", "Tock", "Tick"],
  },
  "zoocraft:unicorn": {
    id: "zoocraft:unicorn",
    displayName: "Unicorn",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_unicorn",
    entityType: "zoocraft:unicorn",
    family: "unicorn",
    movementProfile: "terrestrial",
    habitatProfile: "grassland",
    // Grain Rations (hay with a little grain), from a Basic Feeder or a Hay Rack (rack), as the zebra.
    dietTags: ["grain"],
    rack: true,
    carrierProfile: "livestock",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "moonflowers", "horndip", "rearing"],
    where: "The Mythical Glade only, in small herds on the open grass between the giant trees: grazing, nibbling the glowing flowers and dipping their horns in the glowing pools. Shy: one rears and canters off unless you sneak or hold a Grain Ration",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    // Grazing (the zebra's rule: perAnimal grass blocks in the floor for each give up to `share` of their food), and the
    // glade's glowing flowers on the floor (the unicorn measure): `per` for each grown one, `min` at least.
    graze: { perAnimal: 30, share: 0.4 },
    gladeFlowers: { per: 3, min: 4 },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Moonlit (snow white, a lavender-to-mint mane and tail, a pearl horn), 1 Dawn
    // (cream, a rose-to-peach mane and tail, a rose-gold horn). A foal is soft grey-white with a horn bud.
    coats: ["Moonlit", "Dawn"],
    // One foal after a long wait (a horse's 11 months), on the zebra's scale.
    breeding: { litter: 1, gestationDays: 4, matureDays: 5, cooldownDays: 6, juvenileScale: 0.6, young: "foal", youngPlural: "foals" },
    names: ["Seraphina", "Lumina", "Opaline", "Solstice", "Elowen", "Silverlace", "Halcyon", "Moonglow", "Rosalind", "Evenstar", "Thistledown", "Silverhoof", "Willowmist", "Isolde", "Mirabel", "Sunbeam"],
  },
  "zoocraft:dragon": {
    id: "zoocraft:dragon",
    displayName: "Dragon",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_dragon",
    entityType: "zoocraft:dragon",
    family: "dragon",
    movementProfile: "aerial",
    habitatProfile: "great_aerial",
    flies: true,
    // Meat Rations from a Basic Feeder on the floor.
    dietTags: ["meat"],
    carrierProfile: "large",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "dragonfire", "wingbask", "dragonroar"],
    where: "The Lava Falls in the Nether only, a rare few: flying through its great caverns and over the lava seas, now and then landing on the nylium by the falls to bask in the heat. Wary: one roars and takes off unless you sneak or hold a Meat Ration",
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    // A lit campfire or soul campfire on the floor or beside it (the dragon measure), to bask by.
    warmth: { min: 1 },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Emerald (green scales, a gold belly, green fire), 1 Ember (red, a cream belly,
    // orange fire), 2 Frost (ice blue, a pale belly, icy blue fire). A hatchling is small with a big head and stubby horns.
    coats: ["Emerald", "Ember", "Frost"],
    // One hatchling after a long wait, growing slowly.
    breeding: { litter: 1, gestationDays: 6, matureDays: 8, cooldownDays: 10, juvenileScale: 0.35, young: "hatchling", youngPlural: "hatchlings" },
    names: ["Thorn", "Fafnir", "Brimstone", "Jasper", "Solara", "Borealis", "Galewing", "Ignatius", "Pyra", "Smoulder", "Rune", "Glacius", "Verdigris", "Malachite", "Hearthstone", "Garnet"],
  },
  "zoocraft:griffin": {
    id: "zoocraft:griffin",
    displayName: "Griffin",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_griffin",
    entityType: "zoocraft:griffin",
    family: "griffin",
    movementProfile: "aerial",
    habitatProfile: "great_aerial",
    flies: true,
    // Meat Rations from a Basic Feeder on the floor.
    dietTags: ["meat"],
    carrierProfile: "large",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "guard", "screech", "dive"],
    where: "The Mythical Glade only, a few, alone or in pairs: flying over the giant trees, perching on top of them and now and then landing on the open grass. Wary: one screeches and takes off unless you sneak or hold a Meat Ration",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // A block of gold or raw gold on the floor or in it (the griffin measure), to guard.
    hoard: { min: 1 },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Golden (a white eagle's head on a tawny lion's body, golden wings), 1 Snowy
    // (white with grey bars), 2 Storm (slate grey, a dark head, steel-blue wings). A chick is small and fluffy with a big head.
    coats: ["Golden", "Snowy", "Storm"],
    // One chick after a long wait, growing slowly.
    breeding: { litter: 1, gestationDays: 5, matureDays: 6, cooldownDays: 8, juvenileScale: 0.4, young: "chick", youngPlural: "chicks" },
    names: ["Aquila", "Gryph", "Sunclaw", "Skyreach", "Altair", "Goldcrest", "Feathermane", "Leonis", "Aerie", "Valkyr", "Aurum", "Hyperion", "Cirrus", "Argent", "Stormwing", "Midas"],
  },
  "zoocraft:glowhorn_stag": {
    id: "zoocraft:glowhorn_stag",
    displayName: "Glowhorn Stag",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_glowhorn_stag",
    entityType: "zoocraft:glowhorn_stag",
    family: "glowhorn",
    movementProfile: "terrestrial",
    habitatProfile: "grassland",
    // Leafy Rations (the deer's), from a Basic Feeder or a Hay Rack (rack).
    dietTags: ["leafy"],
    rack: true,
    carrierProfile: "livestock",
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot", "antlerglow", "antlerrub", "stagbellow"],
    where: "The Mythical Glade only, in small herds among the giant trees: grazing, rubbing their antlers on the trunks, and at dusk lifting their heads while their antlers flare with light. Wary: one bounds off unless you sneak or hold a Leafy Ration",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    // Grazing (the zebra's rule: perAnimal grass blocks in the floor for each give up to `share` of their food), and a
    // trunk to rub its antlers on (the stag measure): `min` spots on the floor to rub from.
    graze: { perAnimal: 30, share: 0.4 },
    trunks: { min: 1 },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    // Coat comes from minecraft:variant: 0 Hind (smaller antlers, three points a side), 1 Stag (six points a side, a
    // darker neck and ruff). A fawn is dappled, its spots glowing faintly, with antler buds.
    coats: ["Hind", "Stag"],
    sexByCoat: ["female", "male"],
    // One fawn after a long wait (an elk's 8 months), on the deer's scale.
    breeding: { litter: 1, gestationDays: 3, matureDays: 5, cooldownDays: 5, juvenileScale: 0.5, young: "fawn", youngPlural: "fawns" },
    names: ["Ardent", "Sylvan", "Brindle", "Thornwick", "Brightbough", "Elderglow", "Fennick", "Hartley", "Mossbeam", "Tamarack", "Elkhorn", "Fernlight", "Hartwell", "Larkspur", "Thornbeam", "Wren"],
  },
  "zoocraft:giant_yeti": {
    id: "zoocraft:giant_yeti",
    displayName: "Giant Yeti",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_giant_yeti",
    entityType: "zoocraft:giant_yeti",
    family: "giant_yeti",
    movementProfile: "terrestrial",
    habitatProfile: "yeti",
    // A boss (0.1.159): caught only once tired out in a fight (animals/boss.js bossCatchBlock), its lair then caught.
    boss: true,
    // Fruit Rations (sweet berries: its favourite) and Fish Rations, from a Basic Feeder.
    dietTags: ["fruit", "fish"],
    carrierProfile: "yeti",
    baitItem: "zoocraft:fruit_ration",
    observe: ["spot", "yetiroar", "yetihurl", "yetitired"],
    where: "The taigas only (snowy or not), one to an area, alone in its lair: a snowy clearing with a den of stone and ice. Calm till you hit it or walk right up to it in Survival without sneaking; then it fights, and it is never killed: worn down, it slumps down tired out",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A cold habitat (the penguin's rule: a stocked Cooling Unit), snow or ice under half the floor (the snow measure),
    // and a den: a roof 5 or more blocks up over part of the floor.
    cold: true,
    snowFloor: { share: 0.5 },
    cover: { minFraction: 0.06, why: "a den" },
    // A guest favourite: its exhibit's view counts a quarter more.
    favourite: true,
    rationUnitsPerParkDay: 6,
    enrichmentTags: ["forage"],
    coats: ["Snow"],
    names: ["Avalanche", "Blizzard", "Glacier", "Snowdrift", "Everest", "Frostbeard", "Icemane", "Whiteout", "Kangri", "Migoi", "Yeren", "Hailstone", "Cragmore", "Tundra", "Rime", "Sleet"],
  },
  // The Sloth (0.1.298; Austin, 2026-11-15: "a custom mob that you can capture for the zoo in the labratory. Let's have
  // a normal sloth. This can explain the sloth bears"): an ordinary sloth, the Skeleton Scientist's specimen, one in
  // the cage of each hidden laboratory (world/lab.js). The Soul Sloths of the valleys came of his trials on its kind.
  // An Overworld animal: no heat, leaves to eat, something to climb.
  "zoocraft:sloth": {
    id: "zoocraft:sloth",
    displayName: "Sloth",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:wild_sloth",
    entityType: "zoocraft:sloth",
    family: "sloth",
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["leafy"],
    carrierProfile: "small",
    baitItem: "zoocraft:leafy_ration",
    observe: ["spot"],
    where: "Nowhere in the wild: one sits in a cage in each of the Skeleton Scientist's hidden laboratories, deep under the Nether's fortresses. His notes call it the specimen the Soul Sloths were made from. Slow and harmless",
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    climbTree: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["climb", "forage"],
    coats: ["Brown"],
    // One young at a time, slowly (a game choice): half size.
    breeding: { litter: 1, gestationDays: 5, matureDays: 6, cooldownDays: 8, juvenileScale: 0.5, young: "baby", youngPlural: "babies" },
    names: ["Dozy", "Linger", "Dawdle", "Pokey", "Nap", "Slowpoke", "Tarry", "Lollop", "Siesta", "Hammock", "Bough", "Loiter", "Amble", "Mosey", "Sunday", "Dally"],
  },
  "zoocraft:soul_sloth": {
    id: "zoocraft:soul_sloth",
    displayName: "Soul Sloth",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:wild_soul_sloth",
    entityType: "zoocraft:soul_sloth",
    family: "soul_sloth",
    movementProfile: "terrestrial",
    habitatProfile: "sloth",
    // A boss (0.1.161): caught only once tired out in a fight (animals/boss.js bossCatchBlock), its lair then caught.
    boss: true,
    // Fungal Rations (crimson and warped fungus), from a Basic Feeder.
    dietTags: ["fungus"],
    carrierProfile: "sloth",
    baitItem: "zoocraft:fungal_ration",
    observe: ["spot", "slothhang", "slothlob", "slothtired"],
    where: "The soul sand valleys in the Nether only, one to an area, alone in its lair: a clearing of soul soil with a fossil arch of bone, where it hangs upside down under the beam. Calm till you hit it or walk right up to it in Survival without sneaking; then it drops down and fights, and it is never killed: worn down, it curls up tired out",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A Nether animal: a fuelled Thermal Regulator. Soul sand or soul soil under half the floor (the sloth measure), and
    // a beam to hang from (a post with 5 solid blocks running out from its top, 5 to 8 over the floor).
    heat: true,
    soulFloor: { share: 0.5 },
    beam: true,
    // A guest favourite: its exhibit's view counts a quarter more.
    favourite: true,
    rationUnitsPerParkDay: 5,
    enrichmentTags: ["forage"],
    coats: ["Soul"],
    names: ["Lethe", "Doze", "Slumber", "Ashgrave", "Lull", "Dormer", "Drowse", "Mortimer", "Sorrow", "Grimsby", "Duskclaw", "Morrow", "Nod", "Tallow", "Wraith", "Barrow"],
  },
  "zoocraft:baby_dragon": {
    id: "zoocraft:baby_dragon",
    displayName: "Baby Dragon",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:wild_baby_dragon",
    entityType: "zoocraft:baby_dragon",
    family: "baby_dragon",
    movementProfile: "aerial",
    habitatProfile: "great_aerial",
    flies: true,
    // A boss (0.1.162): caught only once tired out in a fight (animals/boss.js bossCatchBlock), its lair then caught.
    boss: true,
    // Meat Rations from a Basic Feeder on the floor.
    dietTags: ["meat"],
    carrierProfile: "drake",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "drakesleep", "drakedive", "draketired"],
    where: "The outer End islands only (more than 800 blocks out from the middle of the End), one to an area, alone in its lair: a clearing of end stone with an obsidian pillar, its nest on top. Calm till you hit it or walk up under it in Survival without sneaking; then it takes off and fights in the air, and it is never killed: worn down, it glides down and lies panting",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // End ground underfoot as the End's animals have it (end stone, Chorus Turf or Rift Turf in the floor): a lot of it
    // for a big flier.
    endGround: { minCells: 100 },
    // A guest favourite: its exhibit's view counts a quarter more.
    favourite: true,
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Void"],
    names: ["Corvus", "Inkwing", "Noctis", "Voidling", "Ender", "Shardwing", "Riftling", "Starveil", "Erebus", "Tenebris", "Obscura", "Elytra", "Shulk", "Wyrmling", "Morrigan", "Ichor"],
  },
  "zoocraft:zoo_zombie": {
    id: "zoocraft:zoo_zombie",
    displayName: "Zombie",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    // A mob (0.1.163): the vanilla zombie is the one the journal spots (mobSource); a calmed one (a Passivity Serum used
    // on a weakened zombie) is the one a Mob Cage carries (wildSource).
    wildSource: "zoocraft:calm_zombie",
    mobSource: "minecraft:zombie",
    entityType: "zoocraft:zoo_zombie",
    family: "zoo_zombie",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations from a Basic Feeder (zombies eat flesh).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld: on the surface at night and in caves (monsters spawn at block light 0). Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research). Husks, zombie villagers and drowned are mobs of their own",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The dark: no daylight in the pen and nothing brighter than light 7 (the nocturnal house's test; comfort capped in
    // light), and graveyard earth under half the floor (the mob floor measure).
    lowLight: true,
    mobFloor: { ids: ["minecraft:dirt", "minecraft:coarse_dirt", "minecraft:podzol", "minecraft:dirt_with_roots", "minecraft:mud"], share: 0.5, how: "graveyard earth (dirt, coarse dirt, podzol, rooted dirt or mud)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Zombie"],
    names: ["Rotley", "Groan", "Mildew", "Shamble", "Grimace", "Lurch", "Moldy", "Stitches", "Grubb", "Mortis", "Shuffles", "Ghoulie", "Rigor", "Bogart", "Dregs", "Putrid"],
  },
  "zoocraft:zoo_skeleton": {
    id: "zoocraft:zoo_skeleton",
    displayName: "Skeleton",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    // A mob (0.1.163), as the zombie.
    wildSource: "zoocraft:calm_skeleton",
    mobSource: "minecraft:skeleton",
    entityType: "zoocraft:zoo_skeleton",
    family: "zoo_skeleton",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Bone Rations (bones and bone meal) from a Basic Feeder.
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld: on the surface at night and in caves (monsters spawn at block light 0). Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research). Strays, bogged, parched and wither skeletons are mobs of their own",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // A crypt floor under a third of the floor (the mob floor measure).
    mobFloor: { ids: ["minecraft:bone_block", "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:cobbled_deepslate", "minecraft:gravel"], share: 0.3, how: "a crypt floor (bone blocks, cobblestone, mossy cobblestone, cobbled deepslate or gravel)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Skeleton"],
    names: ["Rattles", "Clatter", "Femur", "Tibia", "Ribsy", "Bonaparte", "Skully", "Kneecap", "Marrow", "Calcium", "Jawbone", "Clavicle", "Sternum", "Patella", "Coccyx", "Humerus"],
  },
  "zoocraft:zoo_creeper": {
    id: "zoocraft:zoo_creeper",
    displayName: "Creeper",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    // A mob (0.1.164), as the zombie: the vanilla creeper is the one the journal spots, a calmed one the one a Mob Cage
    // carries. It never swells or explodes.
    wildSource: "zoocraft:calm_creeper",
    mobSource: "minecraft:creeper",
    entityType: "zoocraft:zoo_creeper",
    family: "zoo_creeper",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder.
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld: on the surface at night and in caves (monsters spawn at block light 0). Weaken one to a quarter of its health (a bow keeps you out of reach), then use a Passivity Serum on it from a few blocks away (Mob Taming research): too close and it hisses and explodes",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Grass blocks under a quarter of the floor, and 3 or more leaves or ferns in the pen (leaf blocks in a wall or as a
    // bush, ferns on the grass; a large fern is two).
    mobFloor: { ids: ["minecraft:grass_block"], share: 0.25, how: "grass blocks" },
    mobDecor: { ids: ["minecraft:oak_leaves", "minecraft:spruce_leaves", "minecraft:birch_leaves", "minecraft:jungle_leaves", "minecraft:acacia_leaves", "minecraft:dark_oak_leaves", "minecraft:mangrove_leaves", "minecraft:cherry_leaves", "minecraft:pale_oak_leaves", "minecraft:azalea_leaves", "minecraft:orange_poplar_leaves", "minecraft:red_poplar_leaves", "minecraft:yellow_poplar_leaves", "minecraft:azalea_leaves_flowered", "minecraft:fern", "minecraft:large_fern"], min: 3, how: "leaves or ferns", where: "leaf blocks in a wall or as a bush on the floor, ferns on the grass" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // A guest favourite: its pen's view counts a quarter more.
    favourite: true,
    coats: ["Creeper"],
    names: ["Fizzle", "Fizzbang", "Hissy", "Kaboom", "Fuse", "Popper", "Sparky", "Crackle", "Ssseymour", "Blammo", "Greenie", "Cactus", "Ticker", "Boomer", "Fusebox", "Ssslinky"],
  },
  "zoocraft:zoo_spider": {
    id: "zoocraft:zoo_spider",
    displayName: "Spider",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    // A mob (0.1.164), as the zombie. It walks the floor (navigation.walk, no climbing) and through cobwebs at full speed.
    wildSource: "zoocraft:calm_spider",
    mobSource: "minecraft:spider",
    entityType: "zoocraft:zoo_spider",
    family: "zoo_spider",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld: on the surface at night and in caves (monsters spawn at block light 0); by day they leave you be unless you hit them. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research). Cave spiders are mobs of their own that share a pen with them",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The dark, darker than the zombies': no daylight and nothing brighter than light 4 on the floor (a Nocturnal Lamp
    // hung 3 blocks above the floor gives 4 right under it), and 3 or more cobwebs in the pen.
    lowLight: true,
    darkLight: 4,
    mobDecor: { ids: ["minecraft:web"], min: 3, how: "cobwebs", where: "hung in the corners and along the walls; spiders walk through them" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Spider"],
    names: ["Webster", "Eightlegs", "Silky", "Itsy", "Bitsy", "Tangle", "Creepycrawly", "Crawly", "Spindle", "Lurker", "Weaver", "Cobweb", "Arachne", "Eightball", "Hairy", "Dangle"],
  },
  "zoocraft:zoo_cyclops": {
    id: "zoocraft:zoo_cyclops",
    displayName: "Cyclops",
    plural: "Cyclopes",
    origin: "custom_overworld",
    homeDimension: "minecraft:overworld",
    // A mob (0.1.165): the wild one (a fourth kind in the boss framework) is the one the journal spots; a calmed one (the
    // Passivity Serum used on it while it sits tired out) is the one a Mob Cage carries.
    wildSource: "zoocraft:calm_cyclops",
    mobSource: "zoocraft:wild_cyclops",
    entityType: "zoocraft:zoo_cyclops",
    family: "zoo_cyclops",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen_giant",
    mob: true,
    // Meat Rations from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The windswept hills and the stony peaks only, very rarely: one alone in its camp (a clearing ringed with boulders, a campfire in the middle and a bed of hides under a rock wall), made the first time you walk there once your park has done Mob Taming, and never within 1,500 blocks of another. It goes for anyone within 12 blocks (sneak to get closer) and can't be killed: wear it down till it sits down panting (a quarter of its health), then use a Passivity Serum on it",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // Stone underfoot (under half the floor), and a pile of 4 or more mossy cobblestone boulders in the pen.
    mobFloor: { ids: ["minecraft:stone", "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:andesite", "minecraft:diorite", "minecraft:granite", "minecraft:tuff", "minecraft:calcite", "minecraft:gravel"], share: 0.5, how: "stone (stone, cobblestone, mossy cobblestone, andesite, diorite, granite, tuff, calcite or gravel)" },
    mobDecor: { ids: ["minecraft:mossy_cobblestone"], min: 4, how: "mossy cobblestone boulders", where: "a pile of them on the floor, or in a wall" },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    // A guest favourite: its pen's view counts a quarter more.
    favourite: true,
    coats: ["Hill"],
    names: ["Polyphemus", "Brontes", "Steropes", "Arges", "Bigeye", "Cobblejaw", "Gorm", "Lumpkin", "Clobber", "Grunt", "Basher", "Stomper", "Ogle", "Squint", "Monocle", "Hurlwick"],
  },
  "zoocraft:zoo_necromancer": {
    id: "zoocraft:zoo_necromancer",
    displayName: "Necromancer",
    origin: "custom_nether",
    homeDimension: "minecraft:nether",
    // A mob (0.1.166): the wild one (a fifth kind in the boss framework) is the one the journal spots; a calmed one (the
    // Passivity Serum used on it while it kneels tired out) is the one a Mob Cage carries.
    wildSource: "zoocraft:calm_necromancer",
    mobSource: "zoocraft:wild_necromancer",
    entityType: "zoocraft:zoo_necromancer",
    family: "zoo_necromancer",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Bone Rations from a Basic Feeder.
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "The Nether only, very rarely: one alone in its crypt (a floor of soul soil and blackstone with broken walls, pillars with soul lanterns, an altar and two headstones) in a soul sand valley or beside a Nether fortress, made the first time you walk there once your park has done Mob Taming, and never within 1,500 blocks of another. It goes for anyone within 12 blocks (sneak to get closer), throws soul bolts and raises skeletons, and can't be killed: wear it down till it kneels down panting (a quarter of its health), then use a Passivity Serum on it",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // Soul sand or soul soil under half the floor, and a soul lantern or more in the pen.
    mobFloor: { ids: ["minecraft:soul_sand", "minecraft:soul_soil"], share: 0.5, how: "soul sand or soul soil" },
    mobDecor: { ids: ["minecraft:soul_lantern"], min: 1, how: "soul lanterns", where: "hung from the roof, or standing on the floor or a wall" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // A guest favourite: its pen's view counts a quarter more.
    favourite: true,
    coats: ["Crypt"],
    names: ["Mordecai", "Grimwald", "Ossian", "Morbius", "Revenant", "Hollowell", "Cinderbone", "Soulwick", "Cryptkin", "Duskbane", "Marrowgast", "Sepulchre", "Wraithe", "Bonewick", "Graveling", "Lanthorn"],
  },
  "zoocraft:zoo_voidling": {
    id: "zoocraft:zoo_voidling",
    displayName: "Voidling",
    origin: "custom_end",
    homeDimension: "minecraft:the_end",
    // A mob (0.1.167): the wild one (a sixth kind in the boss framework) is the one the journal spots; a calmed one (the
    // Passivity Serum used on it while it crouches tired out) is the one a Mob Cage carries.
    wildSource: "zoocraft:calm_voidling",
    mobSource: "zoocraft:wild_voidling",
    entityType: "zoocraft:zoo_voidling",
    family: "zoo_voidling",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Chorus Browse from a Basic Feeder.
    dietTags: ["chorus"],
    carrierProfile: "mob",
    baitItem: "zoocraft:chorus_browse",
    observe: ["spot", "mobcalm"],
    where: "The outer End islands only, very rarely: one alone in its rift (a round floor of end stone with crying obsidian in its middle and a broken ring of obsidian pillars) by an island's edge, made the first time you walk out there once your park has done Mob Taming, and never within 1,500 blocks of another. It is very slow, but it goes for anyone within 10 blocks (sneak to get closer), throws void orbs, and shrieks before it grabs you to drag you to the edge (hit it and it lets go). It can't be killed: wear it down till it crouches down panting (a quarter of its health), then use a Passivity Serum on it",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A solid floor (no void in the zoo), end stone or end stone bricks under half of it, and a crying obsidian or more.
    mobFloor: { ids: ["minecraft:end_stone", "minecraft:end_bricks"], share: 0.5, how: "end stone or end stone bricks" },
    mobDecor: { ids: ["minecraft:crying_obsidian"], min: 1, how: "crying obsidian", where: "set in the floor or a wall" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // A guest favourite: its pen's view counts a quarter more.
    favourite: true,
    coats: ["Shadow"],
    names: ["Ebon", "Shroud", "Penumbra", "Tenebra", "Sliver", "Stilt", "Gaunt", "Brink", "Lurk", "Nullie", "Dimly", "Duskin", "Murkle", "Inkwell", "Grimble", "Longarm"],
  },
  // The farmyard four (0.1.168, module 12: research/vanilla_plan.md): the game's own sheep, cows, pigs and chickens as zoo
  // copies with the vanilla look (the zoo rabbit's pattern), kept as a petting farm. They share a yard with each other and
  // the rabbits (exhibits/mixing.js farmyard). A sheep keeps its wool colour (species.coatFrom "color": minecraft:color),
  // the others their climate (coatFrom "climate": minecraft:climate_variant, the zoo copy's minecraft:variant). They want
  // hay bedding under a roof (species.hay), sheep and cows grass to graze, pigs a mud wallow; the game's shearing, milking
  // and eggs stay (species.products; animals/farm.js keeps a shorn sheep's wool growing back).
  "zoocraft:zoo_sheep": {
    id: "zoocraft:zoo_sheep",
    displayName: "Sheep",
    plural: "Sheep",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:sheep", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_sheep",
    family: "sheep", // the vanilla family: the journal counts wild and zoo ones as its flock
    movementProfile: "terrestrial",
    habitatProfile: "farmyard",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "Plains, meadows, forests, taigas and snowy plains, in small flocks",
    social: { minGroup: 2, recommendedMax: 10, prefersCompany: true },
    graze: { perAnimal: 12, share: 0.5 },
    hay: { per: 2, min: 2 }, // bedding: hay bales under a roof, 1 for every 2 in the yard (animals/farmRules.js)
    products: ["wool"],
    petting: true, // with a keeper on its round the yard is a petting farm: guests like it a quarter more
    coatFrom: "color",
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Gray", "Light Gray", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black"],
    breeding: { litter: 1, litterMax: 2, gestationDays: 2, matureDays: 2, cooldownDays: 3, juvenileScale: 0.5, young: "lamb", youngPlural: "lambs" },
    names: ["Woolly", "Fleece", "Baabara", "Lambchop", "Cotton", "Fluffy", "Lanolin", "Dolly", "Shearlock", "Daisy", "Puffball", "Ramsey", "Woolbert", "Muffin", "Snowball", "Tufty"],
  },
  "zoocraft:zoo_cow": {
    id: "zoocraft:zoo_cow",
    displayName: "Cow",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:cow", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_cow",
    family: "cow", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "farmyard",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "Plains, meadows, forests, savannas and taigas, in small herds",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    graze: { perAnimal: 12, share: 0.5 },
    hay: { per: 2, min: 2 }, // bedding: hay bales under a roof, 1 for every 2 in the yard (animals/farmRules.js)
    products: ["milk"],
    petting: true, // with a keeper on its round the yard is a petting farm: guests like it a quarter more
    coatFrom: "climate",
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Temperate", "Warm", "Cold"],
    breeding: { litter: 1, gestationDays: 3, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "calf", youngPlural: "calves" },
    names: ["Bessie", "Buttercup", "Clarabelle", "Moolinda", "Milky", "Moobert", "Gertie", "Mabel", "Brownie", "Caramel", "Dottie", "Bluebell", "Mootilda", "Angus", "Ferdinand", "Pumpkin"],
  },
  "zoocraft:zoo_pig": {
    id: "zoocraft:zoo_pig",
    displayName: "Pig",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:pig", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_pig",
    family: "pig", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "farmyard",
    dietTags: ["grain", "root"],
    carrierProfile: "livestock",
    baitItem: "minecraft:carrot",
    observe: ["spot", "sniff", "herd"],
    where: "Plains, forests, savannas, jungles and taigas, in small groups",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    mud: { minCells: 4 },
    hay: { per: 2, min: 2 }, // bedding: hay bales under a roof, 1 for every 2 in the yard (animals/farmRules.js)
    products: [],
    petting: true, // with a keeper on its round the yard is a petting farm: guests like it a quarter more
    coatFrom: "climate",
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage", "dig"],
    coats: ["Temperate", "Warm", "Cold"],
    breeding: { litter: 2, litterMax: 4, gestationDays: 2, matureDays: 2, cooldownDays: 3, juvenileScale: 0.5, young: "piglet", youngPlural: "piglets" },
    names: ["Wilbur", "Babe", "Oinkers", "Hamlet", "Porkchop", "Snorty", "Truffles", "Hogwash", "Curly", "Snuffles", "Snoutie", "Penelope", "Napoleon", "Gloria", "Squeaky", "Piggles"],
  },
  "zoocraft:zoo_chicken": {
    id: "zoocraft:zoo_chicken",
    displayName: "Chicken",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:chicken", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_chicken",
    family: "chicken", // the vanilla family: the journal counts wild and zoo ones as its flock
    movementProfile: "terrestrial",
    habitatProfile: "coop",
    dietTags: ["grain", "seed"],
    carrierProfile: "small",
    baitItem: "minecraft:wheat_seeds",
    observe: ["spot", "peck", "flock"],
    where: "Plains, forests, savannas, jungles and taigas, in small flocks",
    social: { minGroup: 3, recommendedMax: 12, prefersCompany: true },
    hay: { per: 2, min: 2 }, // bedding: hay bales under a roof, 1 for every 2 in the yard (animals/farmRules.js)
    products: ["eggs"],
    petting: true, // with a keeper on its round the yard is a petting farm: guests like it a quarter more
    coatFrom: "climate",
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Temperate", "Warm", "Cold"],
    breeding: { litter: 1, litterMax: 3, gestationDays: 1, matureDays: 2, cooldownDays: 2, juvenileScale: 0.5, young: "chick", youngPlural: "chicks" },
    names: ["Henrietta", "Clucky", "Pecky", "Eggbert", "Feathers", "Goldie", "Peep", "Henny", "Penny", "Cluckers", "Omelette", "Cornflake", "Speckles", "Scramble", "Featherby", "Chirpy"],
  },
  // Wolves and foxes (0.1.169, module 12: research/vanilla_plan.md): the game's own as zoo copies with the vanilla look
  // (the zoo rabbit's pattern) and the game's own ways (animals/woodlandRules.js). A wolf keeps its coat (minecraft:variant,
  // all nine), a fox red or arctic. Any of their foods coaxes one in (species.baitAlso). Wolves: a pack with a den (cover)
  // and Scent Posts to follow as a scent trail (species.scentTrail: the zoo wolf walks to one now and then). Foxes: alone
  // or a pair, napping by day under cover as the game's foxes do (species.naps: the journal reads the sleeping flag), with
  // Burrow Soil to dig in (toys "soil") and a Puzzle Feeder to find their food in.
  "zoocraft:zoo_wolf": {
    id: "zoocraft:zoo_wolf",
    displayName: "Wolf",
    plural: "Wolves",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:wolf", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_wolf",
    family: "wolf", // the vanilla family: the journal counts wild and zoo ones as its pack
    movementProfile: "terrestrial",
    habitatProfile: "pack",
    dietTags: ["meat"],
    carrierProfile: "livestock",
    baitItem: "zoocraft:meat_ration",
    baitAlso: ["minecraft:beef", "minecraft:porkchop", "minecraft:mutton", "minecraft:chicken", "minecraft:rabbit"], // the raw meats coax one in too
    baitText: "some raw meat (beef, pork, mutton, chicken or rabbit) or a Meat Ration",
    observe: ["spot", "pack", "sniff"],
    where: "Taigas and forests, in packs: pale ones in taigas, ashen in snowy taigas, black and chestnut in old growth taigas, rusty in sparse jungles, snowy in groves, spotted on savanna plateaus, striped in wooded badlands, woods ones in forests. They leave you be unless one is hit",
    social: { minGroup: 3, recommendedMax: 8, prefersCompany: true },
    cover: { minFraction: 0.1, why: "a den" }, // a roofed corner or trees, where the pack lies up together
    scentTrail: true, // the zoo wolf walks to a Scent Post now and then and noses it (entities/zoo_wolf.json move_to_block)
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["scent", "forage"],
    coats: ["Pale", "Ashen", "Black", "Chestnut", "Rusty", "Snowy", "Spotted", "Striped", "Woods"],
    breeding: { litter: 2, litterMax: 4, gestationDays: 3, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "pup", youngPlural: "pups" },
    names: ["Fang", "Shadow", "Storm", "Timber", "Koda", "Kiba", "Rook", "Fenrir", "Akela", "Kaya", "Lobo", "Sitka", "Raksha", "Howl", "Moonfang", "Tala"],
  },
  "zoocraft:zoo_fox": {
    id: "zoocraft:zoo_fox",
    displayName: "Fox",
    plural: "Foxes",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:fox", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_fox",
    family: "fox", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "terrestrial",
    habitatProfile: "small_terrestrial",
    dietTags: ["fruit"],
    carrierProfile: "small",
    baitItem: "zoocraft:fruit_ration",
    baitAlso: ["minecraft:sweet_berries", "minecraft:glow_berries"], // berries coax one in too
    baitText: "sweet berries, glow berries or a Fruit Ration",
    observe: ["spot", "nap", "sniff"],
    where: "Taigas, old growth taigas and groves; white arctic foxes where the ground is snowy. By day they nap under the trees, at night they hunt rabbits and chickens. Shy: they run from anyone who isn't sneaking. Sneak up holding sweet berries and one comes to you",
    social: { minGroup: 1, recommendedMax: 5, prefersCompany: false }, // alone or a pair, with a litter
    cover: { minFraction: 0.2, why: "cover to nap under" },
    naps: true, // naps by day under cover, as the game's foxes do (entities/zoo_fox.json fox_day)
    toys: ["soil"], // digs in Burrow Soil (animals/woodlandRules.js soilFixtures)
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["dig", "manipulate", "forage"],
    coats: ["Red", "Arctic"],
    breeding: { litter: 2, litterMax: 3, gestationDays: 2, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "kit", youngPlural: "kits" },
    names: ["Reynard", "Tod", "Vixey", "Copper", "Brush", "Snowdrop", "Kitsune", "Marmalade", "Tinsel", "Flurry", "Paprika", "Sly", "Cinnabar", "Scarlet", "Rufus", "Swift"],
  },
  // Pandas (0.1.170, module 12: research/vanilla_plan.md "0.1.170 pandas: the design"): the game's own as a zoo copy with
  // the vanilla look and ways (animals/bambooRules.js). Each keeps the gene that shows on it (species.genes: its coat is
  // minecraft:variant 0-6, so a brown one is brown and a lazy one lazes), and a cub takes after a parent. Bamboo or a Leafy
  // Ration coaxes one in. A bamboo grove growing in the floor (species.grove) is something to browse, and they have cubs
  // only with one; shade over part of it.
  "zoocraft:zoo_panda": {
    id: "zoocraft:zoo_panda",
    displayName: "Panda",
    plural: "Pandas",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:panda", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_panda",
    family: "panda", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    dietTags: ["leafy"],
    carrierProfile: "livestock",
    baitItem: "zoocraft:leafy_ration",
    baitAlso: ["minecraft:bamboo"], // bamboo coaxes one in too
    baitText: "some bamboo or a Leafy Ration",
    observe: ["spot", "bamboo", "gene"],
    where: "Bamboo jungles, and now and then jungles, alone or two or three together, sitting in the bamboo chewing a stalk. Calm: an aggressive one swats back if hit, and a worried one keeps away from people. Hold bamboo and one comes to you",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    cover: { minFraction: 0.15, why: "shade" },
    grove: { min: 6 }, // stalks of bamboo growing in the floor or beside it (animals/bambooRules.js measureBamboo)
    genes: true, // the coat is the gene that shows (minecraft:variant 0-6; entities/zoo_panda.json zoocraft:coat_N)
    toys: ["grove"], // a bamboo grove is something to browse (forage enrichment)
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage", "climb", "manipulate"],
    coats: ["Normal", "Lazy", "Worried", "Playful", "Brown", "Weak", "Aggressive"],
    breeding: { litter: 1, gestationDays: 4, matureDays: 6, cooldownDays: 8, juvenileScale: 0.4, grove: true, young: "cub", youngPlural: "cubs" },
    names: ["Bao", "Mei", "Ling", "Tuan", "Yuan", "Xiao", "Panko", "Ping", "Jade", "Tofu", "Sesame", "Wonton", "Nori", "Taro", "Lychee", "Dango"],
  },
  // Polar bears (0.1.174, module 12: research/vanilla_plan.md "0.1.174 polar bears: the design"): the game's own as a zoo
  // copy (its look; the young drawn with the grown model, 0.1.172), kept like the big cats: dangerous (Holding Dens, a
  // cub going in and out with its mother, the double Keeper Gate, warn then swipe: animals/predators.js), stepped by
  // animals/polarBear.js. Cold (a stocked Cooling Unit), a pool to swim in (the "polar_bear" profile) and snow or ice
  // under a quarter of the floor (the yeti's snow measure: species.snowFloor). Caught wild like the big cats: a Fish
  // Ration or raw cod or salmon thrown down near a grown one; it can be crated while it eats. The game's own
  // minecraft:on_calm takes an angry one's attack off as it goes to eat (wildCalm), and one let go in the wild comes out
  // grown (wildGrown: the game's grow-up event; its spawn rolls a cub one time in ten).
  "zoocraft:zoo_polar_bear": {
    id: "zoocraft:zoo_polar_bear",
    displayName: "Polar Bear",
    plural: "Polar Bears",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:polar_bear", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_polar_bear",
    family: "polarbear", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "amphibious",
    habitatProfile: "polar_bear",
    // Fish (zoos feed polar bears fish, meat and a carnivore diet): Fish Rations, or raw cod or salmon, from a Basic Feeder.
    dietTags: ["fish"],
    carrierProfile: "large",
    baitItem: "zoocraft:fish_ration",
    baitAlso: ["minecraft:cod", "minecraft:salmon"], // raw cod or salmon thrown down draws one over too
    baitText: "a Fish Ration or a raw cod or salmon",
    wildCalm: "minecraft:on_calm",
    wildGrown: "minecraft:ageable_grow_up",
    observe: ["spot", "swim", "bank"],
    where: "Snowy plains, ice spikes and frozen oceans and rivers, alone or a mother with her cubs, swimming between the ice. Calm unless one is hit or someone comes near a cub; then a grown one stands up and charges. Throw a Fish Ration (or a raw cod or salmon) down near a grown one: while it eats it's calm, and can be crated",
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    dangerous: true,
    dens: { spare: 0, cubsFollow: true },
    cold: true,
    snowFloor: { share: 0.25 },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["swim", "manipulate", "forage"],
    coats: ["White"],
    // 1 or 2 cubs (litterMax), born in the den with their mother; they stay by her till they're grown.
    breeding: { litter: 1, litterMax: 2, gestationDays: 4, matureDays: 8, cooldownDays: 8, juvenileScale: 0.5, young: "cub", youngPlural: "cubs" },
    sounds: { warn: "mob.polarbear.warning", warnPitch: 1.0, swipe: "mob.polarbear.warning", swipePitch: 0.75 },
    names: ["Nanuq", "Siku", "Aput", "Qannik", "Ukiuq", "Nuka", "Kallik", "Taqqiq", "Iceberg", "Pakak", "Floe", "Nilak", "Tundra Rose", "Sila", "Anuri", "Hudson"],
  },
  // Horses and donkeys (0.1.175, module 12: research/vanilla_plan.md "0.1.175 horses and donkeys: the design"): the game's
  // own as zoo copies (its look; the young drawn with the grown model, 0.1.172), kept in a paddock: room, a straight run
  // of floor to gallop along (species.run), grass to graze, hay bales under a roof in a stable corner (species.hay), a Hay
  // Rack, and grooming (species.groom: the game's brush used on each one, or a keeper with the paddock on their round).
  // animals/paddock.js grazes and gallops them (rules in animals/paddockRules.js). A horse keeps its coat (the game's 7)
  // and its markings (the game's 5: species.marks); one let go in the wild gets its coat back by the game's own colour
  // events (species.wildCoats: minecraft:make_<colour>) and, like every one of the game's own animals but the polar bear,
  // comes out grown (the game's spawn rolls a foal one time in five: quests/conservationRules.js growsUpWhenFreed).
  "zoocraft:zoo_horse": {
    id: "zoocraft:zoo_horse",
    displayName: "Horse",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:horse", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_horse",
    family: "horse", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "paddock",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    baitAlso: ["zoocraft:grain_ration"], // a Grain Ration (hay) coaxes one in too
    baitText: "some wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "Plains and savannas, in herds of 2 to 6 of one colour",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    graze: { perAnimal: 30, share: 0.5 },
    hay: { per: 1, min: 1 }, // a stable corner: a hay bale under a roof for each (a 12 by 12 foot box each, the Defra code)
    run: { length: 20 }, // a straight run of floor 2 wide to gallop along (a 20 by 40 riding arena's short side)
    groom: true, // a brush on each one every few park days, or a keeper on the round
    marks: true, // its markings, the game's minecraft:mark_variant
    crossBreed: { with: "zoocraft:zoo_donkey", young: "zoocraft:zoo_mule" }, // with a donkey: a mule foal (0.1.193)
    herdWith: ["zoocraft:zoo_donkey", "zoocraft:zoo_mule"], // the other equines in its paddock count as its herd (0.1.193: a lone horse and donkey, a mule's parents)
    wildCoats: ["white", "creamy", "chestnut", "brown", "black", "gray", "darkbrown"], // the game's minecraft:make_<colour>
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["White", "Creamy", "Chestnut", "Brown", "Black", "Gray", "Dark Brown"],
    // One foal after about 11 months (4 park days), grown in 4.
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "foal", youngPlural: "foals" },
    names: ["Duchess", "Thunder", "Spirit", "Apollo", "Rosie", "Ranger", "Galloway", "Mustang", "Palomino", "Trigger", "Bronco", "Mistral", "Pegasus", "Whinny", "Clyde", "Shire"],
  },
  // Donkeys: a smaller paddock (the "donkey_paddock" profile), a shorter run and less grass (Scotland's equine code:
  // donkeys need much less grazing than horses), a hay bale for every 2 (the Donkey Sanctuary: 50 square feet of bedded
  // shelter each), always in company (the Donkey Sanctuary rehomes them only in pairs). They gallop half as often as
  // horses, and make a petting farm with a keeper on the round, as the farmyard four. They share a paddock with horses.
  "zoocraft:zoo_donkey": {
    id: "zoocraft:zoo_donkey",
    displayName: "Donkey",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:donkey",
    entityType: "zoocraft:zoo_donkey",
    family: "donkey",
    movementProfile: "terrestrial",
    habitatProfile: "donkey_paddock",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    baitAlso: ["zoocraft:grain_ration"],
    baitText: "some wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "Plains, savannas and meadows, alone or in twos and threes",
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    graze: { perAnimal: 16, share: 0.5 },
    hay: { per: 2, min: 1 },
    run: { length: 12, gallop: 0.5 },
    groom: true,
    petting: true, // with a keeper on its round the paddock is a petting farm: guests like it a quarter more
    crossBreed: { with: "zoocraft:zoo_horse", young: "zoocraft:zoo_mule" }, // with a horse: a mule foal (0.1.193)
    herdWith: ["zoocraft:zoo_horse", "zoocraft:zoo_mule"], // the other equines in its paddock count as its herd (0.1.193)
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Gray"],
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "foal", youngPlural: "foals" },
    names: ["Jack", "Jenny", "Honey", "Taffy", "Bertie", "Ollie", "Peggy", "Gus", "Hamish", "Winnie", "Poppet", "Wellington", "Parsnip", "Tumbleweed", "Buttons", "Mojave"],
  },
  // Goats (0.1.180, module 12: research/vanilla_plan.md "0.1.180 goats: the design"): the game's own as a zoo copy (its
  // look and sounds, both horns on; the kid drawn with the grown model, 0.1.172) kept in a mountain exhibit: walls 4 blocks
  // high (they leap 3 up: the goats' own walk in exhibits.js), rock ledges to leap onto with a lookout among them
  // (species.rockLedges, animals/goatRules.js), hay bales under a roof for shelter (species.hay, the farmyard's bedding
  // rule) and a Hay Rack. animals/goat.js leaps them onto the ledges and has two butt heads now and then. A screamer (the
  // game's minecraft:variant 1, 1 goat in 50) stays one: coat 1, screaming where others bleat (zoo_goat.json); let go, the
  // game's own birth event makes it one again (species.wildCoatEvents). A kid takes after one parent or the other.
  "zoocraft:zoo_goat": {
    id: "zoocraft:zoo_goat",
    displayName: "Goat",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:goat", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_goat",
    family: "goat", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "mountain",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    baitAlso: ["zoocraft:grain_ration"], // a Grain Ration (hay) coaxes one in too
    baitText: "some wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "herd", "ledge"],
    where: "Snowy slopes, jagged peaks and frozen peaks, in small herds",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true }, // Defra's goat code para 3: "gregarious animals"
    hay: { per: 2, min: 1 }, // shelter: hay bales under a roof, 1 for every 2 (Defra para 2 and 20)
    rockLedges: true, // rock ledges to leap onto, one a lookout; walls 4 high (animals/goatRules.js, BALANCE.goat)
    petting: true, // with a keeper on its round the exhibit is a petting farm: guests like it a quarter more
    wildCoatEvents: ["minecraft:born_default", "minecraft:born_screamer"], // the game's goat events for each coat
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["White", "White"], // coat 1 is a screamer (the clipboard says so: goatRules.js screamLine)
    // Twins after about 5 months (2 park days; a Georgia study of 608 does: 150.6 days, 1.85 kids a litter), grown in 2.
    breeding: { litter: 2, gestationDays: 2, matureDays: 2, cooldownDays: 3, juvenileScale: 0.5, young: "kid", youngPlural: "kids" },
    names: ["Billy", "Nanny", "Heidi", "Alpine", "Edelweiss", "Scree", "Butterscotch", "Gruff", "Summit", "Dandelion", "Ibex", "Gizmo", "Tuppence", "Oatcake", "Granite", "Capricorn"],
  },
  // Camels (0.1.181, module 12: research/vanilla_plan.md "0.1.181 camels: the design"): the game's own as a zoo copy (its
  // look, sounds and its own now-and-then kneel; the calf drawn with the grown model, 0.1.172) kept in a desert exhibit: sand
  // underfoot over half the floor and shade over 6 blocks of floor for each (species.desert, animals/camelRules.js), and
  // Leafy Rations (hay and browse) from a Hay Rack, a Basic Feeder or an Elevated Browse Feeder. animals/camel.js takes them
  // into the shade at midday and kneels one on sand now and then for a dust bath. Let go, the game's own spawn_adult.
  "zoocraft:zoo_camel": {
    id: "zoocraft:zoo_camel",
    displayName: "Camel",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:camel", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_camel",
    family: "camel", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "desert",
    dietTags: ["leafy"],
    carrierProfile: "livestock",
    baitItem: "minecraft:cactus", // the game's camel follows a cactus
    baitAlso: ["zoocraft:leafy_ration"],
    baitText: "a cactus or a Leafy Ration",
    rack: true, // hay from a Hay Rack (Wild Welfare: "Camels should always have access to hay or grass")
    browsesEither: true, // and browse from a Basic Feeder or an Elevated Browse Feeder (spec 5.1 "browse feeders")
    observe: ["spot", "herd", "kneel"],
    where: "Deserts, one at a time",
    social: { minGroup: 2, recommendedMax: 10, prefersCompany: true }, // herd animals
    desert: true, // sand underfoot and shade (animals/camelRules.js, BALANCE.camel)
    bornTamed: true, // every one of the game's camels has minecraft:is_tamed from birth (anyone may saddle one): not a pet
    wildGrown: "minecraft:spawn_adult", // the game's camel spawns a calf 1 time in 20: let go, it comes out grown
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Sandy"],
    // One calf after about 13 months (5 park days), grown in 5.
    breeding: { litter: 1, gestationDays: 5, matureDays: 5, cooldownDays: 6, juvenileScale: 0.45, young: "calf", youngPlural: "calves" },
    names: ["Sahara", "Humphrey", "Oasis", "Mirage", "Caravan", "Dromedary", "Nomad", "Sirocco", "Dates", "Gobi", "Marrakesh", "Kalahari", "Atacama", "Sultan", "Cumin", "Timbuktu"],
  },
  // Sea turtles (0.1.183, module 12: research/vanilla_plan.md "0.1.183 sea turtles: the design"): the game's own as a zoo
  // copy (its look, swimming and crawling, sounds; the young drawn with the grown model at the server's 0.3, 0.1.172) kept on
  // a turtle beach: a pool with a dry sand beach beside it (USFWS 2019: water nine shell lengths by two shell widths for each,
  // 1.2 m deep), seagrass in the water to graze (the manatee's rule) and sand a few blocks from the water to nest in (the
  // crocodile's measure). Leafy Rations, or seagrass, from an Aquarium Feeder. animals/turtle.js walks a female carrying her
  // eggs up the beach at night to dig her nest and lay; animals/nursery.js keeps the Turtle Nest on the sand, the cracks as
  // the days pass, the hatchlings' sexes by the nest's warmth (sea turtles: warm, female) and the scute a young one sheds.
  "zoocraft:zoo_turtle": {
    id: "zoocraft:zoo_turtle",
    displayName: "Sea Turtle",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:turtle", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_turtle",
    family: "turtle", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "amphibious",
    habitatProfile: "turtle_beach",
    dietTags: ["leafy"],
    carrierProfile: "livestock", // a sea turtle travels out of the water, kept moist (USFWS 2019, transport)
    baitItem: "minecraft:seagrass", // the game's turtle follows seagrass
    baitAlso: ["zoocraft:leafy_ration"],
    baitText: "seagrass or a Leafy Ration",
    aquariumFeeder: true, // greens fed in the water, as the manatees' (and from nothing else)
    seaTurtle: true, // the nesting walk, the eggs on the sand, the scute (animals/turtle.js, turtleRules.js)
    seagrass: { perAnimal: 4, share: 0.3 }, // green turtles graze seagrass (the manatee's rule: columns for each, a share of the food)
    sandNest: { sites: 1, tsd: true }, // sand 2 to 5 blocks from the water (the crocodile's measure); the warmth sets the sex
    observe: ["spot", "beach", "nesting"],
    where: "Warm beaches, a few together: swimming in the shallows and crawling up onto the sand. At night a female comes ashore, digs a nest in the sand and lays her eggs. Harmless",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false }, // sea turtles live alone
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["swim", "forage"],
    coats: ["Green"],
    // 1 to 4 hatchlings (the game's clutch; a real one is about 100) after 3 park days in the sand, grown in 8 (sea turtles
    // grow slowly), rest 6 (a female nests every 2 to 4 years).
    breeding: { litter: 1, litterMax: 4, gestationDays: 3, matureDays: 8, cooldownDays: 6, juvenileScale: 0.3, young: "hatchling", youngPlural: "hatchlings" },
    names: ["Myrtle", "Leatherback", "Loggerhead", "Hawksbill", "Kemp", "Ridley", "Driftwood", "Tortuga", "Tidepool", "Morro", "Seashell", "Scute", "Wave", "Caretta", "Ningaloo", "Bermuda"],
  },
  // Frogs (0.1.184, module 12: research/vanilla_plan.md "0.1.184 frogs and tadpoles: the design"): the game's own as a zoo
  // copy (its look, hopping, swimming, croaking and leaps onto lily pads; its three looks by climate) kept in a frog pond:
  // the natterjack toad guideline's breeding enclosure (EAZA 2025: land 75%, water 25% and 20 cm deep, 8 to 20 toads in
  // about 7 square metres) at the game frog's size, lily pads on the water to sit on (the game's frog leaps onto them),
  // cover on land and Insect Rations on the land. Rain gets a pair mating sooner (the guideline's 2.4.1); she lays
  // frogspawn on the water (animals/nursery.js keeps the Frog Spawn there) and the young are tadpoles (the game's model,
  // swimming only), which graze the pond and grow into frogs with the look of the pond's climate (animals/frogRules.js).
  "zoocraft:zoo_frog": {
    id: "zoocraft:zoo_frog",
    displayName: "Frog",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:frog", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_frog",
    youngEntityType: "zoocraft:zoo_tadpole", // the young are tadpoles, a mob of their own as the game's are (one model each)
    family: "frog", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "amphibious",
    habitatProfile: "frog_pond",
    dietTags: ["insect"],
    carrierProfile: "small",
    baitItem: "zoocraft:insect_ration", // (the game's frog follows slimeballs too, but every bait is a food it eats)
    baitText: "an Insect Ration",
    lilyPads: true, // lily pads or big dripleaf on the water to sit on (animals/frogRules.js), which the tadpoles graze
    rainBreeds: true, // rain gets a pair mating sooner (the natterjack guideline: "rain" stimulates breeding)
    frogSpawn: true, // she lays frogspawn on the open water (animals/nursery.js), the young are tadpoles
    wildSpawnEvents: ["spawn_temperate", "spawn_cold", "spawn_warm"], // let go, the game's frog is spawned by the event for its look
    observe: ["spot", "lilypad", "frogleap"],
    where: "Swamps and mangrove swamps, a few together: hopping along the banks, swimming, leaping onto lily pads and big dripleaf, croaking. Orange where it's temperate, green where it's cold, white where it's warm. Harmless",
    social: { minGroup: 1, recommendedMax: 10, prefersCompany: true }, // kept together, males and females (the guideline's 2.3.1)
    cover: { minFraction: 0.2, why: "cover to hide under" }, // branches, bark and stones to hide among (the guideline's 2.1.3)
    rationUnitsPerParkDay: 1, // fed every 1 to 2 days (the guideline's 2.2.2)
    enrichmentTags: ["swim", "forage"],
    coats: ["Temperate", "Cold", "Warm"], // the game's minecraft:variant 0, 1, 2
    // Frogspawn on the water hatches in 2 park days into 2 to 6 tadpoles (the game's hatch), which grow into frogs in 4. A
    // tadpole is the game's own tadpole at full size (about half a frog's length: juvenileScale), a mob of its own.
    breeding: { litter: 2, litterMax: 6, gestationDays: 2, matureDays: 4, cooldownDays: 4, juvenileScale: 0.5, young: "tadpole", youngPlural: "tadpoles", tadpoles: true },
    names: ["Lily", "Croaker", "Pondweed", "Ribbit", "Bullrush", "Puddle", "Fen", "Natter", "Marsh", "Sedge", "Jumper", "Mangrove", "Pickerel", "Bog", "Peeper", "Duckweed"],
  },
  // Axolotls (0.1.185, module 12: research/vanilla_plan.md "0.1.185 axolotls: the design"): the game's own as a zoo copy (its
  // look, swimming and walking along the bottom, sounds; its five colours; the young drawn with the grown model at the
  // game's 0.5, 0.1.172) kept in an axolotl tank: the EAZA Amphibian TAG guideline for the Lake Patzcuaro salamander (a
  // densely planted aquarium, a bare or fine sand floor, never gravel), at the game axolotl's size. Insect Rations from an
  // Aquarium Feeder. She lays her eggs on the water plants (animals/axolotlRules.js); a young one takes a parent's colour,
  // or is blue 1 time in 1200 (the game's mutation).
  "zoocraft:zoo_axolotl": {
    id: "zoocraft:zoo_axolotl",
    displayName: "Axolotl",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:axolotl", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_axolotl",
    family: "axolotl", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "aquatic",
    habitatProfile: "axolotl_tank",
    dietTags: ["insect"],
    carrierProfile: "aquatic", // the Water Transport Tank (the game's bucket)
    baitItem: "zoocraft:insect_ration", // (the game's axolotl follows a bucket of tropical fish too, but every bait is a food it eats)
    baitText: "an Insect Ration",
    aquariumFeeder: true, // worms and shrimp fed in the water (the guideline's 2.2), from nothing else
    waterPlants: true, // seagrass or kelp in the water for cover, their enrichment and to lay on; no gravel (animals/axolotlRules.js)
    coatMutation: { coat: 4, chance: 0.00083 }, // a young one is blue 1 time in 1200 (the game's offspring mutation_factor)
    observe: ["spot", "bottom"],
    where: "Lush caves, under the water over clay, 4 to 6 together: walking along the bottom and swimming. Pink, brown, gold or cyan; a blue one is rare. Harmless to people",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false }, // no social structure (the guideline's 2.3)
    rationUnitsPerParkDay: 1, // adults fed every other day (the guideline's 2.2.3)
    enrichmentTags: [], // the water plants are their enrichment (hiding and foraging among them), as the manatees' seagrass
    coats: ["Pink", "Cyan", "Gold", "Brown", "Blue"], // the game's minecraft:variant 0 (lucy), 1 (cyan), 2 (gold), 3 (wild), 4 (blue)
    // One young (the game's) from eggs laid on the plants, hatched in 2 park days (the guideline: 2 to 3 weeks), grown in 5.
    breeding: { litter: 1, gestationDays: 2, matureDays: 5, cooldownDays: 4, juvenileScale: 0.5, young: "larva", youngPlural: "larvae" },
    names: ["Axel", "Lotl", "Xochi", "Rosado", "Gills", "Gilly", "Lucy", "Patzcuaro", "Xochimilco", "Frilly", "Nemo", "Ajolote", "Canal", "Dripleaf", "Clay", "Wiggles"],
  },
  // Dolphins (0.1.186, module 12: research/vanilla_plan.md "0.1.186 dolphins: the design"): the game's own as a zoo copy
  // (its look, swimming, breathing at the surface, leaps out of the water and swimming alongside a player; the calf drawn
  // with the grown model at the game's 0.65, 0.1.172) kept in a dolphin pool: the European Association for Aquatic
  // Mammals' standard (275 square metres of water for five, 75 more each, 3.5 m deep) and the US rules' narrowest width
  // (7.32 m), at the game dolphin's size (about 2.6 blocks long, life-size): its space is the water (the `dolphin_pool`
  // profile), with a stretch 8 by 8 and 4 deep and the water open to the air (animals/dolphinRules.js). Fish Rations from
  // an Aquarium Feeder. They live in pods: company matters.
  "zoocraft:zoo_dolphin": {
    id: "zoocraft:zoo_dolphin",
    displayName: "Dolphin",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:dolphin", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_dolphin",
    family: "dolphin", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "aquatic",
    habitatProfile: "dolphin_pool",
    dietTags: ["fish"],
    carrierProfile: "marine", // the Large Water Tank (Marine Husbandry), as the sharks and manatees
    baitItem: "zoocraft:fish_ration",
    baitAlso: ["minecraft:cod", "minecraft:salmon"], // the game's dolphin takes raw cod and salmon (its bribe items)
    baitText: "a Fish Ration, raw cod or raw salmon",
    aquariumFeeder: true, // fish fed in the water, from nothing else
    deepPool: true, // a stretch of water deep and wide enough, open to the air (animals/dolphinRules.js)
    wildGrowUp: "ageable_grow_up", // the game's dolphin's own grow-up event (one let go comes out grown)
    observe: ["spot", "dolphinleap", "alongside"],
    where: "Oceans that aren't frozen, in pods of a few: swimming fast near the surface, leaping out of the water and coming up to breathe. They swim alongside a swimming player. Harmless unless hit",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true }, // pods (the game's flocking: 4 to 8); never kept alone
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["swim", "forage"], // a Floating Toy in the pool (zoos give them balls and toys) and food to forage for (a Hanging Food Basket of Fish Rations: zoos give them fish in ice and feeding devices), and play; one kind alone (12 a day against the 15 they lose) let it run down on the test server (0.1.186)
    coats: ["Grey"],
    // One calf after a long wait (a bottlenose dolphin carries hers about a year); it stays by its mother. The game's calf
    // is drawn at 0.65 of a grown one (its dolphin_baby scale).
    breeding: { litter: 1, gestationDays: 5, matureDays: 6, cooldownDays: 7, juvenileScale: 0.65, young: "calf", youngPlural: "calves" },
    names: ["Clicker", "Bubblenet", "Delphi", "Squeak", "Azura", "Finn", "Seaspray", "Bottlenose", "Tursi", "Porpoise", "Surf", "Pod", "Blowhole", "Atlantis", "Whistle", "Dorsal"],
  },
  // Bees (0.1.187, module 12; research/vanilla_plan.md "0.1.187 bees: the design"): the game's own bee, kept in a bee
  // garden (animals/beeRules.js). The game flies it to its flowers, gives it nectar and takes it home to its hive, which
  // fills with honey; the zoo counts the flowers (its food) and the hives.
  "zoocraft:zoo_bee": {
    id: "zoocraft:zoo_bee",
    displayName: "Bee",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:bee", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_bee",
    family: "bee", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "aerial",
    habitatProfile: "bee_garden",
    flies: true, // the game's own hover flight (the copy keeps it); the garden is measured by floodAerial
    // The flowers are their food (beeGarden: with enough, all of it); short of them, Nectar Rations from a Nectar Feeder
    // (beekeepers feed sugar syrup when flowers are short).
    dietTags: ["nectar"],
    nectarFeeder: true,
    beeGarden: true, // the garden's flowers and hives (animals/beeRules.js)
    carrierProfile: "small",
    baitItem: "zoocraft:nectar_ration",
    // Nectar Rations only: the game's bee follows anyone holding one of its flowers (its tempt items), but a flower isn't
    // a ration (it would feed the moths too).
    baitText: "a Nectar Ration",
    observe: ["spot", "beeflower", "beenectar"],
    where: "Plains, sunflower plains, flower forests, meadows and cherry groves, where bee nests hang under the trees: by day they fly from flower to flower, sit in each a while gathering nectar and carry it home to the nest, which slowly fills with honey; at night and in the rain they stay inside. Harm one, or take honey with no campfire under the nest, and the whole nest comes out angry and stings; a wild bee that stings loses its stinger and dies",
    social: { minGroup: 3, recommendedMax: 12, prefersCompany: true }, // a colony: a hive's worth at least (the game's holds 3)
    rationUnitsPerParkDay: 1,
    enrichmentTags: [], // foraging the flowers is their enrichment (the manatees' way: a built feature, 0.1.185's lesson)
    coats: ["Honeybee"],
    // One young bee a day after mating, grown in a day (the game's baby bee grows up in a day). The game's baby is drawn at
    // 0.5 of a grown one (its bee_baby scale).
    breeding: { litter: 1, gestationDays: 1, matureDays: 1, cooldownDays: 2, juvenileScale: 0.5, young: "young bee", youngPlural: "young bees" },
    names: ["Buzz", "Beeswax", "Dancer", "Propolis", "Nectar", "Pollen", "Waggle", "Comb", "Mellie", "Queenie", "Honeycomb", "Lavender", "Hexa", "Zinnia", "Fuzz", "Apis"],
  },
  // Parrots (0.1.188, module 12; research/vanilla_plan.md "0.1.188 parrots: the design"): the game's own parrot, kept in a
  // parrot aviary (animals/parrot.js, parrotRules.js). The game flies it; the copy also flies from Perch to Perch, dances
  // while a jukebox near it plays and imitates the monsters near it (the game's own parrot does both by its engine).
  "zoocraft:zoo_parrot": {
    id: "zoocraft:zoo_parrot",
    displayName: "Parrot",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:parrot", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_parrot",
    family: "parrot", // the copy's own family (the game's are parrot_wild and parrot_tame: a shoulder takes parrot_tame)
    movementProfile: "aerial",
    habitatProfile: "parrot_aviary",
    flies: true, // the game's own fly movement and navigation (the copy keeps them); the aviary is measured by floodAerial
    dances: true, // to a jukebox, and imitates monsters (animals/parrot.js)
    // Seeds, the game's parrot food (wheat, beetroot, melon, pumpkin), or Fruit Rations: zoo parrots eat fruit, seeds and nuts.
    dietTags: ["seed", "fruit"],
    carrierProfile: "small",
    baitItem: "minecraft:wheat_seeds",
    baitAlso: ["minecraft:beetroot_seeds", "minecraft:melon_seeds", "minecraft:pumpkin_seeds"],
    baitText: "seeds",
    observe: ["spot", "dance", "imitate"],
    where: "Jungles, bamboo jungles and sparse jungles, one or two together: flying about the treetops and landing to rest, red, blue, green, cyan or grey. One near a monster imitates its sound, and they dance by a jukebox that's playing",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true }, // a flock (macaws pair for life within it)
    rationUnitsPerParkDay: 1,
    // A Hanging Food Basket (forage) and a Puzzle Feeder (manipulate: zoos give parrots foraging puzzles); and music, when
    // they dance to a jukebox.
    enrichmentTags: ["forage", "manipulate", "music"],
    coats: ["Red", "Blue", "Green", "Cyan", "Grey"], // the game's minecraft:variant 0 to 4
    // The game's parrots never breed: the zoo's do, as zoo macaws (2 to 4 eggs laid in a tree hollow, 24 to 28 days, fledged
    // at about 4 months: Monroe Zoo, Cougar Mountain Zoo): 1 or 2 eggs in a Nest Box (the owls'), hatched in 3 park days,
    // grown in 8. The game has no young parrot: a chick is a small grown one (0.6).
    breeding: { litter: 1, litterMax: 2, gestationDays: 3, matureDays: 8, cooldownDays: 8, juvenileScale: 0.6, young: "chick", youngPlural: "chicks", nestBox: true },
    names: ["Polly", "Rio", "Ara", "Blu", "Captain", "Cockatiel", "Squawk", "Cracker", "Macaw", "Lory", "Skye", "Rosella", "Papaya", "Toucan", "Jewel", "Kea"],
  },
  // Ocelots and cats (0.1.189, module 12: research/vanilla_plan.md "0.1.189 ocelots and cats: the design"): the game's own
  // as zoo copies (its models, skins, animations and sounds; the young drawn with the grown model, 0.1.172). Shy until
  // they trust (species.wary): a caught one runs from people until one feeds it raw cod or salmon (the game's trusting,
  // one time in three), and the record keeps it (animals/cats.js). They nap (species.naps: the game's nap; a cat round the
  // clock, an ocelot by day) and rest up on things (species.restSpots: an ocelot on a log, a cat on a chest, the foot of a
  // bed or a lit furnace; animals/catRules.js). Both keep creepers off as the game's do (their families ocelot and cat).
  "zoocraft:zoo_ocelot": {
    id: "zoocraft:zoo_ocelot",
    displayName: "Ocelot",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:ocelot", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_ocelot",
    family: "ocelot", // the vanilla family: the journal counts wild and zoo ones (and creepers keep away)
    movementProfile: "terrestrial",
    habitatProfile: "ocelot",
    // Zoo ocelots eat mice, rats, chicken and fish (SDZWA): Meat Rations or Fish Rations, or raw cod or salmon.
    dietTags: ["meat", "fish"],
    carrierProfile: "small",
    baitItem: "zoocraft:fish_ration",
    baitAlso: ["minecraft:cod", "minecraft:salmon", "zoocraft:meat_ration"], // the game's: raw cod or salmon
    baitText: "raw cod or salmon, or a Meat or Fish Ration",
    observe: ["spot", "nap", "trust"],
    where: "Jungles and bamboo jungles, one or two together, now and then with kittens. Shy: they run from people. They sleep by day and are about at dusk and at night. Feed one raw cod or salmon by hand and, one time in three, it trusts you. Creepers keep away from them",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false }, // a pair and their kittens at most: they live alone (SDZWA: adults rest 600 to 1200 m apart)
    cover: { minFraction: 0.3, why: "dense cover" },
    naps: true, // asleep from dawn to late afternoon (the copy's nap with a by-day filter)
    wary: true, // runs from people until it trusts (the game's trusting: raw cod or salmon)
    restSpots: { kind: "log", per: 1 }, // a log on the floor for each to lie up on (SDZWA: perching platforms, logs)
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["scent", "manipulate", "forage"], // a Scent Post (cats mark), a Puzzle Feeder, a Hanging Food Basket
    coats: ["Spotted"],
    // 1 or 2 kittens (SDZWA: "1-2 most often; rarely 3 or 4"; 79 to 85 days): after 3 park days, grown in 6.
    breeding: { litter: 1, litterMax: 2, gestationDays: 3, matureDays: 6, cooldownDays: 6, juvenileScale: 0.5, young: "kitten", youngPlural: "kittens" },
    names: ["Ocelotl", "Maracaja", "Chico", "Tito", "Selva", "Chispa", "Pinto", "Canela", "Mancha", "Tigrillo", "Dorado", "Bonita", "Sombra", "Rayo", "Pepita", "Yuca"],
  },
  "zoocraft:zoo_cat": {
    id: "zoocraft:zoo_cat",
    displayName: "Cat",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:cat", // a stray caught makes the zoo copy (the game's own look and voice)
    entityType: "zoocraft:zoo_cat",
    family: "cat", // the vanilla family: the journal counts wild and zoo ones (and creepers keep away)
    movementProfile: "terrestrial",
    habitatProfile: "cat_house",
    dietTags: ["meat", "fish"],
    carrierProfile: "small",
    baitItem: "zoocraft:fish_ration",
    baitAlso: ["minecraft:cod", "minecraft:salmon", "zoocraft:meat_ration"], // the game's: raw cod or salmon
    baitText: "raw cod or salmon, or a Meat or Fish Ration",
    observe: ["spot", "catnap", "sit"],
    where: "Villages (a cat for every few beds) and swamp huts (a black cat). Strays: they run from people. Feed one raw cod or salmon by hand and, one time in three, it's tamed: a tamed cat is someone's pet. They nap on and off all day and night, and sit on chests, beds and lit furnaces. Creepers keep away from them",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: true }, // up to 6 to a room (the shelter vets' figure)
    cover: { minFraction: 0.25, why: "a roofed corner to sleep in" },
    naps: true, // on and off round the clock, curled up and purring (the copy's own cycle)
    wary: true, // runs from people until it trusts (the game's: raw cod or salmon)
    restSpots: { kind: "seat", per: 2 }, // a chest, the foot of a bed or a lit furnace for each 2 (the game's tamed cats' places)
    soundVariants: true, // the game's two voices, classic and royal (its minecraft:sound_variant; the copy's zoocraft:sound_variant)
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["manipulate", "climb", "forage"], // a Puzzle Feeder, a Climbing Frame (a cat tree), a Hanging Food Basket
    // The game's minecraft:variant 0 to 10.
    coats: ["White", "Tuxedo", "Red", "Siamese", "British Shorthair", "Calico", "Persian", "Ragdoll", "Tabby", "All Black", "Jellie"],
    // 1 to 3 kittens (the game's one; real litters 2 to 5, 63 to 65 days): after 2 park days, grown in 4.
    breeding: { litter: 1, litterMax: 3, gestationDays: 2, matureDays: 4, cooldownDays: 4, juvenileScale: 0.4, young: "kitten", youngPlural: "kittens" },
    names: ["Clove", "Mittens", "Tom", "Jellie", "Chai", "Salem", "Smokey", "Binx", "Cleo", "Toulouse", "Tigger", "Misty", "Kipper", "Felix", "Pixel", "Oreo"],
  },
  // Armadillos (0.1.190, module 12: research/vanilla_plan.md "0.1.190 armadillos: the design"): the game's own as a zoo
  // copy (its model, skin, sounds and its own roll-up: the game's threat sensor, states, timers and events, so it rolls up
  // for a player sprinting or riding by, a hit or undead near it, peeks out and unrolls; the young drawn with the grown
  // model, 0.1.172), shedding a scute now and then and one more for a brush, as the game's. Sand underfoot
  // (species.sandFloor), a Burrow Shelter to sleep in, Burrow Soil to dig in, and in a snowy biome a fuelled Thermal
  // Regulator (species.coldWarmth: they can't keep themselves warm). animals/armadilloRules.js.
  "zoocraft:zoo_armadillo": {
    id: "zoocraft:zoo_armadillo",
    displayName: "Armadillo",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:armadillo", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_armadillo",
    family: "armadillo", // the vanilla family: the journal counts wild and zoo ones (and spiders keep off)
    movementProfile: "terrestrial",
    habitatProfile: "armadillo",
    // Zoo armadillos eat an insectivore diet, mealworms and crickets (San Diego Zoo, Louisville Zoo): Insect Rations, or
    // the game's spider eyes.
    dietTags: ["insect"],
    carrierProfile: "small",
    baitItem: "zoocraft:insect_ration",
    baitAlso: ["minecraft:spider_eye"], // the game's armadillo follows a spider eye
    baitText: "a spider eye or an Insect Ration",
    observe: ["spot", "rollup", "peek"],
    where: "Savannas (a few together) and badlands (one or two). Shy of a hurry: one rolls up into its shell when someone sprints or rides by, when it's hit, or when undead come near, peeks out now and then and unrolls once they've gone. Spiders keep away from them. A grown one sheds a scute now and then, and a brush gets one more",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false }, // "usually solitary but occasionally group together during cold weather" (ADW)
    den: "burrow", // a Burrow Shelter to sleep in (they rest in other animals' burrows; zoos give hides with straw)
    toys: ["soil"], // digs in Burrow Soil (animals/woodlandRules.js soilFixtures)
    sandFloor: { share: 0.3 }, // sand or red sand under three tenths of the floor (animals/armadilloRules.js)
    coldWarmth: true, // in a snowy biome, a fuelled Thermal Regulator (animals/armadilloRules.js)
    rollsUp: true, // the game's roll-up (the journal reads its state)
    wildGrown: "minecraft:spawn_adult", // the game's spawn makes a young one 1 time in 20: let go, it comes out grown
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["dig", "manipulate", "forage"], // Burrow Soil, a Puzzle Feeder (a ball and a box to explore), a Hanging Food Basket
    coats: ["Banded"],
    // One pup (the three-banded armadillo's one young after 120 days, ADW): after 4 park days, grown in 6, 0.6 the size
    // (the game's young).
    breeding: { litter: 1, gestationDays: 4, matureDays: 6, cooldownDays: 6, juvenileScale: 0.6, young: "pup", youngPlural: "pups" },
    names: ["Dillo", "Bolita", "Tatu", "Armando", "Mataco", "Rolo", "Bolo", "Chaco", "Pampa", "Quirquincho", "Pichi", "Tolypeutes", "Pelusa", "Caliche", "Mesa", "Tuco"],
  },
  // Mooshrooms (0.1.191, module 12; research/vanilla_plan.md "0.1.191 mooshrooms: the design"): the game's own, red or
  // brown, in the Farmyard with the farm animals and their hay bedding; mycelium to graze (animals/mooshroomRules.js).
  "zoocraft:zoo_mooshroom": {
    id: "zoocraft:zoo_mooshroom",
    displayName: "Mooshroom",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:mooshroom", // catching the wild one makes the zoo copy (the game's own look, red or brown)
    entityType: "zoocraft:zoo_mooshroom",
    family: "mushroomcow", // the vanilla family: the journal counts wild and zoo ones as its herd
    movementProfile: "terrestrial",
    habitatProfile: "farmyard",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat", // the game's mooshroom follows wheat
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "The Mushroom Fields, islands of mycelium and giant mushrooms out at sea, in herds of 4 to 8. Most are red: a lightning strike turns one brown, and a calf is now and then the other colour",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    mycelium: { perAnimal: 12, share: 0.5 }, // mycelium to graze, as cows graze grass (animals/mooshroomRules.js)
    hay: { per: 2, min: 2 }, // bedding: hay bales under a roof, 1 for every 2 in the yard (animals/farmRules.js)
    products: ["milk", "stew"],
    petting: true, // with a keeper on its round the yard is a petting farm: guests like it a quarter more
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Red", "Brown"], // the game's minecraft:variant 0 and 1, carried from the wild one
    coatMutation: { swap: true, chance: 0.00098 }, // a calf is the other colour 1 time in 1024 (the game's offspring deny_parents_variant)
    // Let go, the game's own comes out grown in its colour by its own events (its usual spawn rolls a calf 1 time in 20).
    wildSpawnEvents: ["minecraft:become_red_adult", "minecraft:become_brown_adult"],
    breeding: { litter: 1, gestationDays: 3, matureDays: 3, cooldownDays: 4, juvenileScale: 0.5, young: "calf", youngPlural: "calves" },
    names: ["Shroomie", "Inkcap", "Bolete", "Chanterelle", "Portobello", "Fungi", "Spore", "Cremini", "Enoki", "Shiitake", "Speckle", "Maitake", "Mycena", "Reishi", "Russula", "Amanita"],
  },
  // Sniffers (0.1.192, module 12; research/vanilla_plan.md "0.1.192 sniffers: the design"): the game's own as a zoo copy
  // (its model, skin, sounds and animations, and its own digging: the game's scenting timer, dig goal and events, so it
  // sniffs, digs up a torchflower seed or a pitcher pod and stands up again; the young drawn with the grown model, 0.1.172),
  // in a paddock of its own with ground to dig in underfoot (species.digBed). animals/snifferRules.js.
  "zoocraft:zoo_sniffer": {
    id: "zoocraft:zoo_sniffer",
    displayName: "Sniffer",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:sniffer", // catching the game's one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_sniffer",
    family: "sniffer", // the vanilla family: the journal counts the game's and the zoo's
    movementProfile: "terrestrial",
    habitatProfile: "medium_terrestrial",
    // The seeds they dig up (torchflower seeds and pitcher pods: the game's sniffer follows torchflower seeds) or Grain
    // Rations, from a Basic Feeder.
    dietTags: ["seed", "grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:torchflower_seeds",
    baitAlso: ["zoocraft:grain_ration"],
    baitText: "torchflower seeds or a Grain Ration",
    observe: ["spot", "seedsniff", "digup"],
    where: "Nowhere in the wild: an ancient animal, brought back from sniffer eggs brushed out of the suspicious sand in warm ocean ruins (an egg hatches in 10 minutes on moss, 20 elsewhere; a snifflet grows up in about 40). A grown one sniffs the air now and then, walks about nose down and digs up an ancient seed, a torchflower seed or a pitcher pod",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    digBed: { share: 0.5 }, // the ground the game's sniffer digs in under half the floor (animals/snifferRules.js)
    wildGrown: "minecraft:spawn_adult", // the game's spawn rolls a snifflet now and then: let go, it comes out grown
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage", "dig"], // a Hanging Food Basket, Burrow Soil
    coats: ["Mossy"],
    // One snifflet (the game's: one egg): after 4 park days, grown in 8 (the game's snifflet takes twice a calf's time),
    // 0.45 the size (the game's snifflet).
    breeding: { litter: 1, gestationDays: 4, matureDays: 8, cooldownDays: 6, juvenileScale: 0.45, young: "snifflet", youngPlural: "snifflets" },
    names: ["Sniffy", "Torchy", "Pitcher", "Seedling", "Fossil", "Snoot", "Relic", "Snorkel", "Trowel", "Loam", "Archie", "Mossie", "Spadey", "Gaia", "Sniffington", "Tuber"],
  },
  // Llamas, trader llamas and mules (0.1.193, module 12; research/vanilla_plan.md "0.1.193 llamas, trader llamas and mules:
  // the design"): the game's own as zoo copies (their look, size, walk and sounds; the young drawn with the grown model,
  // 0.1.172) in the Paddock with horses and donkeys. Llamas and trader llamas wear a carpet used on them (species.decor:
  // animals/llama.js) and spit at a wild wolf as the game's do; a trader llama is caught once it's off its trader's lead
  // (species.freeTamed: the game tames it then); mules have no foals (species.sterile), but a horse and a donkey sharing a
  // paddock can have one (species.crossBreed). Herd mates of other kinds count as company (species.herdWith).
  // animals/llamaRules.js.
  "zoocraft:zoo_llama": {
    id: "zoocraft:zoo_llama",
    displayName: "Llama",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:llama", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_llama",
    family: "llama", // the vanilla family: the journal counts wild and zoo ones (trader llamas too) as its herd
    movementProfile: "terrestrial",
    habitatProfile: "llama_paddock",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:hay_block", // the game's llama follows a hay bale
    baitAlso: ["minecraft:wheat", "zoocraft:grain_ration"],
    baitText: "a hay bale, wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "herd", "carpet"],
    where: "Savannas and windswept hills, in herds of 4 to 6",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true }, // Ohio State: other herd animals, preferably another llama
    herdWith: ["zoocraft:zoo_trader_llama"],
    graze: { perAnimal: 20, share: 0.5 },
    hay: { per: 2, min: 1 }, // a stable corner: a hay bale under a roof for every 2 (Lost Creek Llamas: 40 square feet each)
    decor: true, // wears a carpet used on it (zoocraft:decor)
    wildMount: true, // a wild one offers a ride, as a horse does: the crate's ride fix (main.js crateMounts)
    petting: true, // with a keeper on its round the paddock is a petting farm: guests like it a quarter more
    wildGrown: "minecraft:spawn_adult", // the game's spawn rolls a cria one time in ten: let go, it comes out grown
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Creamy", "White", "Brown", "Gray"], // the game's minecraft:variant 0-3
    // One cria after about 11 and a half months (4 park days), grown in 4.
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "cria", youngPlural: "crias" },
    names: ["Nilla", "Como", "Lima", "Andes", "Pablo", "Fuzzy", "Quinoa", "Tina", "Kuzco", "Inca", "Huacaya", "Bolivar", "Suri", "Cusco", "Llarry", "Alma"],
  },
  "zoocraft:zoo_trader_llama": {
    id: "zoocraft:zoo_trader_llama",
    displayName: "Trader Llama",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:trader_llama",
    entityType: "zoocraft:zoo_trader_llama",
    family: "trader_llama",
    movementProfile: "terrestrial",
    habitatProfile: "llama_paddock",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:hay_block",
    baitAlso: ["minecraft:wheat", "zoocraft:grain_ration"],
    baitText: "a hay bale, wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "herd", "onlead"],
    where: "Only with wandering traders, two on leads",
    social: { minGroup: 2, recommendedMax: 8, prefersCompany: true },
    herdWith: ["zoocraft:zoo_llama"],
    graze: { perAnimal: 20, share: 0.5 },
    hay: { per: 2, min: 1 },
    decor: true, // without a carpet it wears its trader's blanket
    freeTamed: true, // off its trader's lead the game tames it at once: caught then (transport/carriers.js)
    wildMount: true,
    petting: true,
    wildGrown: "minecraft:spawn_adult",
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Creamy", "White", "Brown", "Gray"],
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "cria", youngPlural: "crias" },
    names: ["Marco", "Polo", "Bazaar", "Sienna", "Topaz", "Silk", "Emerald", "Wander", "Rover", "Trinket", "Barter", "Satchel", "Indigo", "Tassel", "Ochre", "Pedlar"],
  },
  "zoocraft:zoo_mule": {
    id: "zoocraft:zoo_mule",
    displayName: "Mule",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:mule",
    entityType: "zoocraft:zoo_mule",
    family: "mule",
    movementProfile: "terrestrial",
    habitatProfile: "mule_paddock",
    dietTags: ["grain"],
    carrierProfile: "livestock",
    baitItem: "minecraft:wheat",
    baitAlso: ["zoocraft:grain_ration"],
    baitText: "some wheat or a Grain Ration",
    rack: true,
    observe: ["spot", "graze", "herd"],
    where: "Nowhere in the wild: the foal of a horse and a donkey",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: true },
    herdWith: ["zoocraft:zoo_horse", "zoocraft:zoo_donkey"], // World Horse Welfare: mules seem to prefer horses' company
    graze: { perAnimal: 20, share: 0.5 },
    hay: { per: 1, min: 1 }, // a stable corner: a hay bale under a roof for each, as a horse
    run: { length: 12, gallop: 0.5 }, // as a donkey's
    groom: true,
    sterile: true, // no foals of its own: a horse and a donkey have them (species.crossBreed)
    petting: true,
    wildGrown: "minecraft:spawn_adult",
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Brown"],
    breeding: { litter: 1, gestationDays: 4, matureDays: 4, cooldownDays: 5, juvenileScale: 0.5, young: "foal", youngPlural: "foals" },
    names: ["Molly", "Banjo", "Sarge", "Hinny", "Stubborn", "Maverick", "Pecos", "Otis", "Molasses", "Sawyer", "Waylon", "Bucky", "Hank", "Josie", "Hattie", "Sully"],
  },
  // Bats and allays (0.1.194, module 12; research/vanilla_plan.md "0.1.194 bats and allays: the design"): the game's own
  // as zoo copies (their models, skins, animations and sounds). The game flies both. Bats hang from the roof of a dark
  // house (species.batRoost: the zoo hangs them, animals/bat.js) and want a long straight flight (species.flight) and the
  // dark (lowLight); allays dance to a jukebox as parrots do (species.dances) and split in two when given an amethyst shard
  // while they dance (species.duplicates: animals/allay.js), the only way they have young.
  "zoocraft:zoo_bat": {
    id: "zoocraft:zoo_bat",
    displayName: "Bat",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:bat", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_bat",
    family: "bat", // the vanilla family: the journal counts wild and zoo ones as its colony
    movementProfile: "aerial",
    habitatProfile: "bat_house",
    flies: true, // the game's own float_wander (the copy keeps it); the house is measured by floodAerial
    batRoost: { per: 1 }, // a block of solid roof over open air for each to hang from (animals/batRules.js)
    flight: { length: 10 }, // a straight 10 blocks of open air: 8 wingspans (AZA Bat TAG), the game's bat spanning 1.2
    lowLight: true, // a dark house: out at any hour; in a bright one they hang all day (animals/bat.js)
    // Fruit, as zoos feed fruit bats (Seba's short-tailed bats: fruit, insects when it's short; Niabi Zoo: a variety of
    // fruit), or Insect Rations.
    dietTags: ["fruit", "insect"],
    carrierProfile: "small",
    baitItem: "zoocraft:fruit_ration",
    baitAlso: ["minecraft:sweet_berries", "minecraft:glow_berries", "zoocraft:insect_ration"],
    baitText: "a Fruit Ration, sweet or glow berries or an Insect Ration",
    observe: ["spot", "hang", "colony"],
    where: "Caves and dark places underground anywhere in the Overworld but the deep dark, in colonies of 8: flitting about squeaking, and hanging upside down from the ceiling to rest. They fly off when someone comes near",
    social: { minGroup: 3, recommendedMax: 12, prefersCompany: true }, // a colony (the game's spawn in 8s; zoos keep 10 to 100)
    rationUnitsPerParkDay: 0.5,
    enrichmentTags: ["forage"], // a Hanging Food Basket (zoos hang the fruit up)
    coats: ["Brown"],
    // The game's bats never breed: the zoo's do, as zoo fruit bats (Seba's: one pup after about 120 days, mature at 9 months
    // to a year, two litters a year): one pup after 4 park days, grown in 6. A pup is a small grown bat (0.6).
    breeding: { litter: 1, gestationDays: 4, matureDays: 6, cooldownDays: 6, juvenileScale: 0.6, young: "pup", youngPlural: "pups" },
    names: ["Moth", "Nightwing", "Rafter", "Belfry", "Fig", "Batty", "Chirp", "Marlo", "Corvina", "Tink", "Vlad", "Flapjack", "Radar", "Wingnut", "Nibbler", "Zuzu"],
  },
  "zoocraft:zoo_allay": {
    id: "zoocraft:zoo_allay",
    displayName: "Allay",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:allay",
    entityType: "zoocraft:zoo_allay",
    family: "allay",
    movementProfile: "aerial",
    habitatProfile: "allay_room",
    flies: true, // the game's own hover (the copy keeps it)
    dances: true, // to a jukebox, as parrots (animals/parrot.js; within BALANCE.allay.danceRadius)
    duplicates: true, // an amethyst shard while it dances: it splits in two (animals/allay.js); no sexes, no breeding
    noteBlock: true, // a note block in the room or its wall: enrichment (the copy has no vibration listener to hear one)
    // The game's allays eat nothing; the zoo gives them fruit, sweet and glow berries most of all (a game choice).
    dietTags: ["fruit"],
    carrierProfile: "small",
    baitItem: "zoocraft:fruit_ration",
    baitAlso: ["minecraft:sweet_berries", "minecraft:glow_berries"],
    baitText: "a Fruit Ration or sweet or glow berries",
    observe: ["spot", "dance", "carry"],
    where: "Shut in the dark oak cages by pillager outposts and in the cells of woodland mansions, 1 to 3 together, made with the world. They glow blue, hover about, dance to a jukebox, and bring whoever gave them an item more of the same",
    social: { minGroup: 1, recommendedMax: 8, prefersCompany: false },
    rationUnitsPerParkDay: 0.5,
    enrichmentTags: ["forage", "music", "notes"], // a Hanging Food Basket; dancing to a jukebox; a note block there
    coats: ["Blue"],
    names: ["Melody", "Chime", "Pixie", "Harmony", "Aria", "Bell", "Sprite", "Jingle", "Tempo", "Lyric", "Sky", "Allegro", "Sonata", "Treble", "Trill", "Lullaby"],
  },
  // Golems (0.1.195, module 12; research/vanilla_plan.md "0.1.195 iron, snow and copper golems: the design"): the game's
  // own as zoo copies (their models, skins, animations and sounds). Built, not born (species.built: no sexes, no young; build
  // another and catch it); they drink nothing (species.drinksNothing); the zoo keeps them in repair with iron or copper and
  // topped up with snow (a game choice: the game's eat nothing). Iron golems want village paving underfoot (mobFloor: the
  // game's keeps to those blocks), snow golems a roof over all of their yard (cover: rain melts the game's) and a biome
  // no warmer than 1.0 (species.melts), copper golems a copper chest and a chest to carry between (enrichment: species.
  // chestSorting); copper golems oxidise, are waxed and scraped, and turn into statues (species.copper: animals/
  // copperGolem.js). animals/golemRules.js.
  "zoocraft:zoo_iron_golem": {
    id: "zoocraft:zoo_iron_golem",
    displayName: "Iron Golem",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:iron_golem", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_iron_golem",
    family: "irongolem", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "terrestrial",
    habitatProfile: "iron_golem_yard",
    built: "iron", // built, not born: four iron blocks in a T and a carved pumpkin
    drinksNothing: true,
    // The game's iron golem keeps to its village's paths: dirt path, stone and planks (its preferred_path).
    mobFloor: { ids: ["minecraft:grass_path", "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:stone", "minecraft:stone_bricks", "minecraft:mossy_stone_bricks", "minecraft:cracked_stone_bricks", "minecraft:chiseled_stone_bricks", "minecraft:granite", "minecraft:polished_granite", "minecraft:diorite", "minecraft:polished_diorite", "minecraft:andesite", "minecraft:polished_andesite", "minecraft:sandstone", "minecraft:cut_sandstone", "minecraft:smooth_sandstone", "minecraft:red_sandstone", "minecraft:cut_red_sandstone", "minecraft:smooth_red_sandstone", "minecraft:oak_planks", "minecraft:spruce_planks", "minecraft:birch_planks", "minecraft:jungle_planks", "minecraft:acacia_planks", "minecraft:dark_oak_planks", "minecraft:brick_block"], share: 0.25, how: "village paving (dirt path, cobblestone, stone, stone bricks, bricks or planks)" },
    dietTags: ["iron"],
    carrierProfile: "large",
    baitItem: "minecraft:iron_ingot",
    baitAlso: ["minecraft:iron_nugget"],
    baitText: "an iron ingot or iron nuggets",
    observe: ["spot", "rounds"],
    where: "Villages (their defenders) and the cages by pillager outposts, or built by anyone: four iron blocks in a T with a carved pumpkin on top. They walk the village's paths, fling monsters and hold out a poppy to copper golems",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    wildGrown: "minecraft:from_player", // let go as one a player built: it never turns on players
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["manipulate"], // a Puzzle Feeder of iron nuggets to work, an Enrichment Ball to push about
    coats: ["Iron"],
    names: ["Bastion", "Ingot", "Forge", "Clank", "Bulwark", "Rampart", "Ferris", "Sentinel", "Patrol", "Rivet", "Girder", "Gauntlet", "Ironside", "Hammer", "Ferrum", "Colossus"],
  },
  "zoocraft:zoo_snow_golem": {
    id: "zoocraft:zoo_snow_golem",
    displayName: "Snow Golem",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:snow_golem",
    entityType: "zoocraft:zoo_snow_golem",
    family: "snowgolem",
    movementProfile: "terrestrial",
    habitatProfile: "snow_golem_yard",
    built: "snow", // two snow blocks and a carved pumpkin
    drinksNothing: true, // water melts the game's
    cover: { minFraction: 1, why: "a roof against the rain" }, // rain melts the game's: all of the yard
    melts: true, // in a biome warmer than 1.0 (deserts, badlands, savannas, the Nether) the game's melts: comfort capped
    dietTags: ["snow"],
    carrierProfile: "livestock",
    baitItem: "minecraft:snowball",
    baitAlso: ["minecraft:snow"],
    baitText: "a snowball or a snow block",
    observe: ["spot", "snowtrail"],
    where: "Never in the wild: built from two snow blocks with a carved pumpkin on top. They leave a trail of snow where it's cool enough and throw snowballs at monsters",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["manipulate"], // a Puzzle Feeder of snowballs, an Enrichment Ball
    coats: ["Snow"],
    names: ["Frosty", "Slush", "Crystal", "Powder", "Icicle", "Chilly", "Nippy", "Mitten", "Gourd", "Carver", "Cone", "Squash", "Frostbite", "Sherbet", "Flake", "Sleigh"],
  },
  "zoocraft:zoo_copper_golem": {
    id: "zoocraft:zoo_copper_golem",
    displayName: "Copper Golem",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:copper_golem",
    entityType: "zoocraft:zoo_copper_golem",
    family: "copper_golem",
    movementProfile: "terrestrial",
    habitatProfile: "copper_golem_yard",
    built: "copper", // a copper block and a carved pumpkin
    drinksNothing: true,
    copper: true, // oxidises, waxes, scrapes, turns into a statue (animals/copperGolem.js); its stage is its coat
    coatFrom: "oxidation", // the wild one's minecraft:oxidation_level (and its wax) come with it
    chestSorting: true, // a copper chest and a chest by the floor: enrichment ("sorting"), the game's transport_items
    dietTags: ["copper"],
    carrierProfile: "small",
    baitItem: "minecraft:copper_ingot",
    baitAlso: ["minecraft:copper_nugget"],
    baitText: "a copper ingot or copper nuggets",
    observe: ["spot", "chestsort"],
    where: "Built from a copper block with a carved pumpkin on top (the block turns into a copper chest); oxidized statues of them stand in abandoned camps (scrape one with an axe to bring it back). They carry items from copper chests to chests",
    social: { minGroup: 1, recommendedMax: 8, prefersCompany: false },
    // Let go: the game's own, as one a player built at its stage (its from_player_* events), waxed again if it was.
    wildSpawnEvents: ["minecraft:from_player_default", "minecraft:from_player_exposed", "minecraft:from_player_weathered", "minecraft:from_player_oxidized"],
    rationUnitsPerParkDay: 0.5,
    enrichmentTags: ["sorting"],
    coats: ["Copper", "Exposed", "Weathered", "Oxidized"], // its stage (zoocraft:oxidation)
    names: ["Patina", "Verdi", "Tinker", "Cogsworth", "Copperfield", "Bronzy", "Ohm", "Widget", "Kettle", "Thimble", "Cuppa", "Ampere", "Volt", "Lamplight", "Sorter", "Gadget"],
  },
  // The happy ghast and the nautilus (0.1.196, module 12; research/vanilla_plan.md "0.1.196 happy ghast and nautilus: the
  // design"): the game's own as zoo copies (their models, skins, animations and sounds). The game floats the ghast about
  // and stops it still under a player standing on its back; it isn't born (species.hatched: the game's hatch from a dried
  // ghast left in water) and wants the open sky (species.skyRoof: a glass roof over its Sky Pen). The nautilus is the game's
  // tame one swimming on its own, in a dim tank (lowLight: they live deep). animals/ghastRules.js, nautilusRules.js.
  "zoocraft:zoo_happy_ghast": {
    id: "zoocraft:zoo_happy_ghast",
    displayName: "Happy Ghast",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:happy_ghast", // catching the wild one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_happy_ghast",
    family: "happy_ghast", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "aerial",
    habitatProfile: "sky_pen",
    flies: true, // the game's own float about (the copy keeps it); the pen is measured by floodAerial
    hatched: true, // not born: the game's hatch from a dried ghast left in water, and can't be bred (no sexes, no young)
    bornTamed: true, // every one of the game's has minecraft:is_tamed (for its harness): one is caught like any other
    skyRoof: { minFraction: 0.5 }, // glass over half of the pen's roof or more: the open sky (the game's heal faster under it)
    dietTags: ["snow"], // the game's: ghastlings grow on snowballs, and every one follows a snowball
    carrierProfile: "large",
    baitItem: "minecraft:snowball",
    baitText: "a snowball",
    observe: ["spot", "skyfloat", "ghaststand"],
    where: "Never wild: a dried ghast block (from Nether fossils in soul sand valleys, or crafted from ghast tears and soul sand) left in water hatches into a ghastling in about 20 minutes, which grows up in 20 minutes or with 10 snowballs. They float about slowly, follow a snowball, and stop still while someone stands on their back",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    wildGrown: "minecraft:spawn_adult", // let go grown, unharnessed (its spawn rolls a ghastling one time in twenty)
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "manipulate"], // a Hanging Food Basket of snowballs, and a Puzzle Feeder of them to nudge (two kinds: one loses to the daily drain, the dolphins' lesson)
    coats: ["White"],
    names: ["Cumulus", "Mallow", "Drifty", "Hoverly", "Cloudy", "Stratus", "Hover", "Pillow", "Fogbank", "Snowcap", "Loft", "Daydream", "Floaty", "Overcast", "Skylark", "Altocumulus"],
  },
  "zoocraft:zoo_nautilus": {
    id: "zoocraft:zoo_nautilus",
    displayName: "Nautilus",
    plural: "Nautiluses",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:nautilus",
    entityType: "zoocraft:zoo_nautilus",
    family: "nautilus",
    movementProfile: "aquatic",
    habitatProfile: "nautilus_tank",
    nautilus: true, // the game's nautilus (animals/nautilusRules.js)
    lowLight: true, // a dim tank (Daw and Barord: "only enough light in the tank to view the animal")
    dietTags: ["fish"],
    carrierProfile: "aquatic", // the Water Transport Tank, as the axolotls
    baitItem: "minecraft:pufferfish", // the game's wild nautilus follows pufferfish (and is tamed with them)
    baitText: "a pufferfish",
    aquariumFeeder: true, // fish fed in the water, from nothing else
    observe: ["spot", "swim"],
    where: "Every ocean but the frozen ones (cold ones only deep), alone, between Y 38 and 58, a tenth of them young: swimming slowly, idling in the water, following pufferfish. Tamed with pufferfish they're someone's mount. A wild one hit, or hunting a pufferfish, charges",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false }, // solitary in the sea; aquariums keep a few
    wildGrown: "minecraft:spawn_wild_adult", // let go as the game's wild one, grown
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"], // food to find (a Hanging Food Basket of fish: aquariums give them crab and lobster molts)
    coats: ["Striped"],
    // One egg at a time (Daw and Barord: one or two a month, at least a year to hatch), a hatchling after 6 park days, grown
    // in 8. Drawn with the grown model at half size.
    breeding: { litter: 1, gestationDays: 6, matureDays: 8, cooldownDays: 6, juvenileScale: 0.5, young: "hatchling", youngPlural: "hatchlings" },
    names: ["Nautica", "Argo", "Ammonite", "Nereus", "Bathy", "Mollie", "Murex", "Conch", "Pelagia", "Trident", "Pompilius", "Fibonacci", "Chamber", "Jules", "Verne", "Septum"],
  },
  // Sulfur cubes (0.1.197, module 12; research/vanilla_plan.md "0.1.197 sulfur cube: the design"): the game's own as a zoo
  // copy (its model, skins, animations and sounds, its hop and its blocks: one picks up a block lying near it, or takes one
  // given, holds it inside and rolls as that block says, the game's archetypes; shears take it out), never taking TNT or a
  // magma block. Split, not born (species.splits): the game's large cube splits into two small ones when it dies, and zoo
  // animals never do. A Sulfur Cave with sulfur or cinnabar underfoot (species.sulfurFloor). animals/sulfurCubeRules.js.
  "zoocraft:zoo_sulfur_cube": {
    id: "zoocraft:zoo_sulfur_cube",
    displayName: "Sulfur Cube",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:sulfur_cube", // catching the game's large one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_sulfur_cube",
    family: "sulfur_cube", // the vanilla family: the journal counts wild and zoo ones
    movementProfile: "terrestrial",
    habitatProfile: "sulfur_cave",
    splits: true, // not born: the game's large cube splits into two small ones when it dies (no sexes, no young)
    absorbs: true, // the game's: it picks up or takes a block and holds it (zoocraft:sulfur_cube_archetype)
    sulfurFloor: { share: 0.5 }, // sulfur or cinnabar under half the floor or more: their caves' ground (animals/sulfurCubeRules.js)
    dietTags: ["slime"], // the game's small ones grow on slimeballs
    carrierProfile: "small",
    baitItem: "minecraft:slime_ball",
    baitText: "a slimeball",
    observe: ["spot", "cubehop", "cubeblock"],
    where: "Sulfur caves, underground under flat land (near swamps and deserts), 2 to 4 together, in any light. They hop about aimlessly, pick up a block lying near them (or take one you give them) and hold it inside: then they stop hopping and roll as the block says when you kick them, bouncing, sliding or floating. Shears take it out. Killed, a large one splits into two small ones, which grow in 20 minutes or sooner with slimeballs",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    wildGrown: "minecraft:spawn_medium", // let go as the game's large one, with no block (its spawn rolls a small one 1 time in 20)
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage", "manipulate"], // a Hanging Food Basket of slimeballs, and a Puzzle Feeder of them (two kinds: one loses to the daily drain)
    coats: ["Sulfur"],
    names: ["Brimley", "Gloop", "Wibble", "Cubert", "Sulphy", "Bouncer", "Blocko", "Quiver", "Gelatin", "Dicey", "Squish", "Squidge", "Custard", "Gumdrop", "Jiggles", "Vermilion"],
  },
  // The undead mounts (0.1.198, module 12; research/vanilla_plan.md "0.1.198 undead mounts: the design"): the game's
  // skeleton horse, zombie horse and camel husk as zoo copies (the game's grown one's model, skin, animations, sounds and
  // goals; the skeleton horse sinks and walks the bottom, the other two float). Zoo mobs (species.mob) with no serum
  // (species.undeadMount: alone each is calm, the game's are passive till a monster rides one): a Mob Cage takes one with no
  // monster on it (transport/carriers.js; its rider goes first), the bait in your inventory, after Mob Taming research. A
  // stable pen beside a Mob House's hall (mob_pen_stable: 120 blocks of floor for the first, 40 more each, 4 of headroom;
  // skeleton and zombie horses share one, the Undead Stable). Never bred: the game's undead mounts have no foals.
  // animals/undeadMountRules.js.
  "zoocraft:zoo_skeleton_horse": {
    id: "zoocraft:zoo_skeleton_horse",
    displayName: "Skeleton Horse",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:skeleton_horse", // the Mob Cage on the game's one makes the zoo copy (the game's own look)
    entityType: "zoocraft:zoo_skeleton_horse",
    family: "zoo_skeleton_horse",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen_stable",
    mob: true,
    undeadMount: true, // no serum: calm alone; a monster riding it goes first
    wildMount: true, // a wild one offers a ride: the cage's ride fix (main.js crateMounts) sets the rider down and catches it
    bornTamed: true, // every one of the game's has minecraft:is_tamed from birth (anyone can ride one): not a pet
    // Bone Rations (bones and bone meal) from a Basic Feeder, as the zoo's skeletons (the game's eats nothing).
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "riderless"],
    where: "Only from a skeleton trap: in a thunderstorm lightning now and then leaves a skeleton horse standing alone on the surface, and when you come within 10 blocks more lightning turns it into four skeleton horsemen. Defeat a rider, then use a Mob Cage on its horse (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // A crypt floor under a third of the floor (the zoo's skeletons').
    mobFloor: { ids: ["minecraft:bone_block", "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:cobbled_deepslate", "minecraft:gravel"], share: 0.3, how: "a crypt floor (bone blocks, cobblestone, mossy cobblestone, cobbled deepslate or gravel)" },
    wildGrown: "minecraft:spring_trap", // let go as the game's grown one (its spawn rolls a foal 1 time in 5; the trap's grown one)
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Skeleton"],
    names: ["Rattlehoof", "Marrowmane", "Ossie", "Clatterhoof", "Grimgallop", "Bonejangles", "Dustmane", "Spectre", "Tombstone", "Wishbone", "Femura", "Hollowhoof", "Ivorymane", "Wraithhoof", "Calcifer", "Thunderbone"],
  },
  "zoocraft:zoo_zombie_horse": {
    id: "zoocraft:zoo_zombie_horse",
    displayName: "Zombie Horse",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:zombie_horse",
    entityType: "zoocraft:zoo_zombie_horse",
    family: "zoo_zombie_horse",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen_stable",
    mob: true,
    undeadMount: true,
    wildMount: true, // a wild one offers a ride (to tame it): the cage's ride fix sets the rider down and catches it
    // Red mushrooms (the game's zombie horse follows one and is healed by it) or Fungal Rations, from a Basic Feeder.
    dietTags: ["fungus", "mushroom"],
    carrierProfile: "mob",
    baitItem: "minecraft:red_mushroom",
    baitAlso: ["zoocraft:fungal_ration"],
    baitText: "a red mushroom or a Fungal Ration",
    observe: ["spot", "riderless"],
    where: "Plains, snowy plains and savannas at night, one at a time, as a zombie horseman's mount (a zombie with a spear riding it). Defeat its rider, then use a Mob Cage on the horse (Mob Taming research). One a player tamed is theirs",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // The dark (the zoo's zombies': the game's burns in the sun) and graveyard earth under half the floor.
    lowLight: true,
    mobFloor: { ids: ["minecraft:dirt", "minecraft:coarse_dirt", "minecraft:podzol", "minecraft:dirt_with_roots", "minecraft:mud"], share: 0.5, how: "graveyard earth (dirt, coarse dirt, podzol, rooted dirt or mud)" },
    wildGrown: "minecraft:spawn_adult", // let go as the game's wild grown one, no rider
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Zombie"],
    names: ["Rotgallop", "Moldmane", "Shambletrot", "Mouldhoof", "Gangrene", "Lichenmane", "Swampy", "Rigormane", "Mossflank", "Grubhoof", "Fester", "Ghoulhoof", "Pallor", "Murkmane", "Creeping Ivy", "Nightmare"],
  },
  "zoocraft:zoo_camel_husk": {
    id: "zoocraft:zoo_camel_husk",
    displayName: "Camel Husk",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:camel_husk",
    entityType: "zoocraft:zoo_camel_husk",
    family: "zoo_camel_husk",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen_stable",
    mob: true,
    undeadMount: true,
    wildMount: true, // a wild one offers a ride: the cage's ride fix
    bornTamed: true, // every one of the game's has minecraft:is_tamed from birth (anyone can saddle one): not a pet
    kneels: true, // now and then it kneels down to rest, as the zoo camel (animals/camel.js; the game's sitting goal does nothing for a copy)
    // Meat Rations, as the husks that ride it; a rabbit's foot (the game's: it follows one and is healed by it) too.
    dietTags: ["meat", "rabbit_foot"],
    carrierProfile: "mob",
    baitItem: "minecraft:rabbit_foot",
    baitAlso: ["zoocraft:meat_ration"],
    baitText: "a rabbit's foot or a Meat Ration",
    observe: ["spot", "riderless", "kneel"],
    where: "Deserts at night, one at a time, as a camel husk jockey's mount (a husk in front, a parched with a bow behind). Defeat both riders, then use a Mob Cage on the camel husk (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // Desert ground under half the floor (sand, red sand, sandstone of any cut).
    mobFloor: { ids: ["minecraft:sand", "minecraft:red_sand", "minecraft:sandstone", "minecraft:cut_sandstone", "minecraft:chiseled_sandstone", "minecraft:smooth_sandstone", "minecraft:red_sandstone", "minecraft:cut_red_sandstone", "minecraft:chiseled_red_sandstone", "minecraft:smooth_red_sandstone"], share: 0.5, how: "desert ground (sand, red sand or sandstone of any cut)" },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Husk"],
    names: ["Mummy", "Dunebone", "Sandwraith", "Khamsin", "Parchment", "Tutan", "Ramses", "Dustbowl", "Scarabaeus", "Wraithhump", "Khepri", "Anubis", "Simoom", "Withered", "Ossuary", "Haboob"],
  },
  // Husks and zombie villagers (0.1.199, module 12; research/vanilla_plan.md "0.1.199 husks and zombie villagers: the
  // design"): zoo mobs the zombie's way (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage
  // to a pen beside a Mob House's hall (mob_pen). A husk likes desert ground (the camel husk's) and needs no dark (it never
  // burns in the sun); a zombie villager likes the zombie's graveyard earth and the dark, shares the Crypt with zombies and
  // skeletons, and keeps its job (coats: the game's minecraft:variant 0 to 14) and its home's clothes (marks, markNames:
  // minecraft:mark_variant 0 to 6) when calmed (animals/mobRules.js lookEvents) and caught.
  "zoocraft:zoo_husk": {
    id: "zoocraft:zoo_husk",
    displayName: "Husk",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_husk",
    mobSource: "minecraft:husk",
    entityType: "zoocraft:zoo_husk",
    family: "zoo_husk",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations from a Basic Feeder, as the zombie.
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Deserts at night: most of the zombies there are husks, in groups of 2 to 4 (one rides in front on a camel husk jockey, a parched behind it). Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Desert ground under half the floor (the camel husk's); no dark: a husk never burns in the sun.
    mobFloor: { ids: ["minecraft:sand", "minecraft:red_sand", "minecraft:sandstone", "minecraft:cut_sandstone", "minecraft:chiseled_sandstone", "minecraft:smooth_sandstone", "minecraft:red_sandstone", "minecraft:cut_red_sandstone", "minecraft:chiseled_red_sandstone", "minecraft:smooth_red_sandstone"], share: 0.5, how: "desert ground (sand, red sand or sandstone of any cut)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Husk"],
    names: ["Gritmaw", "Duneshade", "Sandlurch", "Sunbake", "Tombsand", "Cracklip", "Driftgrit", "Ashdune", "Mummer", "Harmattan", "Grittle", "Dryrot", "Scorchy", "Sandshamble", "Cracklehide", "Dunegroan"],
  },
  "zoocraft:zoo_zombie_villager": {
    id: "zoocraft:zoo_zombie_villager",
    displayName: "Zombie Villager",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_zombie_villager",
    mobSource: "minecraft:zombie_villager_v2",
    entityType: "zoocraft:zoo_zombie_villager",
    family: "zoo_zombie_villager",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld, now and then in place of zombies (2 to 4 of them); in abandoned villages, caged in an igloo's basement, and a villager a zombie kills may rise as one (half the time on Normal, always on Hard). Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research). Cured instead (a golden apple while it has Weakness) it is a villager again",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The zombie's dark and graveyard earth.
    lowLight: true,
    mobFloor: { ids: ["minecraft:dirt", "minecraft:coarse_dirt", "minecraft:podzol", "minecraft:dirt_with_roots", "minecraft:mud"], share: 0.5, how: "graveyard earth (dirt, coarse dirt, podzol, rooted dirt or mud)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // Its job (the game's minecraft:variant, in the game's order) and its home's clothes (minecraft:mark_variant).
    coats: ["Unemployed", "Farmer", "Fisherman", "Shepherd", "Fletcher", "Librarian", "Cartographer", "Cleric", "Armorer", "Weaponsmith", "Toolsmith", "Butcher", "Leatherworker", "Stone Mason", "Nitwit"],
    marks: true,
    markNames: ["the plains", "the desert", "the jungle", "the savanna", "the snow", "the swamp", "the taiga"],
    names: ["Hrumph", "Barterby", "Mumbles", "Grumbold", "Haggle", "Emeraldo", "Plowshare", "Quillstub", "Quillby", "Anvilda", "Lecterna", "Smithers", "Grindle", "Bellhop", "Hrmmond", "Nitwick"],
  },
  // The drowned and the zombie nautilus (0.1.200, module 12; research/vanilla_plan.md "0.1.200 the drowned and the zombie
  // nautilus: the design"): the Mob House's first water pen (mob_pen_water: a tank beside the hall, its space the water). The
  // drowned is a zoo mob the zombie's way (0.1.163: weakened, a Passivity Serum, a Mob Cage), walking the bottom as the
  // game's does by day; the sea floor under half its floor (the foot of the water counts, and the bank: mobFloor.underWater)
  // and the dark. The zombie nautilus is an undead mount (0.1.198: no serum, calm alone; caught once its drowned is gone),
  // swimming only, its look kept (the game's property minecraft:variant "coral" is coat 1: species.coatFrom "coral"); the
  // dark; Fish Rations from an Aquarium Feeder. They share a pen (the Sunken Crypt).
  "zoocraft:zoo_drowned": {
    id: "zoocraft:zoo_drowned",
    displayName: "Drowned",
    plural: "Drowned",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_drowned",
    mobSource: "minecraft:drowned",
    entityType: "zoocraft:zoo_drowned",
    family: "zoo_drowned",
    movementProfile: "amphibious",
    habitatProfile: "mob_pen_water",
    mob: true,
    // Meat Rations from a Basic Feeder on the bank, as the zombie.
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "In water in the dark (block light 0): oceans in groups of 2 to 4, rivers one at a time, and dripstone caves; a zombie that stays under water too long becomes one. By day they keep to the bottom. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The zombie's dark, and the sea floor under half the floor (the bottom of the water and the bank).
    lowLight: true,
    mobFloor: { ids: ["minecraft:sand", "minecraft:gravel", "minecraft:clay"], share: 0.5, how: "the sea floor (sand, gravel or clay)", underWater: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Drowned"],
    names: ["Soggy", "Bloater", "Brineby", "Davy", "Jonesy", "Gurgle", "Waterlog", "Bilgewater", "Jetsam", "Sodden", "Drippy", "Mossjaw", "Saltrot", "Brackish", "Squelch", "Marooner"],
  },
  "zoocraft:zoo_zombie_nautilus": {
    id: "zoocraft:zoo_zombie_nautilus",
    displayName: "Zombie Nautilus",
    plural: "Zombie Nautiluses",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "minecraft:zombie_nautilus",
    entityType: "zoocraft:zoo_zombie_nautilus",
    family: "zoo_zombie_nautilus",
    movementProfile: "aquatic",
    habitatProfile: "mob_pen_water",
    mob: true,
    undeadMount: true, // a drowned's mount: no serum, calm alone (animals/undeadMountRules.js)
    lowLight: true,
    // Fish Rations from an Aquarium Feeder over the water (a pufferfish coaxes one: the game's follows fish and is tamed
    // with pufferfish).
    dietTags: ["fish"],
    aquariumFeeder: true,
    carrierProfile: "mob",
    baitItem: "minecraft:pufferfish",
    baitAlso: ["zoocraft:fish_ration"],
    baitText: "a pufferfish or a Fish Ration",
    observe: ["spot", "riderlessSwim"],
    where: "Oceans in the dark, only under a drowned: half the grown drowned holding a trident (outside rivers) ride one; in warm shallow oceans it is the coral kind. Defeat its rider, then use a Mob Cage on the zombie nautilus (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Its look, the game's (minecraft:variant "default" or "coral": coral grows on its shell).
    coatFrom: "coral",
    coats: ["Plain", "Coral"],
    names: ["Rotshell", "Wreckling", "Wreckbone", "Grimspiral", "Tidewrack", "Coralrot", "Shipwreck", "Ghostshell", "Drudge", "Rustcoil", "Sinker", "Bonewhorl", "Kelpgrip", "Hollowshell", "Ballast", "Barnacleback"],
  },
  // The skeleton kin (0.1.201, module 12; research/vanilla_plan.md "0.1.201 strays, bogged, parched and wither skeletons:
  // the design"): zoo mobs the skeleton's way (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a
  // Mob Cage to a pen beside a Mob House's hall (mob_pen), Bone Rations. Strays like frozen ground; bogged swamp ground
  // and mushrooms, and keep their sheared look (coat 1: the game's is_sheared; animals/mobRules.js lookEvents); parched
  // the husk's desert ground and share the Desert Tomb with husks (the camel husk jockey's two); wither skeletons a
  // fortress floor and the dark.
  "zoocraft:zoo_stray": {
    id: "zoocraft:zoo_stray",
    displayName: "Stray",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_stray",
    mobSource: "minecraft:stray",
    entityType: "zoocraft:zoo_stray",
    family: "zoo_stray",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Snowy places at night, out under the open sky (snowy plains, ice spikes, frozen rivers, snowy slopes, the frozen and jagged peaks), in place of most of the skeletons there, one or two at a time; a skeleton kept in powder snow turns into one. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Frozen ground under half the floor.
    mobFloor: { ids: ["minecraft:snow", "minecraft:packed_ice", "minecraft:blue_ice", "minecraft:ice"], share: 0.5, how: "frozen ground (snow blocks, packed ice, blue ice or ice)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Stray"],
    names: ["Frostbone", "Rimebone", "Frostjaw", "Snowskull", "Frostrattle", "Hoarfrost", "Chilblain", "Permafrost", "Wintermarrow", "Brrr", "Wintergrave", "Frostgrin", "Icerib", "Coldsnap", "Glaze", "Numbskull"],
  },
  "zoocraft:zoo_bogged": {
    id: "zoocraft:zoo_bogged",
    displayName: "Bogged",
    plural: "Bogged",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_bogged",
    mobSource: "minecraft:bogged",
    entityType: "zoocraft:zoo_bogged",
    family: "zoo_bogged",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Swamps and mangrove swamps at night, on the surface (under thick mangrove leaves even by day), in place of some of the skeletons there, one or two at a time; and the spawners of trial chambers. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research). One sheared of its mushrooms stays bare",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Swamp ground under half the floor, and 3 or more mushrooms in the pen.
    mobFloor: { ids: ["minecraft:mud", "minecraft:muddy_mangrove_roots", "minecraft:clay"], share: 0.5, how: "swamp ground (mud, muddy mangrove roots or clay)" },
    mobDecor: { ids: ["minecraft:brown_mushroom", "minecraft:red_mushroom"], min: 3, how: "mushrooms (brown or red)", where: "planted on the floor, as they grow in a swamp" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Its look, kept from the wild: its mushrooms, or sheared (minecraft:variant 0 or 1; coat 1 the game's is_sheared).
    coats: ["Mossy", "Sheared"],
    names: ["Mossbones", "Mirebones", "Mosscap", "Mirejaw", "Bogwort", "Sporeskull", "Mudrattle", "Mycel", "Shroomy", "Peatbones", "Fenrattle", "Mildewbone", "Murkbone", "Sludgy", "Fenbone", "Sporejaw"],
  },
  "zoocraft:zoo_parched": {
    id: "zoocraft:zoo_parched",
    displayName: "Parched",
    plural: "Parched",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_parched",
    mobSource: "minecraft:parched",
    entityType: "zoocraft:zoo_parched",
    family: "zoo_parched",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Deserts at night, out under the open sky, in place of a third of the skeletons there, one or two at a time; one rides behind the husk on a camel husk jockey. It never burns in the sun. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The husk's desert ground under half the floor; no dark: a parched never burns in the sun.
    mobFloor: { ids: ["minecraft:sand", "minecraft:red_sand", "minecraft:sandstone", "minecraft:cut_sandstone", "minecraft:chiseled_sandstone", "minecraft:smooth_sandstone", "minecraft:red_sandstone", "minecraft:cut_red_sandstone", "minecraft:chiseled_red_sandstone", "minecraft:smooth_red_sandstone"], share: 0.5, how: "desert ground (sand, red sand or sandstone of any cut)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Parched"],
    names: ["Sunbleach", "Dustrattle", "Bleachbone", "Scorchrib", "Dryskull", "Dunejaw", "Sandrattle", "Sunjaw", "Brittle", "Dryrib", "Desiccus", "Chalky", "Kilnbone", "Saltbone", "Crispin", "Sunrattle"],
  },
  "zoocraft:zoo_wither_skeleton": {
    id: "zoocraft:zoo_wither_skeleton",
    displayName: "Wither Skeleton",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_wither_skeleton",
    mobSource: "minecraft:wither_skeleton",
    entityType: "zoocraft:zoo_wither_skeleton",
    family: "zoo_wither_skeleton",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Nether fortresses only, two or three at a time at light 7 or less (and a wither calls up a few when it is hurt below half). Fire and lava don't hurt them, and a hit from their stone sword withers you. Weaken one to a quarter of its health, then use a Passivity Serum on it (Mob Taming research); a Mob Cage carries it home through a portal",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // A fortress floor under half the floor, and the dark (no daylight, nothing brighter than light 7).
    lowLight: true,
    mobFloor: { ids: ["minecraft:nether_brick", "minecraft:red_nether_brick", "minecraft:cracked_nether_bricks", "minecraft:chiseled_nether_bricks"], share: 0.5, how: "a fortress floor (nether bricks of any kind)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Wither Skeleton"],
    names: ["Coalbones", "Ashrib", "Soot", "Charnel", "Cinderskull", "Blackrib", "Witherby", "Ashjaw", "Cinderrib", "Netherbone", "Sootjaw", "Fortressa", "Grimrib", "Skullduggery", "Blackguard", "Ashgrin"],
  },
  // The small arthropods (0.1.202, module 12; research/vanilla_plan.md "0.1.202 cave spiders, silverfish and endermites:
  // the design"): zoo mobs the spider's way (0.1.164). A weakened one calmed by a Passivity Serum (its wildSource), a
  // Mob Cage to a pen beside a Mob House's hall (mob_pen). Cave spiders the spider's dark and cobwebs, sharing the Spider
  // Den with spiders; silverfish the stone they hide in; endermites End ground and Chorus Browse.
  "zoocraft:zoo_cave_spider": {
    id: "zoocraft:zoo_cave_spider",
    displayName: "Cave Spider",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_cave_spider",
    mobSource: "minecraft:cave_spider",
    entityType: "zoocraft:zoo_cave_spider",
    family: "zoo_cave_spider",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Abandoned mineshafts, round the monster spawners among the cobwebs (light 0); in sulfur caves every spider is a cave spider; and the spawners of trial chambers. Their bite poisons. Weaken one to a quarter of its health (3 of 12), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The spider's dark (nothing brighter than light 4 on the floor) and 3 or more cobwebs.
    lowLight: true,
    darkLight: 4,
    mobDecor: { ids: ["minecraft:web"], min: 3, how: "cobwebs", where: "hung in the corners and along the walls, as round a mineshaft's spawner; cave spiders walk through them" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Cave Spider"],
    names: ["Venom", "Scurry", "Nibs", "Fangs", "Bluebite", "Minecrawl", "Toxie", "Shafter", "Railrunner", "Timbers", "Pinch", "Crevice", "Webbie", "Lurkling", "Spinneret", "Minnie"],
  },
  "zoocraft:zoo_silverfish": {
    id: "zoocraft:zoo_silverfish",
    displayName: "Silverfish",
    plural: "Silverfish",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_silverfish",
    mobSource: "minecraft:silverfish",
    entityType: "zoocraft:zoo_silverfish",
    family: "zoo_silverfish",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations: starch, the real silverfish's food.
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Hidden in infested blocks (stone, cobblestone, deepslate and stone bricks that break too quickly): in strongholds, underground in mountains and windswept hills, in igloo basements and woodland mansions; and the spawner of a stronghold's portal room and the spawners of trial chambers. Hit one and more break out round it. Weaken one to a quarter of its health (2 of 8: punch it, a sword kills it), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The stone they hide in under half the floor (an infested block of it counts too); no dark: they come out of the
    // stone in any light.
    mobFloor: { ids: ["minecraft:stone", "minecraft:cobblestone", "minecraft:deepslate", "minecraft:stone_bricks", "minecraft:mossy_stone_bricks", "minecraft:cracked_stone_bricks", "minecraft:chiseled_stone_bricks", "minecraft:infested_stone", "minecraft:infested_cobblestone", "minecraft:infested_deepslate", "minecraft:infested_stone_bricks", "minecraft:infested_mossy_stone_bricks", "minecraft:infested_cracked_stone_bricks", "minecraft:infested_chiseled_stone_bricks"], share: 0.5, how: "the stone they hide in (stone, cobblestone, deepslate or stone bricks of any kind)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Silverfish"],
    names: ["Silvie", "Starch", "Wriggle", "Crumb", "Bookworm", "Sterling", "Papercut", "Flour", "Quicksilver", "Shimmy", "Bristletail", "Silvertail", "Nook", "Cranny", "Teaspoon", "Scales"],
  },
  "zoocraft:zoo_endermite": {
    id: "zoocraft:zoo_endermite",
    displayName: "Endermite",
    origin: "vanilla",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:calm_endermite",
    mobSource: "minecraft:endermite",
    entityType: "zoocraft:zoo_endermite",
    family: "zoo_endermite",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Chorus Browse, the End's food (the Voidling's).
    dietTags: ["chorus"],
    carrierProfile: "mob",
    baitItem: "zoocraft:chorus_browse",
    baitText: "Chorus Browse",
    observe: ["spot", "mobcalm"],
    where: "Where an ender pearl a player throws lands, now and then (1 in 20). It vanishes after two minutes unless it is named (a Name Tag keeps it), and endermen hunt them. Weaken one to a quarter of its health (2 of 8: punch it, a sword kills it), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // End ground under half the floor.
    mobFloor: { ids: ["minecraft:end_stone", "minecraft:end_bricks", "minecraft:purpur_block", "minecraft:purpur_pillar"], share: 0.5, how: "End ground (end stone, end stone bricks or purpur)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Endermite"],
    names: ["Pearlie", "Mite", "Blinky", "Pearlbug", "Pearly", "Blip", "Glitch", "Phaser", "Twitch", "Fizz", "Speck", "Plum", "Teleporta", "Voidbug", "Smidge", "Jitter"],
  },
  // The slime and the magma cube (0.1.203, module 12; research/vanilla_plan.md "0.1.203 slimes and magma cubes: the
  // design"): zoo mobs the spider's way (0.1.164). A weakened one calmed by a Passivity Serum (its wildSource; a small one
  // at 1 health as it is), a Mob Cage to a pen beside a Mob House's hall (mob_pen). Each keeps its size from the wild
  // (the game's minecraft:variant 1, 2 or 4: coat 0, 1 or 2, coatFrom "size"; animals/mobRules.js MOB_LOOKS sizes). Slimes
  // want swamp ground and eat slimeballs (the sulfur cube's food: the game's jelly grows on them); magma cubes want Nether
  // ground and eat magma cream (the game's: a slimeball and blaze powder, the magma cube's own jelly).
  "zoocraft:zoo_slime": {
    id: "zoocraft:zoo_slime",
    displayName: "Slime",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_slime",
    mobSource: "minecraft:slime",
    entityType: "zoocraft:zoo_slime",
    family: "zoo_slime",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["slime"],
    carrierProfile: "mob",
    baitItem: "minecraft:slime_ball",
    observe: ["spot", "mobcalm"],
    where: "Swamps and mangrove swamps at night (light 7 or less; most on a full moon, none on a new moon), and deep underground below y 40 in one chunk in ten (slime chunks), in any light; and the spawners of some trial chambers. They hop straight at you and hurt you by touch (the small ones don't). Killed, a large one splits into 2 to 4 medium ones and a medium one into small ones. Weaken one to a quarter of its health (4 of 16 for a large one; punch a medium one down to 1 of 4: a sword splits it), then use a Passivity Serum on it (Mob Taming research); a small one (1 health) calms as it is. It keeps its size, small, medium or large",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Swamp ground under half the floor (the bogged's: where they come out at night). No dark: underground they come in any light.
    mobFloor: { ids: ["minecraft:mud", "minecraft:muddy_mangrove_roots", "minecraft:clay"], share: 0.5, how: "swamp ground (mud, muddy mangrove roots or clay)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Its size, kept from the wild (minecraft:variant 1, 2 or 4).
    coatFrom: "size",
    coats: ["Small", "Medium", "Large"],
    names: ["Blobby", "Goo", "Splodge", "Jello", "Bounce", "Gelato", "Limey", "Ooze", "Plop", "Glooper", "Splat", "Gummy", "Sproing", "Blorp", "Globule", "Dollop"],
  },
  "zoocraft:zoo_magma_cube": {
    id: "zoocraft:zoo_magma_cube",
    displayName: "Magma Cube",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_magma_cube",
    mobSource: "minecraft:magma_cube",
    entityType: "zoocraft:zoo_magma_cube",
    family: "zoo_magma_cube",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["magma"],
    carrierProfile: "mob",
    baitItem: "minecraft:magma_cream",
    observe: ["spot", "mobcalm"],
    where: "The Nether, in any light: most in basalt deltas, fewer in the nether wastes and fortresses; and the spawners of a treasure bastion. They hop high and straight at you (a large one 4 blocks up) and hurt you by touch; fire, lava and falls never hurt them, and they swim up through lava. Killed, a large one splits into 2 to 4 medium ones and a medium one into small ones. Weaken one to a quarter of its health (4 of 16 for a large one; punch a medium one down to 1 of 4: a sword splits it), then use a Passivity Serum on it (Mob Taming research); a small one (1 health) calms as it is. It keeps its size, small, medium or large",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // Nether ground under half the floor (the basalt deltas' and the nether wastes').
    mobFloor: { ids: ["minecraft:netherrack", "minecraft:basalt", "minecraft:polished_basalt", "minecraft:smooth_basalt", "minecraft:blackstone", "minecraft:magma"], share: 0.5, how: "Nether ground (netherrack, basalt of any kind, blackstone or magma blocks)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coatFrom: "size",
    coats: ["Small", "Medium", "Large"],
    names: ["Magmo", "Lavalamp", "Searbelly", "Hotshot", "Fizzwick", "Cinderblock", "Simmer", "Spitfire", "Embertoe", "Flarecube", "Glowcore", "Hotfoot", "Firecracker", "Molty", "Scald", "Fondue"],
  },
  // The witch (0.1.204, module 12; research/vanilla_plan.md "0.1.204 the witch: the design"): a zoo mob the zombie's way
  // (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage to a pen beside a Mob House's hall
  // (mob_pen). It likes a swamp hut's floor or swamp ground and a cauldron in the pen (its hut has one), needs no dark (it
  // never burns in the sun), and eats Grain Rations. It never throws or drinks a potion in the zoo; now and then purple
  // sparkles rise over its hat, as the game's witch's.
  "zoocraft:zoo_witch": {
    id: "zoocraft:zoo_witch",
    displayName: "Witch",
    plural: "Witches",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_witch",
    mobSource: "minecraft:witch",
    entityType: "zoocraft:zoo_witch",
    family: "zoo_witch",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Anywhere dark in the Overworld (block light 0), one at a time: not in mushroom fields, the deep dark, rivers, frozen rivers or snowy plains. One lives in each swamp hut (with a black cat) and more come to it; they come with raids from the fourth wave; and a villager that lightning strikes turns into one. Weaken one to a quarter of its health (6.5 of 26: be quick, a hurt witch drinks a Potion of Healing), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // A swamp hut's floor (spruce planks) or swamp ground under half the floor, and a cauldron (the hut's), no dark.
    mobFloor: { ids: ["minecraft:spruce_planks", "minecraft:mud", "minecraft:muddy_mangrove_roots", "minecraft:clay"], share: 0.5, how: "a swamp hut's floor or swamp ground (spruce planks, mud, muddy mangrove roots or clay)" },
    mobDecor: { ids: ["minecraft:cauldron"], min: 1, how: "cauldrons", where: "on the floor or set in a wall, as in a swamp hut" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Witch"],
    names: ["Agatha", "Grizelda", "Morgana", "Nettle", "Belladonna", "Hexley", "Cackla", "Wartwhistle", "Brewella", "Mandrake", "Henbane", "Toadflax", "Cauldra", "Bramblewick", "Mugwort", "Elspeth"],
  },
  // The phantom (0.1.205, module 12; research/vanilla_plan.md "0.1.205 the phantom: the design"): a zoo mob the zombie's
  // way (0.1.163), flown by script. A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage to a tall dark
  // pen beside a Mob House's hall (mob_pen_sky). It never lands: it circles under the pen's roof and swoops down over the
  // floor every 10 to 20 seconds, as the game's phantom swoops (animals/mobFlight.js: the game's own goals sit it at the
  // roof). The dark (it burns in daylight in the wild), and Meat Rations. It never bites in the zoo.
  "zoocraft:zoo_phantom": {
    id: "zoocraft:zoo_phantom",
    displayName: "Phantom",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_phantom",
    mobSource: "minecraft:phantom",
    entityType: "zoocraft:zoo_phantom",
    family: "zoo_phantom",
    movementProfile: "aerial",
    habitatProfile: "mob_pen_sky",
    mob: true,
    mobFlight: true,
    // Meat Rations from a Basic Feeder (it bites).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The night sky over the Overworld, 1 to 4 at a time (more on harder difficulties), over a player who hasn't slept in a bed (or died) for three days or more and has nothing but open sky over them. They circle high and swoop down every 10 to 20 seconds to bite, and burn in the daylight; cats and ocelots keep them off. Weaken one to a quarter of its health (5 of 20: hit it as it swoops), then use a Passivity Serum on it as it swoops again (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // The dark: no daylight in the pen and nothing brighter than light 7 (the nocturnal house's test; comfort capped in light).
    lowLight: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Phantom"],
    names: ["Insomnia", "Moonglide", "Skreech", "Wraithwing", "Drowsy", "Starless", "Swoopy", "Snooze", "Yawn", "Bedtime", "Grimwing", "Somnus", "Morpheus", "Hypnos", "Restless", "Sleepless"],
  },
  // The piglins (0.1.206, module 12; research/vanilla_plan.md "0.1.206 piglins, piglin brutes and zombified piglins: the
  // design"): zoo mobs the zombie's way (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage
  // to a pen beside a Mob House's hall (mob_pen). Each keeps the weapon it held in the wild (its coat: `gear`, the item
  // in its hand) and any golden armour it wore (`gold`: animals/gold.js), and never uses them; none ever turns into a
  // zombified piglin. Piglins barter for a gold ingot, as the game's, want a bastion's or crimson forest's ground and gold
  // in the pen, and share the Bastion with brutes (a bastion's floor); zombified piglins the Nether wastes' ground, and
  // fire never hurts them. Meat Rations.
  "zoocraft:zoo_piglin": {
    id: "zoocraft:zoo_piglin",
    displayName: "Piglin",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_piglin",
    mobSource: "minecraft:piglin",
    entityType: "zoocraft:zoo_piglin",
    family: "zoo_piglin",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations from a Basic Feeder (they pick up and eat porkchops).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The Nether: crimson forests and the Nether wastes, 3 or 4 at a time (light 7 or less), and the bastion remnants, where they live. They leave you be while you wear a piece of golden armour, and barter for gold ingots; hit one, open a chest or break gold near them and they all come for you. Out of the Nether they shake and turn into zombified piglins after 15 seconds. Weaken one to a quarter of its health (4 of 16), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // A bastion's or crimson forest's ground under half the floor, and gold in the pen (a bastion's treasure room).
    mobFloor: { ids: ["minecraft:blackstone", "minecraft:polished_blackstone", "minecraft:polished_blackstone_bricks", "minecraft:cracked_polished_blackstone_bricks", "minecraft:chiseled_polished_blackstone", "minecraft:gilded_blackstone", "minecraft:crimson_nylium"], share: 0.5, how: "a bastion's or crimson forest's ground (blackstone of any kind, gilded blackstone or crimson nylium)" },
    mobDecor: { ids: ["minecraft:gold_block"], min: 1, how: "blocks of gold", where: "piglins love gold: a bastion's treasure room is full of it" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    // Its weapon, kept from the wild (the item in its hand; animals/mobRules.js MOB_LOOKS gear), and golden armour.
    coats: ["Golden Sword", "Crossbow", "Golden Spear"],
    gear: ["minecraft:golden_sword", "minecraft:crossbow", "minecraft:golden_spear"],
    gold: true,
    barter: true,
    names: ["Goldsnout", "Bartholomew", "Bastia", "Crimsy", "Oinkley", "Gildy", "Bauble", "Grunter", "Shiny", "Swinella", "Bling", "Snoutbert", "Ducat", "Doubloon", "Gleamy", "Sovereign"],
  },
  "zoocraft:zoo_piglin_brute": {
    id: "zoocraft:zoo_piglin_brute",
    displayName: "Piglin Brute",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_piglin_brute",
    mobSource: "minecraft:piglin_brute",
    entityType: "zoocraft:zoo_piglin_brute",
    family: "zoo_piglin_brute",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Bastion remnants only, a few in some of their rooms, there from the start and never more (no new ones come). They swing a golden axe, go for you whatever you wear and never take gold. Out of the Nether they turn into zombified piglins after 15 seconds. Weaken one to a quarter of its health (12 of 50), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    mobFloor: { ids: ["minecraft:blackstone", "minecraft:polished_blackstone", "minecraft:polished_blackstone_bricks", "minecraft:cracked_polished_blackstone_bricks", "minecraft:chiseled_polished_blackstone", "minecraft:gilded_blackstone"], share: 0.5, how: "a bastion's floor (blackstone of any kind or gilded blackstone)" },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Golden Axe"],
    gear: ["minecraft:golden_axe"],
    names: ["Brutus", "Hogmaul", "Ironhide", "Grimsnout", "Axeley", "Gorehide", "Thudd", "Cleaver", "Hackley", "Maulsby", "Bonecrush", "Grunthor", "Smasher", "Tuskgard", "Bludgeon", "Hewley"],
  },
  "zoocraft:zoo_zombified_piglin": {
    id: "zoocraft:zoo_zombified_piglin",
    displayName: "Zombified Piglin",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_zombified_piglin",
    mobSource: "minecraft:zombie_pigman",
    entityType: "zoocraft:zoo_zombified_piglin",
    family: "zoo_zombified_piglin",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations (rotten flesh, as a zombie's).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The Nether wastes, crimson forests and Nether fortresses, 2 to 4 at a time; in the Overworld beside Nether portals, from a pig that lightning strikes, and from a piglin or brute that leaves the Nether. They leave you be till you hit one: then every one near it comes for you. Fire and lava never hurt them. Weaken one to a quarter of its health (5 of 20), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    mobFloor: { ids: ["minecraft:netherrack", "minecraft:nether_gold_ore", "minecraft:quartz_ore", "minecraft:crimson_nylium"], share: 0.5, how: "the Nether wastes' ground (netherrack, nether gold ore or nether quartz ore, or crimson nylium)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Golden Sword", "Golden Spear", "Crossbow", "Golden Axe"],
    gear: ["minecraft:golden_sword", "minecraft:golden_spear", "minecraft:crossbow", "minecraft:golden_axe"],
    gold: true,
    names: ["Rotsnout", "Zpig", "Gnarl", "Blight", "Porkrot", "Sallow", "Mange", "Grubsnout", "Ashtusk", "Moldchop", "Lurchley", "Wastrel", "Sourham", "Festus", "Zigby", "Grisle"],
  },
  // The hoglin and the zoglin (0.1.207, module 12; research/vanilla_plan.md "0.1.207 the hoglin and the zoglin: the
  // design"): zoo mobs the zombie's way (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage
  // to a pen beside a Mob House's hall (mob_pen); none ever turns into a zoglin. Hoglins live in herds on a crimson
  // forest's ground with crimson fungus growing, eat Fungal Rations (the zoo's crimson-fungus food) and breed (mobBreeds:
  // the one monster the game breeds, with crimson fungus: a baby hoglin); zoglins keep a pen to themselves on the Nether's
  // ground, eat Meat Rations, and fire never hurts them.
  "zoocraft:zoo_hoglin": {
    id: "zoocraft:zoo_hoglin",
    displayName: "Hoglin",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_hoglin",
    mobSource: "minecraft:hoglin",
    entityType: "zoocraft:zoo_hoglin",
    family: "zoo_hoglin",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Fungal Rations from a Basic Feeder (the game's hoglins eat crimson fungus, and breed with it).
    dietTags: ["fungus"],
    carrierProfile: "mob",
    baitItem: "zoocraft:fungal_ration",
    observe: ["spot", "mobcalm"],
    where: "The Nether's crimson forests, 3 or 4 at a time (any light), and the hoglin stables of bastion remnants. They charge you and knock you back, but back away from warped fungus, Nether portals and respawn anchors. Out of the Nether they shake and turn into zoglins after 15 seconds. Weaken one to a quarter of its health (10 of 40), then use a Passivity Serum on it (Mob Taming research)",
    // A herd (the game's come 3 or 4 together): alone they're uneasy.
    social: { minGroup: 2, recommendedMax: 6, prefersCompany: true },
    // A crimson forest's ground under half the floor, and the crimson fungus they root for growing in it.
    mobFloor: { ids: ["minecraft:crimson_nylium"], share: 0.5, how: "a crimson forest's ground (crimson nylium)" },
    mobDecor: { ids: ["minecraft:crimson_fungus"], min: 2, how: "crimson fungi growing", where: "they root about for it in the crimson forests, and the game's breed with it" },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Hoglin"],
    // The game's: one baby a pair, half the size, grown in 20 minutes (the zoo's park days).
    mobBreeds: true,
    breeding: { litter: 1, gestationDays: 2, matureDays: 3, cooldownDays: 3, juvenileScale: 0.5, young: "baby hoglin", youngPlural: "baby hoglins" },
    names: ["Bristleback", "Hogsworth", "Trufflehog", "Snortimer", "Ruddy", "Brisket", "Hogarth", "Tuskany", "Porkins", "Rootley", "Crimsonhoof", "Nylia", "Snoutcrimson", "Hogwart", "Boarbara", "Snortle"],
  },
  "zoocraft:zoo_zoglin": {
    id: "zoocraft:zoo_zoglin",
    displayName: "Zoglin",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_zoglin",
    mobSource: "minecraft:zoglin",
    entityType: "zoocraft:zoo_zoglin",
    family: "zoo_zoglin",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations (rotten flesh, as a zombie's).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Only from a hoglin taken out of the Nether: after 15 seconds it shakes and turns into a zoglin (none spawn on their own). They go for you and any mob near them but creepers and other zoglins, and knock you back. Fire and lava never hurt them. Weaken one to a quarter of its health (10 of 40), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // The Nether's ground they knew as hoglins under half the floor.
    mobFloor: { ids: ["minecraft:netherrack", "minecraft:crimson_nylium"], share: 0.5, how: "the Nether's ground (netherrack or crimson nylium)" },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Zoglin"],
    names: ["Rotfang", "Grimtusk", "Mouldy", "Ghoulhog", "Zog", "Rancid", "Snarl", "Gnash", "Bonehog", "Decay", "Sickle", "Rotbristle", "Zombo", "Gristletusk", "Sourtusk", "Grimbo"],
  },
  // The blaze and the ghast (0.1.208, module 12; research/vanilla_plan.md "0.1.208 the blaze and the ghast: the design"):
  // zoo mobs the zombie's way (0.1.163). A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage to a pen
  // beside a Mob House's hall. Blazes walk (the game's wander over the ground with no target) on a Nether fortress's
  // floor (mob_pen), eat Ember Rations (the zoo's fire food) and drink lava, never water (water hurts the game's).
  // Ghasts float (the game's float_wander: mobFloats) in the tall ghast pen (mob_pen_ghast: the Sky Pen's room) over the
  // Nether's ground, alone or a few, and eat Meat Rations. Fire never hurts either; neither ever shoots in the zoo.
  "zoocraft:zoo_blaze": {
    id: "zoocraft:zoo_blaze",
    displayName: "Blaze",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_blaze",
    mobSource: "minecraft:blaze",
    entityType: "zoocraft:zoo_blaze",
    family: "zoo_blaze",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Ember Rations from a Basic Feeder (the zoo's fire food: charcoal and blaze powder in it).
    dietTags: ["ember"],
    carrierProfile: "mob",
    baitItem: "zoocraft:ember_ration",
    observe: ["spot", "mobcalm"],
    where: "Nether fortresses, 1 to 3 at a time, in light 11 or less, and from the fortresses' blaze spawners. They shoot volleys of three fireballs that set you alight and float up after you; water, rain and snowballs hurt them, fire and lava never. Weaken one to a quarter of its health (5 of 20), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // A Nether fortress's floor under half the pen's.
    mobFloor: { ids: ["minecraft:nether_brick", "minecraft:cracked_nether_bricks", "minecraft:chiseled_nether_bricks"], share: 0.5, how: "a Nether fortress's floor (nether bricks, cracked or chiseled)" },
    // Lava to drink from a Lava Trough, not water (rain and water hurt the game's).
    drinksLava: true,
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Blaze"],
    names: ["Pyro", "Fumes", "Inferno", "Rodney", "Rodrick", "Searing", "Sootly", "Fervor", "Pyrrha", "Hotrod", "Blazewick", "Rodsworth", "Whirligig", "Flamel", "Firebrand", "Volcana"],
  },
  "zoocraft:zoo_ghast": {
    id: "zoocraft:zoo_ghast",
    displayName: "Ghast",
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_ghast",
    mobSource: "minecraft:ghast",
    entityType: "zoocraft:zoo_ghast",
    family: "zoo_ghast",
    movementProfile: "aerial",
    habitatProfile: "mob_pen_ghast",
    mob: true,
    // It floats with the game's own float_wander, no gravity (the zoo's happy ghast's way): never flown by script.
    mobFloats: true,
    // Meat Rations from a Basic Feeder.
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The Nether wastes, soul sand valleys and basalt deltas, always alone, in any light. They float high, crying, and shoot fireballs at you from far off (a fireball hit back at one kills it); fire and lava never hurt them. Weaken one to a quarter of its health (2.5 of 10: weak hits, an arrow or two), then use a Passivity Serum on it when it floats close (Mob Taming research)",
    // Always alone in the wild: a few at most.
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // The Nether's ground under half of the pen they float over.
    mobFloor: { ids: ["minecraft:netherrack", "minecraft:soul_sand", "minecraft:soul_soil", "minecraft:basalt", "minecraft:blackstone"], share: 0.5, how: "the Nether's ground (netherrack, soul sand, soul soil, basalt or blackstone)" },
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Ghast"],
    names: ["Wailer", "Weepy", "Boohoo", "Sobsworth", "Teardrop", "Moaner", "Sniffles", "Ghastly", "Mope", "Blubber", "Lament", "Phantasma", "Whimper", "Banshee", "Tentaclus", "Dolor"],
  },
  // The enderman and the shulker (0.1.209, module 12; research/vanilla_plan.md "0.1.209 the enderman and the shulker: the
  // design"): zoo mobs the zombie's way (0.1.163), from the End. A weakened one calmed by a Passivity Serum (its
  // wildSource), a Mob Cage to a pen beside a Mob House's hall (mob_pen: the enderman is 2.9 tall, the pen's 3 of
  // headroom), Chorus Browse (the endermite's). Endermen walk the End's ground and now and then blink to another spot of
  // their pen (enderBlink: animals/ender.js; the game's own teleport would take them out). Shulkers never move: they sit
  // on an End city's floor and peek out of their shells (the client's), and keep their colour from the wild (coats: the
  // game's minecraft:variant 0 to 16 in the game's order, 16 undyed; animals/mobRules.js MOB_LOOKS); the test zoo's pair
  // are undyed and lime (seedCoats).
  "zoocraft:zoo_enderman": {
    id: "zoocraft:zoo_enderman",
    displayName: "Enderman",
    plural: "Endermen",
    origin: "vanilla",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:calm_enderman",
    mobSource: "minecraft:enderman",
    entityType: "zoocraft:zoo_enderman",
    family: "zoo_enderman",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // It blinks about its pen now and then (the game's random teleports, kept inside it).
    enderBlink: true,
    // Chorus Browse, the End's food (the endermite's).
    dietTags: ["chorus"],
    carrierProfile: "mob",
    baitItem: "zoocraft:chorus_browse",
    baitText: "Chorus Browse",
    observe: ["spot", "mobcalm"],
    where: "Everywhere in the End, in groups of 4; in the Overworld's dark (light 0), 1 or 2 at a time; in the Nether's warped forests (most), Nether wastes and soul sand valleys, alone. Look one in the eyes and it comes for you (not while you wear a carved pumpkin on your head); arrows never hit one, it teleports away, and water hurts it. Weaken one to a quarter of its health (10 of 40), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // The End's ground under half the floor.
    mobFloor: { ids: ["minecraft:end_stone", "minecraft:end_bricks", "minecraft:obsidian"], share: 0.5, how: "the End's ground (end stone, end stone bricks or obsidian)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Enderman"],
    names: ["Gangle", "Pearlman", "Endora", "Starer", "Longshanks", "Shadowstep", "Warpy", "Glance", "Voidwalker", "Purplex", "Endwin", "Stalk", "Spindleshanks", "Tallulah", "Nightstride", "Gazer"],
  },
  "zoocraft:zoo_shulker": {
    id: "zoocraft:zoo_shulker",
    displayName: "Shulker",
    origin: "vanilla",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:calm_shulker",
    mobSource: "minecraft:shulker",
    entityType: "zoocraft:zoo_shulker",
    family: "zoo_shulker",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    dietTags: ["chorus"],
    carrierProfile: "mob",
    baitItem: "zoocraft:chorus_browse",
    baitText: "Chorus Browse",
    observe: ["spot", "mobcalm"],
    where: "End cities, out on the End's outer islands (through an End gateway): on their walls and in their End ships, shut to look like purpur. Shut, one shrugs off most hits; it opens to shoot bullets that home in on you and make you float up. Weaken one to a quarter of its health (7.5 of 30: hit it while it is open), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // An End city's floor under half the pen's.
    mobFloor: { ids: ["minecraft:purpur_block", "minecraft:purpur_pillar", "minecraft:end_bricks"], share: 0.5, how: "an End city's floor (purpur blocks, purpur pillars or end stone bricks)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    // Its colour (the game's minecraft:variant, in the game's order; 16 undyed, the purpur one every wild shulker has).
    coats: ["Black", "Red", "Green", "Brown", "Blue", "Purple", "Cyan", "Light Gray", "Gray", "Pink", "Lime", "Yellow", "Light Blue", "Magenta", "Orange", "White", "Undyed"],
    // The test zoo's pair: undyed and lime.
    seedCoats: [16, 10],
    names: ["Lidsworth", "Peekaboo", "Boxy", "Clamshell", "Hatch", "Cubby", "Pandora", "Locker", "Peeky", "Coffer", "Shutter", "Snapper", "Casket", "Chesty", "Purpurina", "Lidia"],
  },
  // The pillager, the vindicator, the evoker and the vex (0.1.210, module 12; research/vanilla_plan.md "0.1.210 the
  // pillager, the vindicator, the evoker and the vex: the design"): zoo mobs the zombie's way (0.1.163), the illagers and
  // the evoker's vex. A weakened one calmed by a Passivity Serum (its wildSource), a Mob Cage to a pen beside a Mob
  // House's hall (mob_pen), Grain Rations; all four share the Illager Camp (exhibits/mixing.js) on an outpost's or a
  // mansion's floor. Each keeps the game's gear (the entities': a crossbow, an iron axe stowed, an iron sword); a captain
  // its ominous banner (coats: the game's minecraft:variant, 1 a captain; animals/mobRules.js MOB_LOOKS). The vex hovers
  // (mobHovers: the zoo's allay's hover, its collision kept) and never fades away.
  "zoocraft:zoo_pillager": {
    id: "zoocraft:zoo_pillager",
    displayName: "Pillager",
    // Its look: a plain one or a captain with its ominous banner (the game's variant 0 or 1).
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_pillager",
    mobSource: "minecraft:pillager",
    entityType: "zoocraft:zoo_pillager",
    family: "zoo_pillager",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder (the bread of the villages they raid).
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Patrols of 2 to 5 led by a captain with an ominous banner, anywhere in the Overworld after the fifth day (light 7 or less); pillager outposts, up to 8 at a time; raids. They shoot crossbow bolts from up to 8 blocks off. Weaken one to a quarter of its health (6 of 24), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // An outpost's or a woodland mansion's floor under half the pen's.
    mobFloor: { ids: ["minecraft:dark_oak_planks", "minecraft:birch_planks", "minecraft:cobblestone"], share: 0.5, how: "an outpost's or a woodland mansion's floor (dark oak planks, birch planks or cobblestone)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Pillager", "Captain"],
    names: ["Bolt", "Quarrel", "Raider", "Crossley", "Marauder", "Plunder", "Looter", "Scowl", "Grimley", "Outpost", "Brigand", "Sneer", "Harrow", "Pillage", "Ransack", "Boltworth"],
  },
  "zoocraft:zoo_vindicator": {
    id: "zoocraft:zoo_vindicator",
    displayName: "Vindicator",
    // Its look: a plain one or a captain with its ominous banner (the game's variant 0 or 1).
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_vindicator",
    mobSource: "minecraft:vindicator",
    entityType: "zoocraft:zoo_vindicator",
    family: "zoo_vindicator",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder (the bread of the villages they raid).
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Woodland mansions in dark forests, 1 to 3 to a room, there from the start (no more ever come); raids, and now and then a patrol. Arms crossed till they see you, then they run at you with an iron axe. Weaken one to a quarter of its health (6 of 24), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 4, prefersCompany: false },
    // An outpost's or a woodland mansion's floor under half the pen's.
    mobFloor: { ids: ["minecraft:dark_oak_planks", "minecraft:birch_planks", "minecraft:cobblestone"], share: 0.5, how: "an outpost's or a woodland mansion's floor (dark oak planks, birch planks or cobblestone)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Vindicator", "Captain"],
    names: ["Johnny", "Cleft", "Chopper", "Mansionby", "Hewer", "Woodsman", "Splitter", "Grimaxe", "Glare", "Crossarms", "Thane", "Vandal", "Sever", "Felling", "Notch", "Hackett"],
  },
  "zoocraft:zoo_evoker": {
    id: "zoocraft:zoo_evoker",
    displayName: "Evoker",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_evoker",
    mobSource: "minecraft:evocation_illager",
    entityType: "zoocraft:zoo_evoker",
    family: "zoo_evoker",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder (the bread of the villages they raid).
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "The upper floors of woodland mansions in dark forests, there from the start (no more ever come); raids from the fifth wave. They keep their distance, raise fangs from the ground under you and call up vexes. Weaken one to a quarter of its health (6 of 24), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 3, prefersCompany: false },
    // An outpost's or a woodland mansion's floor under half the pen's.
    mobFloor: { ids: ["minecraft:dark_oak_planks", "minecraft:birch_planks", "minecraft:cobblestone"], share: 0.5, how: "an outpost's or a woodland mansion's floor (dark oak planks, birch planks or cobblestone)" },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Evoker"],
    names: ["Wololo", "Fangsworth", "Conjura", "Mystra", "Evander", "Spellby", "Summoner", "Totemus", "Robes", "Incanta", "Maleva", "Arcana", "Wardle", "Sorcerella", "Grimoire", "Chanter"],
  },
  "zoocraft:zoo_vex": {
    id: "zoocraft:zoo_vex",
    displayName: "Vex",
    plural: "Vexes",
    // It hovers about low in the pen (the zoo's allay's hover); the game's flies through blocks, the zoo's never does.
    mobHovers: true,
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_vex",
    mobSource: "minecraft:vex",
    entityType: "zoocraft:zoo_vex",
    family: "zoo_vex",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder (the bread of the villages they raid).
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Only where an evoker calls them up, three at a time; they fly through walls, and one an evoker calls up starts to fade away 30 seconds to 2 minutes later. Weaken one to a quarter of its health (3.5 of 14) before it fades, then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // An outpost's or a woodland mansion's floor under half the pen's.
    mobFloor: { ids: ["minecraft:dark_oak_planks", "minecraft:birch_planks", "minecraft:cobblestone"], share: 0.5, how: "an outpost's or a woodland mansion's floor (dark oak planks, birch planks or cobblestone)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Vex"],
    names: ["Pester", "Snicker", "Imp", "Taunt", "Giggles", "Whirr", "Bother", "Gnat", "Tease", "Vexley", "Irkwing", "Smirk", "Gremlin", "Hoverby", "Fizzwing", "Peeve"],
  },
  // The ravager (0.1.211, module 12; research/vanilla_plan.md "0.1.211 the ravager: the design"): a zoo mob the zombie's
  // way (0.1.163), the raids' beast. A weakened one (a quarter: 25 of 100) calmed by a Passivity Serum (its wildSource),
  // a Mob Cage to a pen beside a Mob House's hall (mob_pen), Grain Rations; it joins the Illager Camp
  // (exhibits/mixing.js) on an outpost's or a mansion's floor. It never rams, bites, roars or tramples anything.
  "zoocraft:zoo_ravager": {
    id: "zoocraft:zoo_ravager",
    displayName: "Ravager",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_ravager",
    mobSource: "minecraft:ravager",
    entityType: "zoocraft:zoo_ravager",
    family: "zoo_ravager",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Grain Rations from a Basic Feeder (it tramples the villages' crops).
    dietTags: ["grain"],
    carrierProfile: "mob",
    baitItem: "zoocraft:grain_ration",
    observe: ["spot", "mobcalm"],
    where: "Only with raids, from the third wave (on Normal another in the fifth, a pillager riding it; on Hard an evoker or a vindicator rides one too). It tramples crops and leaves, rams and bites, and roars when a shield stuns it. Weaken one to a quarter of its health (25 of 100), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // An outpost's or a woodland mansion's floor under half the pen's.
    mobFloor: { ids: ["minecraft:dark_oak_planks", "minecraft:birch_planks", "minecraft:cobblestone"], share: 0.5, how: "an outpost's or a woodland mansion's floor (dark oak planks, birch planks or cobblestone)" },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Ravager"],
    names: ["Tusk", "Trample", "Crunch", "Thunderhoof", "Mauler", "Bellow", "Chomp", "Juggernaut", "Snort", "Barge", "Bruiser", "Wrecker", "Battering", "Bulldozer", "Hornsby", "Rammer"],
  },
  // The guardian and the elder guardian (0.1.212, module 12; research/vanilla_plan.md "0.1.212 the guardian and the elder
  // guardian: the design"): zoo mobs the zombie's way (0.1.163), the first that swim on their own. A weakened one (a
  // quarter: 7.5 of 30, 20 of 80) calmed by a Passivity Serum (its wildSource), a Mob Cage to a Mob House water pen
  // (mob_pen_water, 0.1.200) on an ocean monument's floor, Fish Rations over the water; they share a pen as the Ocean
  // Monument (exhibits/mixing.js). They never fire their lasers; the elder never puts Mining Fatigue on anyone.
  "zoocraft:zoo_guardian": {
    id: "zoocraft:zoo_guardian",
    displayName: "Guardian",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_guardian",
    mobSource: "minecraft:guardian",
    entityType: "zoocraft:zoo_guardian",
    family: "zoo_guardian",
    movementProfile: "aquatic",
    habitatProfile: "mob_pen_water",
    mob: true,
    // Fish Rations from an Aquarium Feeder over the water (the game's hunt squid and axolotls).
    dietTags: ["fish"],
    aquariumFeeder: true,
    carrierProfile: "mob",
    baitItem: "zoocraft:fish_ration",
    observe: ["spot", "mobcalm"],
    where: "Only at ocean monuments, in the water in and around them. They swim in quick charges and fire a laser from up to 16 blocks off. Weaken one to a quarter of its health (7.5 of 30), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 6, prefersCompany: false },
    // An ocean monument's floor under half the pen's (the bottom of the water and the bank).
    mobFloor: { ids: ["minecraft:prismarine", "minecraft:prismarine_bricks", "minecraft:dark_prismarine", "minecraft:sea_lantern"], share: 0.5, how: "an ocean monument's floor (prismarine, prismarine bricks, dark prismarine or sea lanterns)", underWater: true },
    rationUnitsPerParkDay: 2,
    enrichmentTags: ["forage"],
    coats: ["Guardian"],
    names: ["Spiky", "Beamer", "Tidewatch", "Squinty", "Zapper", "Sentry", "Barb", "Eyeful", "Quills", "Spines", "Seawatch", "Spikeback", "Searchlight", "Prismo", "Goggle", "Thornfin"],
  },
  "zoocraft:zoo_elder_guardian": {
    id: "zoocraft:zoo_elder_guardian",
    displayName: "Elder Guardian",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_elder_guardian",
    mobSource: "minecraft:elder_guardian",
    entityType: "zoocraft:zoo_elder_guardian",
    family: "zoo_elder_guardian",
    movementProfile: "aquatic",
    habitatProfile: "mob_pen_water",
    mob: true,
    // Fish Rations from an Aquarium Feeder over the water (the game's hunt squid and axolotls).
    dietTags: ["fish"],
    aquariumFeeder: true,
    carrierProfile: "mob",
    baitItem: "zoocraft:fish_ration",
    observe: ["spot", "mobcalm"],
    where: "Only three in each ocean monument, made with it and never again: one in the top room and one in each wing. They fire a stronger laser and put Mining Fatigue on every player nearby. Weaken one to a quarter of its health (20 of 80), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // An ocean monument's floor under half the pen's (the bottom of the water and the bank).
    mobFloor: { ids: ["minecraft:prismarine", "minecraft:prismarine_bricks", "minecraft:dark_prismarine", "minecraft:sea_lantern"], share: 0.5, how: "an ocean monument's floor (prismarine, prismarine bricks, dark prismarine or sea lanterns)", underWater: true },
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Elder Guardian"],
    names: ["Methuselah", "Grandgaze", "Oldeye", "Ancient", "Patriarch", "Matriarch", "Venerable", "Grizzle", "Monolith", "Leviathan", "Hexer", "Bellwether", "Greybeard", "Elderly", "Doyen", "Primordial"],
  },
  // The breeze and the creaking (0.1.213, module 12; research/vanilla_plan.md "0.1.213 the breeze and the creaking: the
  // design"): zoo mobs the zombie's way (0.1.163). A weakened breeze (a quarter: 7.5 of 30) or any creaking (its 1 health
  // needs no weakening) calmed by a Passivity Serum (its wildSource), a Mob Cage to a Mob House pen: a breeze's on a trial
  // chamber's tuff, a creaking's on a pale garden's moss in the dark (it comes out only at night). A breeze never leaps at
  // anyone or fires a wind charge; a creaking never stalks anyone, freezes or crumbles away at dawn.
  "zoocraft:zoo_breeze": {
    id: "zoocraft:zoo_breeze",
    displayName: "Breeze",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_breeze",
    mobSource: "minecraft:breeze",
    entityType: "zoocraft:zoo_breeze",
    family: "zoo_breeze",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Wind charges (a breeze rod is 4) from a Basic Feeder: a game choice, the game's eat nothing.
    dietTags: ["wind"],
    carrierProfile: "mob",
    baitItem: "minecraft:wind_charge",
    observe: ["spot", "mobcalm"],
    where: "Only in trial chambers, from the trial spawners set in chiseled tuff in their combat rooms. They leap about, fire wind charges that knock you back, and bat arrows and tridents away. Weaken one to a quarter of its health (7.5 of 30), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A trial chamber's floor under half the pen's.
    mobFloor: { ids: ["minecraft:tuff", "minecraft:polished_tuff", "minecraft:tuff_bricks", "minecraft:chiseled_tuff", "minecraft:chiseled_tuff_bricks"], share: 0.5, how: "a trial chamber's floor (tuff, polished tuff, tuff bricks or chiseled tuff)" },
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Breeze"],
    names: ["Gust", "Whirl", "Breezy", "Cyclone", "Squall", "Twister", "Draft", "Whoosh", "Vortex", "Updraft", "Windy", "Blustery", "Typhoon", "Whirlwind", "Dervish", "Zephyrus"],
  },
  "zoocraft:zoo_creaking": {
    id: "zoocraft:zoo_creaking",
    displayName: "Creaking",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_creaking",
    mobSource: "minecraft:creaking",
    entityType: "zoocraft:zoo_creaking",
    family: "zoo_creaking",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Resin clumps (a block of resin is 9) from a Basic Feeder: a game choice, the game's eat nothing (a hit creaking grows resin on its heart's logs).
    dietTags: ["resin"],
    carrierProfile: "mob",
    baitItem: "minecraft:resin_clump",
    observe: ["spot", "mobcalm"],
    where: "Only in pale gardens at night, made by an active creaking heart (one set between two pale oak logs). Nothing hurts one while its heart stands; it stands still while you look at it, creeps up on you when you don't, and crumbles away at dawn. One from a spawn egg stays, and dies to a single hit. It needs no weakening (1 health): use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A pale garden's floor under half the pen's, and the dark (it comes out only at night).
    mobFloor: { ids: ["minecraft:pale_moss_block", "minecraft:pale_oak_planks"], share: 0.5, how: "a pale garden's floor (pale moss blocks or pale oak planks)" },
    lowLight: true,
    rationUnitsPerParkDay: 1,
    enrichmentTags: ["forage"],
    coats: ["Creaking"],
    names: ["Creak", "Splinter", "Bark", "Knot", "Twig", "Sap", "Thicket", "Kindling", "Stump", "Grimbark", "Knothole", "Rootling", "Groany", "Gnarly", "Hollowbark", "Creaky"],
  },
  // The warden (0.1.214, module 12; research/vanilla_plan.md "0.1.214 the warden: the design"): a zoo mob the zombie's
  // way (0.1.163). A weakened one (a quarter: 125 of 500) calmed by a Passivity Serum (its wildSource), a Mob Cage to a
  // Mob House pen on the deep dark's floor, in the dark; Meat Rations. It never roars, strikes, fires a sonic boom, puts
  // Darkness on anyone or digs back into the ground.
  "zoocraft:zoo_warden": {
    id: "zoocraft:zoo_warden",
    displayName: "Warden",
    origin: "vanilla",
    homeDimension: "minecraft:overworld",
    wildSource: "zoocraft:calm_warden",
    mobSource: "minecraft:warden",
    entityType: "zoocraft:zoo_warden",
    family: "zoo_warden",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen",
    mob: true,
    // Meat Rations from a Basic Feeder (a game choice, the zombie's: the game's eats nothing).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "Only in the deep dark, deep underground (most in ancient cities): one digs up out of the ground when sculk shriekers have been set off four times near you, and digs back down after a minute without hearing anything. It is blind but finds you by sound and smell, hits for half your health and more, fires sonic booms through walls and shields, and puts Darkness on you. Weaken one to a quarter of its health (125 of 500), then use a Passivity Serum on it (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // The deep dark's floor under half the pen's, and the dark (it lives far below the light).
    mobFloor: { ids: ["minecraft:sculk", "minecraft:deepslate", "minecraft:cobbled_deepslate", "minecraft:polished_deepslate", "minecraft:deepslate_bricks", "minecraft:deepslate_tiles"], share: 0.5, how: "the deep dark's floor (sculk, deepslate, cobbled or polished deepslate, deepslate bricks or deepslate tiles)" },
    lowLight: true,
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Warden"],
    names: ["Sculkie", "Gloomer", "Shrieker", "Warder", "Quake", "Throb", "Deepdark", "Obsidianus", "Silence", "Grimhold", "Heartbeat", "Tendril", "Abyssal", "Skulkwatch", "Hollowheart", "Gloomheart"],
  },
  // The wither (0.1.215, module 12; research/vanilla_plan.md "0.1.215 the wither: the design"): a zoo mob the zombie's
  // way (0.1.163), without gravity on the vex's hover (0.1.210: mobHovers). A weakened one (a quarter of its health: 75, 112.5 or
  // 150 by the difficulty) calmed by a Passivity Serum (its wildSource), but not while it is still charging up; a Mob
  // Cage to the giant's tall Mob House pen (mob_pen_giant) on a soul sand valley's ground; Bone Rations. It never fires a
  // skull, blows up, breaks a block or calls up wither skeletons.
  "zoocraft:zoo_wither": {
    id: "zoocraft:zoo_wither",
    displayName: "Wither",
    // It drifts about low in the pen, just over the floor, on the vex's hover (as the game's idle wither keeps low; the
    // game's flies by its engine when it fights, a copy can't); a calmed one hangs where it was calmed.
    mobHovers: true,
    origin: "vanilla",
    homeDimension: "minecraft:nether",
    wildSource: "zoocraft:calm_wither",
    mobSource: "minecraft:wither",
    entityType: "zoocraft:zoo_wither",
    family: "zoo_wither",
    movementProfile: "terrestrial",
    habitatProfile: "mob_pen_giant",
    mob: true,
    // Bone Rations from a Basic Feeder (a game choice, the skeletons': it is a skeleton by its family; the game's eats
    // nothing).
    dietTags: ["bone"],
    carrierProfile: "mob",
    baitItem: "zoocraft:bone_ration",
    observe: ["spot", "mobcalm"],
    where: "Never in the wild on its own: someone builds one from four soul sand or soul soil in a T with three wither skeleton skulls on top. It charges up for 11 seconds (nothing hurts it), blows up, then flies about firing exploding skulls that wither you; hurt, it breaks the blocks round it, and below half health it shrugs off arrows, calls up wither skeletons (not on Easy) and dashes at you, smashing through blocks. Its health is 300 on Easy, 450 on Normal and 600 on Hard. Weaken one to a quarter of its health (75, 112.5 or 150), then use a Passivity Serum on it up close (Mob Taming research)",
    social: { minGroup: 1, recommendedMax: 2, prefersCompany: false },
    // A soul sand valley's ground under half the pen's (what a wither is built from).
    mobFloor: { ids: ["minecraft:soul_sand", "minecraft:soul_soil"], share: 0.5, how: "a soul sand valley's ground (soul sand or soul soil)" },
    // Three heads.
    rationUnitsPerParkDay: 3,
    enrichmentTags: ["forage"],
    coats: ["Wither"],
    names: ["Trio", "Tricephalus", "Ashgrim", "Soulsby", "Bonecrown", "Nethra", "Triskull", "Gloamskull", "Sootsby", "Dirge", "Withergrin", "Starfall", "Skulldred", "Mourn", "Grimm", "Cerberus"],
  },
  // The ender dragon (0.1.216, module 12; research/vanilla_plan.md "0.1.216 the ender dragon: the design"): a zoo mob the
  // zombie's way (0.1.163), flown by script the phantom's way (0.1.205: mobFlight): it circles under its pen's roof and
  // dives down over the floor now and then, a calmed one circles low. A weakened one (a quarter of its 200 health: 50)
  // calmed by a Passivity Serum (its wildSource); the End sends another at once (the 1.26.62.1 server: one taken away by
  // script, first or respawned, is replaced within 5 seconds), and a kill still lights the portal. A Mob Cage to a pen of
  // its own (mob_pen_dragon, 35 by 35 under 16 blocks of air) on the End's ground; Meat Rations. It never breathes fire,
  // fires a fireball, perches or knocks anyone about, and no crystal heals it.
  "zoocraft:zoo_ender_dragon": {
    id: "zoocraft:zoo_ender_dragon",
    displayName: "Ender Dragon",
    origin: "vanilla",
    homeDimension: "minecraft:the_end",
    wildSource: "zoocraft:calm_ender_dragon",
    mobSource: "minecraft:ender_dragon",
    entityType: "zoocraft:zoo_ender_dragon",
    family: "zoo_ender_dragon",
    movementProfile: "aerial",
    habitatProfile: "mob_pen_dragon",
    mob: true,
    mobFlight: true,
    // Meat Rations from a Basic Feeder (a game choice: it bites; the game's eats nothing).
    dietTags: ["meat"],
    carrierProfile: "mob",
    baitItem: "zoocraft:meat_ration",
    observe: ["spot", "mobcalm"],
    where: "The End's main island, where one waits for whoever comes through the End portal: it circles the obsidian pillars (the end crystals on top heal it), dives at you and knocks you flying, fires dragon fireballs that leave clouds of purple breath, and now and then perches on the exit portal in the middle and breathes over it. Its health is 200. A kill lights the exit portal home (and lays the dragon egg, the first time); four end crystals on the portal's sides bring another. Break the crystals, weaken it to a quarter of its health (50 of 200), then use a Passivity Serum on it up close as it perches (Mob Taming research). The End sends another at once: the one to beat to light the way home",
    social: { minGroup: 1, recommendedMax: 1, prefersCompany: false },
    // The End's ground under half the pen's (the main island's end stone, the pillars' obsidian).
    mobFloor: { ids: ["minecraft:end_stone", "minecraft:end_bricks", "minecraft:obsidian"], share: 0.5, how: "the End's ground (end stone, end stone bricks or obsidian)" },
    // The biggest mob in the game.
    rationUnitsPerParkDay: 4,
    enrichmentTags: ["forage"],
    coats: ["Ender Dragon"],
    names: ["Voidwing", "Endra", "Obsidia", "Purpurion", "Duskfang", "Nightshade", "Gatekeeper", "Crystalis", "Exile", "Oblivion", "Endwyrm", "Pillarwing", "Skyreign", "Starwyrm", "Gloamwing", "Voidmaw"],
  },
};

// Lava Rays swim in lava, Striders walk across it: either way the lava pool is their home.
export function livesOnLava(species) {
  return Boolean(species?.lavaSwimmer || species?.lavaWalker);
}

// "Otters", "Deer": the display name for more than one.
export function pluralOf(species) {
  return species.plural ?? `${species.displayName}s`;
}

// Every item that coaxes a wild one into its carrier: its bait, and any more it takes (species.baitAlso, 0.1.169).
export function baitItems(species) {
  return [species.baitItem, ...(species.baitAlso ?? [])].filter(Boolean);
}

export function speciesForWild(typeId) {
  return Object.values(SPECIES).find((s) => s.wildSource === typeId);
}

export function speciesForEntity(typeId) {
  return Object.values(SPECIES).find((s) => s.entityType === typeId || s.youngEntityType === typeId);
}

// The mob an animal is drawn as: the young of a species whose young are a mob of their own (frogs' tadpoles, 0.1.184), else
// the species' own.
export function entityTypeOf(species, juvenile) {
  return juvenile && species.youngEntityType ? species.youngEntityType : species.entityType;
}

// The zoo mob a vanilla mob is (0.1.163: the zombie the journal spots; 0.1.164 the creeper and spider too), or undefined.
export function speciesForMob(typeId) {
  return Object.values(SPECIES).find((s) => s.mobSource === typeId);
}
